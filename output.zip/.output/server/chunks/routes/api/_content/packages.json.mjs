import { d as defineEventHandler, f as fetchPackageJson, a as fetchPackageJsonFromGitHub } from '../../../nitro/nitro.mjs';
import { s as serverQueryContent } from '../../../_/server.mjs';
import 'lru-cache';
import '@unocss/core';
import '@unocss/preset-wind3';
import 'devalue';
import 'consola';
import 'unified';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import 'detab';
import 'micromark-util-sanitize-uri';
import 'hast-util-to-string';
import 'github-slugger';
import 'zod';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'vue';
import '@intlify/utils';
import 'vue-router';
import 'node:url';
import '@iconify/utils';
import 'unhead/server';
import 'unhead/plugins';
import 'unhead/utils';
import 'vue-bundle-renderer/runtime';
import 'vue/server-renderer';
import 'ipx';
import '../../../_/storage.mjs';
import '../../../_/path-meta.mjs';
import 'slugify';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';

const packages_json = defineEventHandler(async (event) => {
  const { projects: _projects } = await serverQueryContent(event).where({ _path: /^\/packages$/ }).findOne();
  const projects = Object.values(_projects || {}).flat();
  const populatedPackages = await Promise.all(
    projects.map(
      async (pkg) => {
        const packageJson = pkg.npm ? await fetchPackageJson(pkg.npm) : pkg.github ? await fetchPackageJsonFromGitHub(pkg.github) : null;
        return {
          id: pkg.name.toLowerCase(),
          title: pkg.name,
          icon: pkg.icon,
          description: pkg.desc,
          npm: packageJson ? {
            name: packageJson.name || pkg.npm || pkg.github || pkg.name,
            dependencies: Object.keys((packageJson == null ? void 0 : packageJson.dependencies) || {}),
            devDependencies: Object.keys((packageJson == null ? void 0 : packageJson.devDependencies) || {})
          } : void 0
        };
      }
    )
  );
  return populatedPackages;
});

export { packages_json as default };
