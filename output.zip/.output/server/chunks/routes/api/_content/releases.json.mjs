import { d as defineEventHandler, b as fetchReleasesFromGitHub, p as parseMarkdown } from '../../../nitro/nitro.mjs';
import { s as serverQueryContent } from '../../../_/server.mjs';
import 'lru-cache';
import '@unocss/core';
import '@unocss/preset-wind3';
import 'devalue';
import 'consola';
import 'unified';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import 'detab';
import 'micromark-util-sanitize-uri';
import 'hast-util-to-string';
import 'github-slugger';
import 'zod';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'vue';
import '@intlify/utils';
import 'vue-router';
import 'node:url';
import '@iconify/utils';
import 'unhead/server';
import 'unhead/plugins';
import 'unhead/utils';
import 'vue-bundle-renderer/runtime';
import 'vue/server-renderer';
import 'ipx';
import '../../../_/storage.mjs';
import '../../../_/path-meta.mjs';
import 'slugify';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';

const releases_json = defineEventHandler(async (event) => {
  const { projects: _projects } = await serverQueryContent(event).where({ _path: /^\/packages$/ }).findOne();
  const projects = Object.values(_projects || {}).flat();
  const releases = await Promise.all(
    projects.map(async (preject) => {
      const repo = preject.github;
      if (!repo)
        return [];
      const releases2 = await fetchReleasesFromGitHub(repo);
      return Promise.all(
        releases2.filter((r) => r.draft === false).map(async (release) => {
          var _a;
          let body = {
            type: "root",
            children: []
          };
          try {
            const markdown = await parseMarkdown((_a = release.markdown) != null ? _a : "");
            body = markdown.body;
          } catch (e) {
            console.warn(`Failed to parse markdown for release ${release.tag} of repo ${repo}:`, e);
            console.warn("Markdown content:", release.markdown);
          }
          return {
            url: `https://github.com/${repo}/releases/tag/${release.tag}`,
            icon: preject.icon,
            repo,
            tag: release.tag,
            title: release.name || release.tag,
            date: release.publishedAt,
            body
          };
        })
      );
    })
  ).then((results) => results.flat().filter(Boolean));
  return releases.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 20);
});

export { releases_json as default };
