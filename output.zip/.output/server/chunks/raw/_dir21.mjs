// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-network/advanced/_dir\",\"_dir\":\"advanced\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"进阶\",\"collapse\":false,\"_id\":\"content:uni-network:3.advanced:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-network/3.advanced/_dir.yml\",\"_stem\":\"uni-network/3.advanced/_dir\",\"_extension\":\"yml\"},\"hash\":\"A7HW96pXHngF1tu4H_aJ2pIgEZn0v5EtrXXrSv8f8nQ\"}";

export { _dir as default };
