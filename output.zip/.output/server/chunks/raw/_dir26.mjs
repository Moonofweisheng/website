// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-use/api/_dir\",\"_dir\":\"api\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"API文档\",\"collapse\":false,\"_id\":\"content:uni-use:2.api:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-use/2.api/_dir.yml\",\"_stem\":\"uni-use/2.api/_dir\",\"_extension\":\"yml\"},\"hash\":\"UdlxyKwiGHzjSsoHbNBAUjrTpJi6e8c99kKNi7sJBlM\"}";

export { _dir as default };
