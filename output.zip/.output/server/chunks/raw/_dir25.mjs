// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-use/guide/_dir\",\"_dir\":\"guide\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"快速开始\",\"collapse\":false,\"_id\":\"content:uni-use:1.guide:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-use/1.guide/_dir.yml\",\"_stem\":\"uni-use/1.guide/_dir\",\"_extension\":\"yml\"},\"hash\":\"u9txxrCnfeHNmxFTlyO0udHd3T3RLH-gp6RxosJkz_4\"}";

export { _dir as default };
