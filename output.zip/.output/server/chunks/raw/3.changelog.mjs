// ROLLUP_NO_REPLACE 
 const _3_changelog = "{\"parsed\":{\"_path\":\"/changelog\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"更新日志\",\"icon\":\"ri-menu-2-fill\",\"fullpage\":true,\"description\":\"查看 uni-helper 生态系统中所有项目的最新更新日志，了解每个版本的改进和新功能。\",\"_id\":\"content:3.changelog.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"3.changelog.yml\",\"_stem\":\"3.changelog\",\"_extension\":\"yml\"},\"hash\":\"ppvVS45_TeZX3HwOrbSRhbz3oNUYomh1Lpysgfnt3C4\"}";

export { _3_changelog as default };
