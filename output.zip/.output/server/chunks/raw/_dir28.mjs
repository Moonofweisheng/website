// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/vitesse-uni-app/guide/_dir\",\"_dir\":\"guide\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"指南\",\"navigation\":{\"redirect\":\"/vitesse-uni-app/guide/auto-imports\"},\"collapse\":false,\"_id\":\"content:vitesse-uni-app:2.guide:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"vitesse-uni-app/2.guide/_dir.yml\",\"_stem\":\"vitesse-uni-app/2.guide/_dir\",\"_extension\":\"yml\"},\"hash\":\"xfpMxg_GU3J_YDIkwazzNhbbjZ0x7ATwlIjDdllq_6I\"}";

export { _dir as default };
