// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/vitesse-uni-app/getting-started/_dir\",\"_dir\":\"getting-started\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"快速开始\",\"navigation\":{\"redirect\":\"/vitesse-uni-app/getting-started/introduction\"},\"collapse\":false,\"_id\":\"content:vitesse-uni-app:1.getting-started:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"vitesse-uni-app/1.getting-started/_dir.yml\",\"_stem\":\"vitesse-uni-app/1.getting-started/_dir\",\"_extension\":\"yml\"},\"hash\":\"jfJiAuPwG1m-LlW9COiVofknlCrQWQM0vMzEwh2JYc4\"}";

export { _dir as default };
