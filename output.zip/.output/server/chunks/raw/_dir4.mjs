// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/plugin-uni/_dir\",\"_dir\":\"plugin-uni\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"plugin-uni\",\"collapse\":false,\"showTitle\":false,\"toc\":{\"links\":[{\"title\":\"点亮星星\",\"icon\":\"lucide:star\",\"to\":\"https://github.com/uni-helper/plugin-uni\",\"target\":\"_blank\"},{\"title\":\"反馈问题\",\"icon\":\"lucide:github\",\"to\":\"https://github.com/uni-helper/plugin-uni/issues\",\"target\":\"_blank\"}]},\"_id\":\"content:plugin-uni:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"plugin-uni/_dir.yml\",\"_stem\":\"plugin-uni/_dir\",\"_extension\":\"yml\"},\"hash\":\"i8H3xUlIuuJMJwZ3KpdYPizyt_m0np7PrLlwWapE9vc\"}";

export { _dir as default };
