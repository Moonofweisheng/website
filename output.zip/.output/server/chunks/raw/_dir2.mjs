// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/create-uni/_dir\",\"_dir\":\"create-uni\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"create-uni\",\"navigation\":{\"redirect\":\"/create-uni/core\"},\"collapse\":false,\"toc\":{\"links\":[{\"title\":\"点亮星星\",\"icon\":\"lucide:star\",\"to\":\"https://github.com/uni-helper/create-uni\",\"target\":\"_blank\"},{\"title\":\"反馈问题\",\"icon\":\"lucide:github\",\"to\":\"https://github.com/uni-helper/create-uni/issues\",\"target\":\"_blank\"}]},\"_id\":\"content:create-uni:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"create-uni/_dir.yml\",\"_stem\":\"create-uni/_dir\",\"_extension\":\"yml\"},\"hash\":\"IKFGDKu827mSM43WcdwOVnniXau5DKIuSVSQ6wdvv7o\"}";

export { _dir as default };
