// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-typed/_dir\",\"_dir\":\"uni-typed\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"uni-typed\",\"navigation\":{\"redirect\":\"/uni-typed/guide/getting-started\"},\"collapse\":false,\"toc\":{\"links\":[{\"title\":\"点亮星星\",\"icon\":\"lucide:star\",\"to\":\"https://github.com/uni-helper/uni-typed\",\"target\":\"_blank\"},{\"title\":\"反馈问题\",\"icon\":\"lucide:github\",\"to\":\"https://github.com/uni-helper/uni-typed/issues\",\"target\":\"_blank\"}]},\"_id\":\"content:uni-typed:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-typed/_dir.yml\",\"_stem\":\"uni-typed/_dir\",\"_extension\":\"yml\"},\"hash\":\"Giun37u_uIvsHFH-9CAh3T0DFdlqcvgZzIL8RMrwoEw\"}";

export { _dir as default };
