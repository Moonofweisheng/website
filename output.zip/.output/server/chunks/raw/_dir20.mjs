// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-network/api/_dir\",\"_dir\":\"api\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"API\",\"collapse\":false,\"_id\":\"content:uni-network:2.api:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-network/2.api/_dir.yml\",\"_stem\":\"uni-network/2.api/_dir\",\"_extension\":\"yml\"},\"hash\":\"sS7qJw_oA35k9DWtkqGRMKi_nlj_BSMLWf1BVoIwyCk\"}";

export { _dir as default };
