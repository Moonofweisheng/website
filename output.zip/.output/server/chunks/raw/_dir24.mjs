// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-typed/other/_dir\",\"_dir\":\"other\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"其他\",\"collapse\":false,\"_id\":\"content:uni-typed:2.other:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-typed/2.other/_dir.yml\",\"_stem\":\"uni-typed/2.other/_dir\",\"_extension\":\"yml\"},\"hash\":\"Lph7POoc4utDxZlq9GPd-IE7lNuMA57uFg583X5HQFw\"}";

export { _dir as default };
