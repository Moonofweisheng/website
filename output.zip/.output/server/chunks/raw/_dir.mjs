// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/axios-adapter/_dir\",\"_dir\":\"axios-adapter\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"axios-adapter\",\"collapse\":false,\"showTitle\":false,\"toc\":{\"links\":[{\"title\":\"点亮星星\",\"icon\":\"lucide:star\",\"to\":\"https://github.com/uni-helper/axios-adapter\",\"target\":\"_blank\"},{\"title\":\"反馈问题\",\"icon\":\"lucide:github\",\"to\":\"https://github.com/uni-helper/axios-adapter/issues\",\"target\":\"_blank\"}]},\"_id\":\"content:axios-adapter:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"axios-adapter/_dir.yml\",\"_stem\":\"axios-adapter/_dir\",\"_extension\":\"yml\"},\"hash\":\"_RyYSgdTtXX3ISj5i5GdR6Mv2yuld9rySs_wLPNLML0\"}";

export { _dir as default };
