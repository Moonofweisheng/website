// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-network/other/_dir\",\"_dir\":\"other\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"其他\",\"collapse\":false,\"_id\":\"content:uni-network:4.other:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-network/4.other/_dir.yml\",\"_stem\":\"uni-network/4.other/_dir\",\"_extension\":\"yml\"},\"hash\":\"A7HW96pXHngF1tu4H_aJ2pIgEZn0v5EtrXXrSv8f8nQ\"}";

export { _dir as default };
