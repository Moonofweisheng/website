// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-use/_dir\",\"_dir\":\"uni-use\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"uni-use\",\"navigation\":{\"redirect\":\"/uni-use/guide/installation\"},\"collapse\":false,\"toc\":{\"links\":[{\"title\":\"Star on Github\",\"icon\":\"lucide:star\",\"to\":\"https://github.com/uni-helper/uni-use\",\"target\":\"_blank\"},{\"title\":\"反馈问题\",\"icon\":\"lucide:github\",\"to\":\"https://github.com/uni-helper/uni-use/issues\",\"target\":\"_blank\"}]},\"_id\":\"content:uni-use:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-use/_dir.yml\",\"_stem\":\"uni-use/_dir\",\"_extension\":\"yml\"},\"hash\":\"A7t2O37FpS9_qCufF2H78IaPN0mxAlPR0KqZv1e-heU\"}";

export { _dir as default };
