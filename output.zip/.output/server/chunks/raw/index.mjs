// ROLLUP_NO_REPLACE 
 const index = "{\"parsed\":{\"_path\":\"/\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"首页\",\"description\":\"欢迎来到uni-helper\",\"navigation\":false,\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"home-page\",\"props\":{},\"children\":[]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:index.md\",\"_source\":\"content\",\"_file\":\"index.md\",\"_stem\":\"index\",\"_extension\":\"md\"},\"hash\":\"HWsQ1ZuOZhCzdd90h2Om8W5FGHUV40MDniC2qWp-O6Q\"}";

export { index as default };
