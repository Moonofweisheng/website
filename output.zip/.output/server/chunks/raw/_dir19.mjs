// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/uni-network/guide/_dir\",\"_dir\":\"guide\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"指南\",\"collapse\":false,\"_id\":\"content:uni-network:1.guide:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"uni-network/1.guide/_dir.yml\",\"_stem\":\"uni-network/1.guide/_dir\",\"_extension\":\"yml\"},\"hash\":\"WRb7cFWunEnjNephNWcVtc-dM9oFDPfWAj-_hY3D5s4\"}";

export { _dir as default };
