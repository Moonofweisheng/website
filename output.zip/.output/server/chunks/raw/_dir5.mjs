// ROLLUP_NO_REPLACE 
 const _dir = "{\"parsed\":{\"_path\":\"/unh/_dir\",\"_dir\":\"unh\",\"_draft\":false,\"_partial\":true,\"_locale\":\"\",\"title\":\"unh\",\"description\":\"二次封装的启动命令，支持平台别名和自定义Hooks\",\"navigation\":{\"redirect\":\"/unh/installation\"},\"collapse\":false,\"showTitle\":false,\"toc\":{\"links\":[{\"title\":\"点亮星星\",\"icon\":\"lucide:star\",\"to\":\"https://github.com/uni-helper/unh\",\"target\":\"_blank\"},{\"title\":\"反馈问题\",\"icon\":\"lucide:github\",\"to\":\"https://github.com/uni-helper/unh/issues\",\"target\":\"_blank\"}]},\"_id\":\"content:unh:_dir.yml\",\"_type\":\"yaml\",\"_source\":\"content\",\"_file\":\"unh/_dir.yml\",\"_stem\":\"unh/_dir\",\"_extension\":\"yml\"},\"hash\":\"2hxLDc_WF5XhmCeMacBD5Segr9XWSsP_6dRGn_N3PDY\"}";

export { _dir as default };
