import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { LRUCache } from 'lru-cache';
import { createGenerator } from '@unocss/core';
import presetWind from '@unocss/preset-wind3';
import { parse as parse$2 } from 'devalue';
import { createConsola, consola } from 'consola';
import { unified } from 'unified';
import remarkParse from 'remark-parse';
import remark2rehype from 'remark-rehype';
import remarkMDC, { parseFrontMatter } from 'remark-mdc';
import remarkGFM from 'remark-gfm';
import rehypeExternalLinks from 'rehype-external-links';
import rehypeSortAttributeValues from 'rehype-sort-attribute-values';
import rehypeSortAttributes from 'rehype-sort-attributes';
import rehypeRaw from 'rehype-raw';
import { detab } from 'detab';
import { normalizeUri } from 'micromark-util-sanitize-uri';
import { toString } from 'hast-util-to-string';
import Slugger from 'github-slugger';
import zod from 'zod';
import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$2, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import { toValue, isRef, hasInjectionContext, inject, ref, watchEffect, getCurrentInstance, onBeforeUnmount, onDeactivated, onActivated } from 'vue';
import { createPathIndexLanguageParser, parseAcceptLanguage } from '@intlify/utils';
import { createRouterMatcher } from 'vue-router';
import { fileURLToPath } from 'node:url';
import { getIcons } from '@iconify/utils';
import { createHead as createHead$1, propsToString } from 'unhead/server';
import { FlatMetaPlugin, DeprecationsPlugin, PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin } from 'unhead/plugins';
import { walkResolver } from 'unhead/utils';
import { createRenderer } from 'vue-bundle-renderer/runtime';
import { renderToString } from 'vue/server-renderer';
import { ipxFSStorage, ipxHttpStorage, createIPX, createIPXH3Handler } from 'ipx';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$2(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$2(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function isRelative(inputString) {
  return ["./", "../"].some((string_) => inputString.startsWith(string_));
}
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/");
  }
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  {
    return input.endsWith("/") ? input : input + "/";
  }
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withoutLeadingSlash(input = "") {
  return (hasLeadingSlash(input) ? input.slice(1) : input) || "/";
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    return input;
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const trimmed = input.slice(_base.length);
  return trimmed[0] === "/" ? trimmed : "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}
function withHttps(input) {
  return withProtocol(input, "https://");
}
function withProtocol(input, protocol) {
  let match = input.match(PROTOCOL_REGEX);
  if (!match) {
    match = input.match(/^\/{2,}/);
  }
  if (!match) {
    return protocol + input;
  }
  return protocol + input.slice(match[0].length);
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return defaultProto ? parseURL(defaultProto + input) : parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

function parse$1(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = {};
  const dec = opt.decode || decode$1;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode$1(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode$1(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode$1(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = Object.assign({}, defaults);
  for (const key in baseObject) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=g(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function g(...n){return function(...e){for(const t of n)t(...e);}}const m=_();class A extends m{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp$1(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

let H3Error$1 = class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode$1(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage$1(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
};
function createError$2(input) {
  if (typeof input === "string") {
    return new H3Error$1(input);
  }
  if (isError$1(input)) {
    return input;
  }
  const err = new H3Error$1(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp$1(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode$1(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode$1(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage$1(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError$1(error) ? error : createError$2(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES$1.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError$1(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function getRouterParams$1(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode$2(params[key]);
    }
  }
  return params;
}
function getRouterParam$1(event, name, opts = {}) {
  const params = getRouterParams$1(event, opts);
  return params[name];
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$2({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders$1(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader$1(event, name) {
  const headers = getRequestHeaders$1(event);
  const value = headers[name.toLowerCase()];
  return value;
}
const getHeader = getRequestHeader$1;
function getRequestHost$1(event, opts = {}) {
  if (opts.xForwardedHost) {
    const xForwardedHost = event.node.req.headers["x-forwarded-host"];
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol$1(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL$1(event, opts = {}) {
  const host = getRequestHost$1(event, opts);
  const protocol = getRequestProtocol$1(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const ParsedBodySymbol = Symbol.for("h3ParsedBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !String(event.node.req.headers["transfer-encoding"] ?? "").split(",").map((e) => e.trim()).filter(Boolean).includes("chunked")) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
async function readBody(event, options = {}) {
  const request = event.node.req;
  if (hasProp$1(request, ParsedBodySymbol)) {
    return request[ParsedBodySymbol];
  }
  const contentType = request.headers["content-type"] || "";
  const body = await readRawBody(event);
  let parsed;
  if (contentType === "application/json") {
    parsed = _parseJSON(body, options.strict ?? true);
  } else if (contentType.startsWith("application/x-www-form-urlencoded")) {
    parsed = _parseURLEncodedBody(body);
  } else if (contentType.startsWith("text/")) {
    parsed = body;
  } else {
    parsed = _parseJSON(body, options.strict ?? false);
  }
  request[ParsedBodySymbol] = parsed;
  return parsed;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}
function _parseJSON(body = "", strict) {
  if (!body) {
    return void 0;
  }
  try {
    return destr(body, { strict });
  } catch {
    throw createError$2({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid JSON body"
    });
  }
}
function _parseURLEncodedBody(body) {
  const form = new URLSearchParams(body);
  const parsedForm = /* @__PURE__ */ Object.create(null);
  for (const [key, value] of form.entries()) {
    if (hasProp$1(parsedForm, key)) {
      if (!Array.isArray(parsedForm[key])) {
        parsedForm[key] = [parsedForm[key]];
      }
      parsedForm[key].push(value);
    } else {
      parsedForm[key] = value;
    }
  }
  return parsedForm;
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES$1 = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS$1 = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage$1(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS$1, "");
}
function sanitizeStatusCode$1(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey$1(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}

function parseCookies(event) {
  return parse$1(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie$1(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString$1(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey$1(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey$1(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie$1(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString$1(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString$1(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer$1 = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send$1(event, data, type) {
  if (type) {
    defaultContentType$1(event, type);
  }
  return new Promise((resolve) => {
    defer$1(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode$1(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode$1(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage$1(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType$1(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect$1(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode$1(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send$1(event, html, MIMES$1.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp$1(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp$1(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString$1(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode$1(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage$1(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$2({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode$1(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage$1(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString$1(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders$1(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp$1(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler$1(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray$1(handler.onRequest),
    onBeforeResponse: _normalizeArray$1(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler$1(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray$1(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler$1(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler$1 = defineEventHandler$1;
function isEventHandler$1(input) {
  return hasProp$1(input, "__is_handler__");
}
function toEventHandler$1(input, _, _route) {
  if (!isEventHandler$1(input)) {
    console.warn(
      "[h3] Implicit event handler conversion is deprecated. Use `eventHandler()` or `fromNodeMiddleware()` to define event handlers.",
      _route && _route !== "/" ? `
     Route: ${_route}` : "",
      `
     Handler: ${input}`
    );
  }
  return input;
}
function defineLazyEventHandler$1(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler$1(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler$1((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler$1 = defineLazyEventHandler$1;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler$1(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _reqPath = event._path || event.node.req.url || "/";
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$2({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler$1(handler);
  } else if (!isEventHandler$1(handler)) {
    handler = toEventHandler$1(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send$1(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send$1(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$2(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send$1(event, val, MIMES$1.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send$1(event, JSON.stringify(val, void 0, jsonSpace), MIMES$1.json);
  }
  if (valType === "bigint") {
    return send$1(event, val.toString(), MIMES$1.json);
  }
  throw createError$2({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler$1(handler, void 0, path);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$2({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$2({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler$1((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$2(_error);
      if (!isError$1(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        context.options.body = typeof context.options.body === "string" ? context.options.body : JSON.stringify(context.options.body);
        context.options.headers = new Headers(context.options.headers || {});
        if (!context.options.headers.has("content-type")) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch$1 = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController$1 = globalThis.AbortController || i;
const ofetch = createFetch({ fetch: fetch$1, Headers: Headers$1, AbortController: AbortController$1 });
const $fetch$1 = ofetch;

const storageKeyProperties$1 = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage$1(storage, base) {
  base = normalizeBaseKey$1(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties$1) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$3(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function normalizeBaseKey$1(base) {
  base = normalizeKey$3(base);
  return base ? base + ":" : "";
}

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive$1(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive$1(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$2(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$2(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$2(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$4 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$4,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$2(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$2(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$2(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$2(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$2(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$2(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$2(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$2(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$2(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$2(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$2(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$2(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {
  ["nuxt-og-image:fonts:Noto+Sans+SC-normal-400.ttf.base64"]: {
    import: () => import('../raw/Noto_Sans_SC-normal-400.ttf.mjs').then(r => r.default || r),
    meta: {"type":"text/plain; charset=utf-8","etag":"\"dd0828-22a5m8oJvGh93dea0lutvzW/UU0\"","mtime":"2025-12-29T15:08:37.154Z"}
  },
  ["nitro:bundled:cache:content:content-index.json"]: {
    import: () => import('../raw/content-index.mjs').then(r => r.default || r),
    meta: {"type":"application/json","etag":"\"2ae7-I5wr1dnIM6rCHxknaytd77VAO9s\"","mtime":"2025-12-29T15:11:07.850Z"}
  },
  ["nitro:bundled:cache:content:content-navigation.json"]: {
    import: () => import('../raw/content-navigation.mjs').then(r => r.default || r),
    meta: {"type":"application/json","etag":"\"91c6-SUxkGD0i+VaVXMMGQV0VUtIqhzw\"","mtime":"2025-12-29T15:11:07.852Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:1.packages.yml"]: {
    import: () => import('../raw/1.packages.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"1e59-e3Fyd0rWc+uH63vUWLfl41SwivI\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:2.relations.md"]: {
    import: () => import('../raw/2.relations.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"e5f-XCSiZlO9LssLSRPDtcLkv4IkygM\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:3.changelog.yml"]: {
    import: () => import('../raw/3.changelog.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"1d2-4TUBfNeTS6GKFPschaSMYqJu1zM\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:index.md"]: {
    import: () => import('../raw/index.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1de-6UQVQOPWtBlx/WJHqPB4UmRYlNM\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:about:index.md"]: {
    import: () => import('../raw/index2.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"393f-z7oWZLrpK27mkbhw86Fo4bj96eA\"","mtime":"2025-12-29T15:11:07.852Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:awesome-uni-app:index.md"]: {
    import: () => import('../raw/index3.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"8f67-bdF5BogUCiM/rk56y7shuU1gmOE\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:axios-adapter:_dir.yml"]: {
    import: () => import('../raw/_dir.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"279-bmqPuiPhu0HQVEZt1hznccA9GjY\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:axios-adapter:index.md"]: {
    import: () => import('../raw/index4.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"835f-xgZNVCEhMYlur3INMuCQUuD15qo\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:blog:definepage.md"]: {
    import: () => import('../raw/definepage.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1654e-4BQVR24kSRCq/fxXUCL1WgetuTA\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:blog:index.md"]: {
    import: () => import('../raw/index5.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"c34-o8y2DEt5h6+WXR8Q3zEBV2OKdpQ\"","mtime":"2025-12-29T15:11:07.853Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:blog:unh.md"]: {
    import: () => import('../raw/unh.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"d3a7-G9SeLoN/HkPty+f42PfsaEB/Bq4\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:create-uni:1.core.md"]: {
    import: () => import('../raw/1.core.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"69de-8LsWOvD1iBc2z8aDRLL8Off8elk\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:create-uni:2.gui.md"]: {
    import: () => import('../raw/2.gui.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"a08-anFHbSX+5UAc8X2mA6Jksb7EMds\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:create-uni:3.info.md"]: {
    import: () => import('../raw/3.info.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"7c9f-IaHm3GDSzkuyKAnkQX92WI7coa4\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:create-uni:4.mcp.md"]: {
    import: () => import('../raw/4.mcp.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1d40-fMR0YDvWvH6nwjeRrKgpHk91te8\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:create-uni:_dir.yml"]: {
    import: () => import('../raw/_dir2.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"27c-KQ/zVGVWy8bEpcQBp+9exnVyCB8\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:eslint-config:index.md"]: {
    import: () => import('../raw/index6.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2e9a-Hki0nV9uYiEScMGMQmKVhfxxCD8\"","mtime":"2025-12-29T15:11:07.856Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:hbuilderx-cli:index.md"]: {
    import: () => import('../raw/index7.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1f75-3ZYhz+Kt4+Zf3SlumrtDeVTBj0s\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:hbuilderx-vanilla:1.introduction.md"]: {
    import: () => import('../raw/1.introduction.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"6243-3klE/LRztOb/jU69mGDMVmx/2n8\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:hbuilderx-vanilla:2.api.md"]: {
    import: () => import('../raw/2.api.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"188a2-+T/O73KtXvUnkxaEzxdtGkXko8Y\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:hbuilderx-vanilla:3.build.md"]: {
    import: () => import('../raw/3.build.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"be91-+LC61rtbvgPPqsFmTLs4eXC790M\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:hbuilderx-vanilla:_dir.yml"]: {
    import: () => import('../raw/_dir3.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"357-SjF7o9cBHtJVvf1Xt4RT8TNVaVA\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:plugin-uni:_dir.yml"]: {
    import: () => import('../raw/_dir4.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"261-C6HYobrbmT6ZEmNVBRHnX4nn2Qk\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:plugin-uni:index.md"]: {
    import: () => import('../raw/index8.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3d8d-VzzTna7Bjw7/AIfNmS4RBHsLdHs\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unh:1.installation.md"]: {
    import: () => import('../raw/1.installation.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"4431-PnRP5/4IP7fbgYnxbmp4PItXgWc\"","mtime":"2025-12-29T15:11:07.865Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unh:2.alias.md"]: {
    import: () => import('../raw/2.alias.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3a49-A/e20qDs3hXjuK/R3jBXd14ysSM\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unh:3.hooks.md"]: {
    import: () => import('../raw/3.hooks.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"5382-N0qp+TasyqAYXN++ly935yan7IA\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unh:4.auto-generate.md"]: {
    import: () => import('../raw/4.auto-generate.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"4a77-izxEhb5ZFDAguTINbu1iu2w4+ys\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unh:5.devtools.md"]: {
    import: () => import('../raw/5.devtools.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"36ec-It/FFpCHtzayalZFCmOWE4JMMbk\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unh:6.env.md"]: {
    import: () => import('../raw/6.env.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"45ff-i+tXUuTa2rixWC1fxOzoEDg2B40\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unh:_dir.yml"]: {
    import: () => import('../raw/_dir5.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2a9-a26gb46gpiYroWzdtjFHcfKXKow\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-deploy:index.md"]: {
    import: () => import('../raw/index9.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"16d3c-qj9Pr6vqjINnhZ1iTB2CIvQGvnM\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-devtools:index.md"]: {
    import: () => import('../raw/index10.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2230-/kgJZDGc1mmUqoYFez2P2emv7pk\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-env:index.md"]: {
    import: () => import('../raw/index11.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1709-kUXqlxj1v6uNTblhDCyEFBSgtyI\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:_dir.yml"]: {
    import: () => import('../raw/_dir6.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2a5-oOtZw2djz3F3fK5pw40zICNRN54\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-promises:index.md"]: {
    import: () => import('../raw/index12.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"ed21-d1OuR8tO68joL3JS0cqH0VS321Y\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:_dir.yml"]: {
    import: () => import('../raw/_dir7.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"284-DygLWwRGWwGh/PPupFh3rOqPbwg\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:_dir.yml"]: {
    import: () => import('../raw/_dir8.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"271-PZC2q/NUoFHmFzz5FY+nUyM+cLg\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unocss-preset-uni:_dir.yml"]: {
    import: () => import('../raw/_dir9.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"299-k/ubu6GL7HE8v8+CvkFxhhrlicY\"","mtime":"2025-12-29T15:11:07.854Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:unocss-preset-uni:index.md"]: {
    import: () => import('../raw/index13.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"ecda-7OjbulpoZ3e4v+zaNuSQdkDFoRk\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-components:_dir.yml"]: {
    import: () => import('../raw/_dir10.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2dc-KSpIHdHD0KuWqxzYKQZGCX6qcwQ\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-components:index.md"]: {
    import: () => import('../raw/index14.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3a6d-Vrn9udpUTuvQ1VmokDOrgKNlBBU\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-layouts:_dir.yml"]: {
    import: () => import('../raw/_dir11.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2c4-dw3kRX6mAn6nD+vJyv5r6zsVgzI\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-layouts:index.md"]: {
    import: () => import('../raw/index15.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"8bc7-7IQElXUaXNZS+EqjqNXYxi5llkQ\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-manifest:_dir.yml"]: {
    import: () => import('../raw/_dir12.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2cc-XKazEmCie9TFCBuu35/zDD5eV00\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-manifest:index.md"]: {
    import: () => import('../raw/index16.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"297f-iV8zH5huwIZo98Ph4i5yKymtl+s\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-middleware:_dir.yml"]: {
    import: () => import('../raw/_dir13.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2dc-rbtBatVB9jo4oMDvEWVYd41s5zM\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-middleware:index.md"]: {
    import: () => import('../raw/index17.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"613c-XOHl1Pu8zFtPXWBEBfNcrgERXJ4\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-pages:1.guide.md"]: {
    import: () => import('../raw/1.guide.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"4a48-nPJx2RvuVKTX8f/PQlHnEmsjVPo\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-pages:2.definepage.md"]: {
    import: () => import('../raw/2.definepage.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"f9d7-qjeLoPDHHQNYMhjpe0I5AKzGr1w\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-pages:3.option.md"]: {
    import: () => import('../raw/3.option.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"94a6-HA4auSjIi5s4X3n8wX7scTpyiRY\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-pages:4.extension.md"]: {
    import: () => import('../raw/4.extension.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"11fe1-Gtbf4/xcvwouk4csKNGZLZvdPhU\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-pages:_dir.yml"]: {
    import: () => import('../raw/_dir14.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"309-Lwau6+ME8xT6fn/po/MT3jtGRRc\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-platform:_dir.yml"]: {
    import: () => import('../raw/_dir15.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2cc-fZQVawyTe7Mzdbf7TPMnMgzZ46U\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-platform:index.md"]: {
    import: () => import('../raw/index18.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2bf2-S+tGs47OpGJBPoZnbiHvP1iVXvI\"","mtime":"2025-12-29T15:11:07.856Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-platform-modifier:_dir.yml"]: {
    import: () => import('../raw/_dir16.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"314-sh/AN/uRaemrH93n8g7AgfCoAFw\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vite-plugin-uni-platform-modifier:index.md"]: {
    import: () => import('../raw/index19.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"709d-yabDkik1Q4DDnxcuIWcxryz+/7c\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:_dir.yml"]: {
    import: () => import('../raw/_dir17.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2d3-fURKROSYPw+tGOzjdRg4WaFicUg\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:1.uni-helper-vscode.md"]: {
    import: () => import('../raw/1.uni-helper-vscode.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3b41-WHG0QO3lVzxtzJCjpsdXmnKIaJg\"","mtime":"2025-12-29T15:11:07.855Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:2.uni-highlight-vscode.md"]: {
    import: () => import('../raw/2.uni-highlight-vscode.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"22dc-2XowdAVFpyXmjq8EL5xVEWpu9j4\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:3.uni-app-schemas-vscode.md"]: {
    import: () => import('../raw/3.uni-app-schemas-vscode.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"8c5-Bm9n+LXdiPdgnLvQIE/HQmH3+Vs\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:4.uni-app-snippets-vscode.md"]: {
    import: () => import('../raw/4.uni-app-snippets-vscode.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"aa6-RupiOZQ5sQM7TL51tJ0ZUUpACV4\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:5.uni-ui-snippets-vscode.md"]: {
    import: () => import('../raw/5.uni-ui-snippets-vscode.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"a9b-Tp6IRR9VOp74ujaYog4zt7bLCd4\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:6.uni-cloud-snippets-vscode.md"]: {
    import: () => import('../raw/6.uni-cloud-snippets-vscode.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"ab6-JjX2f74eNxwjHh+GAryAQDvepgQ\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:7.uni-create-view.md"]: {
    import: () => import('../raw/7.uni-create-view.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"15d8-VVQte6F1cdWLU99WhJcejTc3iwg\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vs-code:_dir.yml"]: {
    import: () => import('../raw/_dir18.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"2ed-nMBiEzn0VouP8n2Kn8q0RephD2Q\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:1.guide:1.introduction.md"]: {
    import: () => import('../raw/1.introduction2.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"b8e-Im8C3uEpRgCw0jD1AyT+zs7YS98\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:1.guide:2.installation.md"]: {
    import: () => import('../raw/2.installation.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"abf-DnVIVWrxVoI5iWoh86TM7sI4IFI\"","mtime":"2025-12-29T15:11:07.850Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:1.guide:3.example.md"]: {
    import: () => import('../raw/3.example.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"a87d-CcMQVCaVDCWR49rLiRReZuDLoRI\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:1.guide:_dir.yml"]: {
    import: () => import('../raw/_dir19.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"16d-fJg8tResFghpklNia+oQRdTwl30\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:2.api:1.introduction.md"]: {
    import: () => import('../raw/1.introduction3.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2f04-Mr3kxyALYg8rYY7hjPjqOzt5No0\"","mtime":"2025-12-29T15:11:07.856Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:2.api:2.instance.md"]: {
    import: () => import('../raw/2.instance.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2cfd-m+lTcbV/rmiVf/4jfLOKd9pfNU8\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:2.api:3.request-config.md"]: {
    import: () => import('../raw/3.request-config.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"14013-aNWT7VipxhPyxenHhXWoErn0n9c\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:2.api:4.response-schema.md"]: {
    import: () => import('../raw/4.response-schema.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"6d4d-LrJnyE6J/NC3lJfCyWLWycjJOrA\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:2.api:5.config-defaults.md"]: {
    import: () => import('../raw/5.config-defaults.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3777-EFVfLiiXb6UuOC02rCroJ7LA9L4\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:2.api:_dir.yml"]: {
    import: () => import('../raw/_dir20.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"160-J5Ya660HQAua6owI3DVs4xFs16I\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:3.advanced:1.interceptors.md"]: {
    import: () => import('../raw/1.interceptors.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"c63e-lvW12X+sbqpo+8vQt/HCXPDzaj8\"","mtime":"2025-12-29T15:11:07.856Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:3.advanced:2.handling-errors.md"]: {
    import: () => import('../raw/2.handling-errors.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"799f-SD3Da/H2C1p0QiOq3RZhzPiSyc0\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:3.advanced:3.cancellation.md"]: {
    import: () => import('../raw/3.cancellation.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"831c-YDDJ0SQl280OObvyGMpwzIHRY2c\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:3.advanced:4.typescript-support.md"]: {
    import: () => import('../raw/4.typescript-support.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"bac2-sQiuSS+C82CRpkbta0J1zAR1bDE\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:3.advanced:5.enhancements.md"]: {
    import: () => import('../raw/5.enhancements.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2ab0-+quJqtAms5kuCovzNt3md64VBvA\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:3.advanced:6.composition-api.md"]: {
    import: () => import('../raw/6.composition-api.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1460-ED4M9bHOftO6imXA3bGgTCJ87BE\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:3.advanced:_dir.yml"]: {
    import: () => import('../raw/_dir21.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"17c-tk4toAlaJxq+FktsAMh9CT81oiI\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:4.other:1.build.md"]: {
    import: () => import('../raw/1.build.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"7cc-eSUi769pbdw3LZANANOkgMonFDA\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:4.other:2.comparison.md"]: {
    import: () => import('../raw/2.comparison.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"54ca-sUyhOhKGRido908qfyWEvsxOVTg\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:4.other:3.thank.md"]: {
    import: () => import('../raw/3.thank.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"93c-Fc/hyIjfqZ0gfgRvt4Be7Eri7lw\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-network:4.other:_dir.yml"]: {
    import: () => import('../raw/_dir22.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"16d-sDSiUl8gU2WFBAWTDTCrNgxXkHo\"","mtime":"2025-12-29T15:11:07.857Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:1.why.md"]: {
    import: () => import('../raw/1.why.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"505-1jGuyv5EuZhtdGH0M6+jmGiDaDk\"","mtime":"2025-12-29T15:11:07.853Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:10.uni-components.md"]: {
    import: () => import('../raw/10.uni-components.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"357-+CNLPUHYZU6RGBqn3nDJnpEYJXQ\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:2.getting-started.md"]: {
    import: () => import('../raw/2.getting-started.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1a22-1LurUPra2Dk6I1vVXMWJxacXciQ\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:3.uni-app-types.md"]: {
    import: () => import('../raw/3.uni-app-types.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"e359-mwd+BioG+pxtm5LH6rMn/UcbTGM\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:4.uni-cloud-types.md"]: {
    import: () => import('../raw/4.uni-cloud-types.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"c528-+mAUrgFUBvEeayOA6cciANEbl+0\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:5.uni-ui-types.md"]: {
    import: () => import('../raw/5.uni-ui-types.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"d138-XQsrMGR+xmcS4NjS0q1j3qtGOaM\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:6.uni-types.md"]: {
    import: () => import('../raw/6.uni-types.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"e526-ygUKkkAblXdUxlxdruKUI5bQ4f8\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:7.uni-app-components.md"]: {
    import: () => import('../raw/7.uni-app-components.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"368-3BWGzb6/t9o+RXzl5JCkF/WyKR4\"","mtime":"2025-12-29T15:11:07.861Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:8.uni-cloud-components.md"]: {
    import: () => import('../raw/8.uni-cloud-components.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"372-7gQywQB56pU88K6d6dRalQA52hk\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:9.uni-ui-components.md"]: {
    import: () => import('../raw/9.uni-ui-components.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"363-kToZ3dt2hSu+BeUqaOftbiB8SLU\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:1.guide:_dir.yml"]: {
    import: () => import('../raw/_dir23.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"165-6Vgfl+dr/FzJLfDDTcLH2El4l8U\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:2.other:1.faq.md"]: {
    import: () => import('../raw/1.faq.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"32af-sA2LITSBUq5GvEtlUJFeomEVwQU\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:2.other:2.migrate-v0-to-v1.md"]: {
    import: () => import('../raw/2.migrate-v0-to-v1.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"8cd3-dNZ5Bn+Fiy1lNV7j054NHxeq8dc\"","mtime":"2025-12-29T15:11:07.857Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-typed:2.other:_dir.yml"]: {
    import: () => import('../raw/_dir24.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"165-Y1SZCFSA8qh8bG514k24Ww5dXgw\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:1.guide:1.installation.md"]: {
    import: () => import('../raw/1.installation2.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"463a-DZ253WCF52/sDAfBDjH38kis7YY\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:1.guide:2.notice.md"]: {
    import: () => import('../raw/2.notice.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"5602-PnDFklKCYPuHwbh6IH6bu9jdRns\"","mtime":"2025-12-29T15:11:07.853Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:1.guide:_dir.yml"]: {
    import: () => import('../raw/_dir25.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"163-eyquxPiB4L7NPnD5AX57biNMKnE\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:_dir.yml"]: {
    import: () => import('../raw/_dir26.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"156-Kdf8v7cLPQ1h7R/z527hOWZs7+w\"","mtime":"2025-12-29T15:11:07.857Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnBackPress.md"]: {
    import: () => import('../raw/tryOnBackPress.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"253e-9udtDfzFP3mKKOTgB5Q6QMh34Z0\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnHide.md"]: {
    import: () => import('../raw/tryOnHide.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"11b4-66I6u1zrXDOo2EXk+Bg29dx3ec4\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnInit.md"]: {
    import: () => import('../raw/tryOnInit.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"11b4-yoqfTbvd/t/94KH8ss+73Q2ePHU\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnLoad.md"]: {
    import: () => import('../raw/tryOnLoad.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"11b4-qcECPBN45hX2xjD5/jZT+Sg6Btg\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnReady.md"]: {
    import: () => import('../raw/tryOnReady.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"11c1-h/1UI0l8pyziJW1Uq7HtgYdCsK0\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnScopeDispose.md"]: {
    import: () => import('../raw/tryOnScopeDispose.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"124f-amEwp9eJYxYQjV93+yVyRZeG7fg\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnShow.md"]: {
    import: () => import('../raw/tryOnShow.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"11b4-XfX8jBvUqo0KLt+E33RH4Oqu/bM\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:tryOnUnload.md"]: {
    import: () => import('../raw/tryOnUnload.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"11ce-sviTxICBC++rF7UYsZa9xgj11a4\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useActionSheet.md"]: {
    import: () => import('../raw/useActionSheet.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"19f6-fIN8jY+E0Jg7jCS7xlt81vE400I\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useClipboardData.md"]: {
    import: () => import('../raw/useClipboardData.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3786-+Z9ZyAHquVwAUq+UAaZQcKPSnhU\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useDownloadFile.md"]: {
    import: () => import('../raw/useDownloadFile.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"5e3-cZR0t/d162HMldVrRxBc0gCJAw0\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useGlobalData.md"]: {
    import: () => import('../raw/useGlobalData.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"16f6-zPF7hVJLevwAO+FIuCp7q5sEXGI\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useInterceptor.md"]: {
    import: () => import('../raw/useInterceptor.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3e88-jUHqo63XhLNz9JLN9jj4N9m4EKo\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useLoading.md"]: {
    import: () => import('../raw/useLoading.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"31ae-EmINTG0v7IzYYltAEZE9pxqbxG0\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useModal.md"]: {
    import: () => import('../raw/useModal.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1942-H7pKqCNgh5OysDe4X8gQEw7hsVA\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useNetwork.md"]: {
    import: () => import('../raw/useNetwork.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1a8c-DWuB9Bg/9bHdO0NS9c+CXUaINZA\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useOnline.md"]: {
    import: () => import('../raw/useOnline.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"f84-g9gyq9TJZsREhnz48US8hP3Jtuk\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:usePage.md"]: {
    import: () => import('../raw/usePage.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"ec8-LvPMHT7B6uVPHXVCSzCFUzR7nwE\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:usePageScroll.md"]: {
    import: () => import('../raw/usePageScroll.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1332-QH0+TY8HBxEqi1h4RU0QU6rw6mM\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:usePages.md"]: {
    import: () => import('../raw/usePages.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"ee1-XIuUi48Y9E1XNjQTO5pMXRxMnRI\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:usePreferredDark.md"]: {
    import: () => import('../raw/usePreferredDark.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"f4b-kwub+aWe2uaPsmrE2oQES6F4txc\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:usePreferredLanguage.md"]: {
    import: () => import('../raw/usePreferredLanguage.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"f65-zmDlRZlW/lUpGS49rvXnEA9AmP4\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:usePrevPage.md"]: {
    import: () => import('../raw/usePrevPage.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"efc-m489Rf632UswpN6BtG7opCVm/wQ\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:usePrevRoute.md"]: {
    import: () => import('../raw/usePrevRoute.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"f1b-8ntU94WxzV4NCQI4pCdLdeeEZ+M\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useProvider.md"]: {
    import: () => import('../raw/useProvider.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"199f-WQm486qNOLTBGjvBcD5I1xQ+KhE\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useQuery.md"]: {
    import: () => import('../raw/useQuery.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1826f-WDmFD2gV0Bf8IT73Kdz9AN2NSJk\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useRequest.md"]: {
    import: () => import('../raw/useRequest.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"5b6-5yny4BqETrUQYwTHAVQfryTJbnk\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useRoute.md"]: {
    import: () => import('../raw/useRoute.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"ee1-d5B36y3HkMyzpierzL486XMIw0E\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useRouter.md"]: {
    import: () => import('../raw/useRouter.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3f15-Nijyzd3Kfcjx0/hnGMXxxa6vWCw\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useScanCode.md"]: {
    import: () => import('../raw/useScanCode.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"194b-j5+D1HKi8831YlQJkmSJAGmB6Ss\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useScreenBrightness.md"]: {
    import: () => import('../raw/useScreenBrightness.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2c39-wf/Xjm2Ilddu96c53/TJRxXW1fs\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useSelectorQuery.md"]: {
    import: () => import('../raw/useSelectorQuery.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2d41-+c3It2uiITtQ64SdgIImNkP+fSY\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useSocket.md"]: {
    import: () => import('../raw/useSocket.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"633-DoOFtY3N6KWhvPGeXAKi/0w4+9I\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useStorage.md"]: {
    import: () => import('../raw/useStorage.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"21d4-ZJG+gS5b+T43NyNOGBiXRtHrX58\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useStorageAsync.md"]: {
    import: () => import('../raw/useStorageAsync.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"2260-wSCuyJKUGD59aYuwAuGmcSi8Dgo\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useStorageSync.md"]: {
    import: () => import('../raw/useStorageSync.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"208c-htmd5fDl+3hzBbP5p1ZrjidQBdI\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useToast.md"]: {
    import: () => import('../raw/useToast.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"1d45-FNYpWt3PgLiD6QcafGF6KxCh5ns\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useUploadFile.md"]: {
    import: () => import('../raw/useUploadFile.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"5d1-wp+tNsT3vaKs7J2Yh18gBwM3++M\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:uni-use:2.api:useVisible.md"]: {
    import: () => import('../raw/useVisible.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"f05-R5NTlj6mC5NikGvWRqXlNnhLLsA\"","mtime":"2025-12-29T15:11:07.862Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:1.introduction.md"]: {
    import: () => import('../raw/1.introduction4.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"fc3-TDItqqYjeO8bTrDzXHJHTUaPHXE\"","mtime":"2025-12-29T15:11:07.853Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:2.installation.md"]: {
    import: () => import('../raw/2.installation2.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3c34-lJ1zE+KJLxgiXn1TTAYekdCdpn8\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:3.views.md"]: {
    import: () => import('../raw/3.views.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"91df-adZwo5b75VxjguyqTHN2UpFmKng\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:4.styling.md"]: {
    import: () => import('../raw/4.styling.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"33a7-9grLnApOsWgaHYzJXUPiMn8ChXU\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:5.data-fetching.md"]: {
    import: () => import('../raw/5.data-fetching.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"3956-0FWUQOAyVIlqhnl3R6Tze6WC6Qg\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:6.state-management.md"]: {
    import: () => import('../raw/6.state-management.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"f1e2-aeChb+l02710KYm+hl8vpswEF5g\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:7.deployment.md"]: {
    import: () => import('../raw/7.deployment.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"c067-gC6ej0/BzBr8X7UqY+PEkMpeoJI\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:1.getting-started:_dir.yml"]: {
    import: () => import('../raw/_dir27.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"1ff-lnXi4Ux9THwFWzgh7689VReQaCQ\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:2.guide:1.auto-imports.md"]: {
    import: () => import('../raw/1.auto-imports.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"23eb-ApxHCSK+SJm8V4XEVdqKxf9yndY\"","mtime":"2025-12-29T15:11:07.860Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:2.guide:2.uniapp-development.md"]: {
    import: () => import('../raw/2.uniapp-development.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"4a0-hFEpymp4vNT6bNgq0IIb4mh8ZWY\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:2.guide:3.typescript.md"]: {
    import: () => import('../raw/3.typescript.mjs').then(r => r.default || r),
    meta: {"type":"text/markdown; charset=utf-8","etag":"\"119e-gFZEx6YaK6zvVFiQ2BK7+s0rQSI\"","mtime":"2025-12-29T15:11:07.863Z"}
  },
  ["nitro:bundled:cache:content:parsed:content:vitesse-uni-app:2.guide:_dir.yml"]: {
    import: () => import('../raw/_dir28.mjs').then(r => r.default || r),
    meta: {"type":"text/yaml; charset=utf-8","etag":"\"1bd-FRCc3Bs+eWSNpRZJz/j4wifY6as\"","mtime":"2025-12-29T15:11:07.863Z"}
  }
};

const normalizeKey$1 = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey$1(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey$1(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey$1(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function normalizeKey(key, sep = ":") {
  if (!key) {
    return "";
  }
  return key.replace(/[:/\\]/g, sep).replace(/^[:/\\]|[:/\\]$/g, "");
}
function createError$1(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError$1);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError$1(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError$1(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$2(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME$3 = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME$3, "base");
  }
  opts.base = resolve$2(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError$1(
        DRIVER_NAME$3,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME$3,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const OVERLAY_REMOVED = "__OVERLAY_REMOVED__";
const DRIVER_NAME$2 = "overlay";
const overlay = defineDriver((options) => {
  return {
    name: DRIVER_NAME$2,
    options,
    async hasItem(key, opts) {
      for (const layer of options.layers) {
        if (await layer.hasItem(key, opts)) {
          if (layer === options.layers[0] && await options.layers[0]?.getItem(key) === OVERLAY_REMOVED) {
            return false;
          }
          return true;
        }
      }
      return false;
    },
    async getItem(key) {
      for (const layer of options.layers) {
        const value = await layer.getItem(key);
        if (value === OVERLAY_REMOVED) {
          return null;
        }
        if (value !== null) {
          return value;
        }
      }
      return null;
    },
    // TODO: Support native meta
    // async getMeta (key) {},
    async setItem(key, value, opts) {
      await options.layers[0]?.setItem?.(key, value, opts);
    },
    async removeItem(key, opts) {
      await options.layers[0]?.setItem?.(key, OVERLAY_REMOVED, opts);
    },
    async getKeys(base, opts) {
      const allKeys = await Promise.all(
        options.layers.map(async (layer) => {
          const keys = await layer.getKeys(base, opts);
          return keys.map((key) => normalizeKey(key));
        })
      );
      const uniqueKeys = [...new Set(allKeys.flat())];
      const existingKeys = await Promise.all(
        uniqueKeys.map(async (key) => {
          if (await options.layers[0]?.getItem(key) === OVERLAY_REMOVED) {
            return false;
          }
          return key;
        })
      );
      return existingKeys.filter(Boolean);
    },
    async dispose() {
      await Promise.all(
        options.layers.map(async (layer) => {
          if (layer.dispose) {
            await layer.dispose();
          }
        })
      );
    }
  };
});

const DRIVER_NAME$1 = "memory";
const memoryDriver = defineDriver(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

const storage$1 = createStorage({});

storage$1.mount('/assets', assets$1);

storage$1.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

const bundledStorage = ["/cache/content"];
for (const base of bundledStorage) {
  storage$1.mount(base, overlay({
    layers: [
      memoryDriver(),
      // TODO
      // prefixStorage(storage, base),
      prefixStorage(storage$1, 'assets:nitro:bundled:' + base)
    ]
  }));
}

function useStorage(base = "") {
  return base ? prefixStorage$1(storage$1, base) : storage$1;
}

function serialize$1(o){return typeof o=="string"?`'${o}'`:new c().serialize(o)}const c=/*@__PURE__*/function(){class o{#t=new Map;compare(t,r){const e=typeof t,n=typeof r;return e==="string"&&n==="string"?t.localeCompare(r):e==="number"&&n==="number"?t-r:String.prototype.localeCompare.call(this.serialize(t,true),this.serialize(r,true))}serialize(t,r){if(t===null)return "null";switch(typeof t){case "string":return r?t:`'${t}'`;case "bigint":return `${t}n`;case "object":return this.$object(t);case "function":return this.$function(t)}return String(t)}serializeObject(t){const r=Object.prototype.toString.call(t);if(r!=="[object Object]")return this.serializeBuiltInType(r.length<10?`unknown:${r}`:r.slice(8,-1),t);const e=t.constructor,n=e===Object||e===void 0?"":e.name;if(n!==""&&globalThis[n]===e)return this.serializeBuiltInType(n,t);if(typeof t.toJSON=="function"){const i=t.toJSON();return n+(i!==null&&typeof i=="object"?this.$object(i):`(${this.serialize(i)})`)}return this.serializeObjectEntries(n,Object.entries(t))}serializeBuiltInType(t,r){const e=this["$"+t];if(e)return e.call(this,r);if(typeof r?.entries=="function")return this.serializeObjectEntries(t,r.entries());throw new Error(`Cannot serialize ${t}`)}serializeObjectEntries(t,r){const e=Array.from(r).sort((i,a)=>this.compare(i[0],a[0]));let n=`${t}{`;for(let i=0;i<e.length;i++){const[a,l]=e[i];n+=`${this.serialize(a,true)}:${this.serialize(l)}`,i<e.length-1&&(n+=",");}return n+"}"}$object(t){let r=this.#t.get(t);return r===void 0&&(this.#t.set(t,`#${this.#t.size}`),r=this.serializeObject(t),this.#t.set(t,r)),r}$function(t){const r=Function.prototype.toString.call(t);return r.slice(-15)==="[native code] }"?`${t.name||""}()[native]`:`${t.name}(${t.length})${r.replace(/\s*\n\s*/g,"")}`}$Array(t){let r="[";for(let e=0;e<t.length;e++)r+=this.serialize(t[e]),e<t.length-1&&(r+=",");return r+"]"}$Date(t){try{return `Date(${t.toISOString()})`}catch{return "Date(null)"}}$ArrayBuffer(t){return `ArrayBuffer[${new Uint8Array(t).join(",")}]`}$Set(t){return `Set${this.$Array(Array.from(t).sort((r,e)=>this.compare(r,e)))}`}$Map(t){return this.serializeObjectEntries("Map",t.entries())}}for(const s of ["Error","RegExp","URL"])o.prototype["$"+s]=function(t){return `${s}(${t})`};for(const s of ["Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Uint16Array","Int32Array","Uint32Array","Float32Array","Float64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join(",")}]`};for(const s of ["BigInt64Array","BigUint64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join("n,")}${t.length>0?"n":""}]`};return o}();

function isEqual(object1, object2) {
  if (object1 === object2) {
    return true;
  }
  if (serialize$1(object1) === serialize$1(object2)) {
    return true;
  }
  return false;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

function hash$1(input) {
  return digest(serialize$1(input));
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler$1(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString$1(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const defineAppConfig = (config) => config;

const appConfig0 = defineAppConfig({
  shadcnDocs: {
    site: {
      name: "uni-helper",
      url: "https://uni-helper.js.org",
      description: "\u65E8\u5728\u589E\u5F3A uni-app \u7CFB\u5217\u4EA7\u54C1\u7684\u5F00\u53D1\u6D41\u7A0B"
    },
    theme: {
      customizable: false,
      color: "zinc",
      radius: 0.5
    },
    header: {
      title: "uni-helper",
      showTitle: true,
      darkModeToggle: true,
      languageSwitcher: {
        enable: false
      },
      logo: {
        light: "/logo.svg",
        dark: "/logo-dark.svg"
      },
      nav: [
        {
          title: "\u9879\u76EE",
          to: "/packages",
          target: "_self",
          showLinkIcon: false
        },
        {
          title: "\u5173\u7CFB",
          to: "/relations",
          target: "_self",
          showLinkIcon: false
        },
        {
          title: "\u535A\u5BA2",
          to: "/blog",
          target: "_self",
          showLinkIcon: false
        },
        {
          title: "\u66F4\u65B0\u65E5\u5FD7",
          to: "/changelog",
          target: "_self",
          showLinkIcon: false
        },
        {
          title: "\u5173\u4E8E\u6211\u4EEC",
          to: "/about",
          target: "_self",
          showLinkIcon: false
        }
      ],
      links: [{
        icon: "lucide:github",
        to: "https://github.com/uni-helper",
        target: "_blank"
      }, {
        icon: "tabler:brand-wechat",
        to: "https://h5.hlcode.com.cn/?id=NE0myp6&f=wx",
        target: "_blank"
      }]
    },
    aside: {
      useLevel: true,
      collapse: false
    },
    main: {
      breadCrumb: true,
      showTitle: true,
      editLink: {
        enable: true,
        text: "\u5728 GitHub \u4E0A\u7F16\u8F91\u6B64\u9875",
        pattern: "https://github.com/uni-helper/website/edit/main/content/:path"
      },
      codeIcon: {
        "vite.config.ts": "vscode-icons:file-type-vite",
        "vite.config.js": "vscode-icons:file-type-vite",
        "uno.config.ts": "vscode-icons:file-type-unocss"
      }
    },
    footer: {
      credits: "This site is powered by [**Netlify**](https://www.netlify.com)",
      links: [{
        icon: "lucide:github",
        to: "https://github.com/uni-helper",
        target: "_blank"
      }, {
        icon: "lucide:coffee",
        to: "https://github.com/ModyQyW/sponsors",
        target: "_blank"
      }, {
        icon: "tabler:brand-wechat",
        to: "https://h5.hlcode.com.cn/?id=NE0myp6&f=wx",
        target: "_blank"
      }, {
        icon: "ri:qq-line",
        to: "https://qm.qq.com/q/5nPFSqa8Eg",
        target: "_blank"
      }]
    },
    toc: {
      title: "\u672C\u9875\u76EE\u5F55",
      iconLinks: [
        {
          icon: "lucide:coffee",
          to: "https://github.com/ModyQyW/sponsors",
          target: "_blank"
        },
        {
          icon: "tabler:brand-wechat",
          to: "https://h5.hlcode.com.cn/?id=NE0myp6&f=wx",
          target: "_blank"
        },
        {
          icon: "ri:qq-line",
          to: "https://qm.qq.com/q/5nPFSqa8Eg",
          target: "_blank"
        }
      ],
      carbonAds: {
        enable: true
      }
    },
    search: {
      enable: true,
      inAside: false
    }
  }
});

const inlineAppConfig = {
  "nuxt": {},
  "icon": {
    "provider": "server",
    "class": "",
    "aliases": {},
    "iconifyApiEndpoint": "https://api.iconify.design",
    "localApiEndpoint": "/api/_nuxt_icon",
    "fallbackToApi": true,
    "cssSelectorPrefix": "i-",
    "cssWherePseudo": true,
    "mode": "css",
    "attrs": {
      "aria-hidden": true
    },
    "collections": [
      "academicons",
      "akar-icons",
      "ant-design",
      "arcticons",
      "basil",
      "bi",
      "bitcoin-icons",
      "bpmn",
      "brandico",
      "bx",
      "bxl",
      "bxs",
      "bytesize",
      "carbon",
      "catppuccin",
      "cbi",
      "charm",
      "ci",
      "cib",
      "cif",
      "cil",
      "circle-flags",
      "circum",
      "clarity",
      "codicon",
      "covid",
      "cryptocurrency",
      "cryptocurrency-color",
      "dashicons",
      "devicon",
      "devicon-plain",
      "ei",
      "el",
      "emojione",
      "emojione-monotone",
      "emojione-v1",
      "entypo",
      "entypo-social",
      "eos-icons",
      "ep",
      "et",
      "eva",
      "f7",
      "fa",
      "fa-brands",
      "fa-regular",
      "fa-solid",
      "fa6-brands",
      "fa6-regular",
      "fa6-solid",
      "fad",
      "fe",
      "feather",
      "file-icons",
      "flag",
      "flagpack",
      "flat-color-icons",
      "flat-ui",
      "flowbite",
      "fluent",
      "fluent-emoji",
      "fluent-emoji-flat",
      "fluent-emoji-high-contrast",
      "fluent-mdl2",
      "fontelico",
      "fontisto",
      "formkit",
      "foundation",
      "fxemoji",
      "gala",
      "game-icons",
      "geo",
      "gg",
      "gis",
      "gravity-ui",
      "gridicons",
      "grommet-icons",
      "guidance",
      "healthicons",
      "heroicons",
      "heroicons-outline",
      "heroicons-solid",
      "hugeicons",
      "humbleicons",
      "ic",
      "icomoon-free",
      "icon-park",
      "icon-park-outline",
      "icon-park-solid",
      "icon-park-twotone",
      "iconamoon",
      "iconoir",
      "icons8",
      "il",
      "ion",
      "iwwa",
      "jam",
      "la",
      "lets-icons",
      "line-md",
      "logos",
      "ls",
      "lucide",
      "lucide-lab",
      "mage",
      "majesticons",
      "maki",
      "map",
      "marketeq",
      "material-symbols",
      "material-symbols-light",
      "mdi",
      "mdi-light",
      "medical-icon",
      "memory",
      "meteocons",
      "mi",
      "mingcute",
      "mono-icons",
      "mynaui",
      "nimbus",
      "nonicons",
      "noto",
      "noto-v1",
      "octicon",
      "oi",
      "ooui",
      "openmoji",
      "oui",
      "pajamas",
      "pepicons",
      "pepicons-pencil",
      "pepicons-pop",
      "pepicons-print",
      "ph",
      "pixelarticons",
      "prime",
      "ps",
      "quill",
      "radix-icons",
      "raphael",
      "ri",
      "rivet-icons",
      "si-glyph",
      "simple-icons",
      "simple-line-icons",
      "skill-icons",
      "solar",
      "streamline",
      "streamline-emojis",
      "subway",
      "svg-spinners",
      "system-uicons",
      "tabler",
      "tdesign",
      "teenyicons",
      "token",
      "token-branded",
      "topcoat",
      "twemoji",
      "typcn",
      "uil",
      "uim",
      "uis",
      "uit",
      "uiw",
      "unjs",
      "vaadin",
      "vs",
      "vscode-icons",
      "websymbol",
      "weui",
      "whh",
      "wi",
      "wpf",
      "zmdi",
      "zondicons"
    ],
    "fetchTimeout": 1500
  }
};

const appConfig = defuFn(appConfig0, inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function upperFirst(str) {
  return str ? str[0].toUpperCase() + str.slice(1) : "";
}
function lowerFirst(str) {
  return str ? str[0].toLowerCase() + str.slice(1) : "";
}
function pascalCase(str, opts) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => upperFirst(opts?.normalize ? p.toLowerCase() : p)).join("") : "";
}
function camelCase(str, opts) {
  return lowerFirst(pascalCase(str || "", opts));
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner ?? "-") : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "a11bb25b-a8a3-4885-b5ea-304859ef914c",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/": {
        "isr": true,
        "prerender": true
      },
      "/about": {
        "isr": true,
        "prerender": true
      },
      "/awesome-uni-app": {
        "isr": true,
        "prerender": true
      },
      "/axios-adapter": {
        "isr": true,
        "prerender": true
      },
      "/blog": {
        "isr": true,
        "prerender": true
      },
      "/blog/definepage": {
        "isr": true,
        "prerender": true
      },
      "/blog/unh": {
        "isr": true,
        "prerender": true
      },
      "/create-uni": {
        "isr": true,
        "prerender": true
      },
      "/create-uni/core": {
        "isr": true,
        "prerender": true
      },
      "/create-uni/gui": {
        "isr": true,
        "prerender": true
      },
      "/create-uni/info": {
        "isr": true,
        "prerender": true
      },
      "/create-uni/mcp": {
        "isr": true,
        "prerender": true
      },
      "/eslint-config": {
        "isr": true,
        "prerender": true
      },
      "/hbuilderx-cli": {
        "isr": true,
        "prerender": true
      },
      "/hbuilderx-vanilla": {
        "isr": true,
        "prerender": true
      },
      "/hbuilderx-vanilla/api": {
        "isr": true,
        "prerender": true
      },
      "/hbuilderx-vanilla/build": {
        "isr": true,
        "prerender": true
      },
      "/hbuilderx-vanilla/introduction": {
        "isr": true,
        "prerender": true
      },
      "/packages": {
        "isr": true,
        "prerender": true
      },
      "/plugin-uni": {
        "isr": true,
        "prerender": true
      },
      "/relations": {
        "isr": true,
        "prerender": true
      },
      "/unh": {
        "isr": true,
        "prerender": true
      },
      "/unh/alias": {
        "isr": true,
        "prerender": true
      },
      "/unh/auto-generate": {
        "isr": true,
        "prerender": true
      },
      "/unh/devtools": {
        "isr": true,
        "prerender": true
      },
      "/unh/env": {
        "isr": true,
        "prerender": true
      },
      "/unh/hooks": {
        "isr": true,
        "prerender": true
      },
      "/unh/installation": {
        "isr": true,
        "prerender": true
      },
      "/uni-deploy": {
        "isr": true,
        "prerender": true
      },
      "/uni-devtools": {
        "isr": true,
        "prerender": true
      },
      "/uni-env": {
        "isr": true,
        "prerender": true
      },
      "/uni-network": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/advanced": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/advanced/cancellation": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/advanced/composition-api": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/advanced/enhancements": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/advanced/handling-errors": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/advanced/interceptors": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/advanced/typescript-support": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/api": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/api/config-defaults": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/api/instance": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/api/introduction": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/api/request-config": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/api/response-schema": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/guide": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/guide/example": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/guide/installation": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/guide/introduction": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/other": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/other/build": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/other/comparison": {
        "isr": true,
        "prerender": true
      },
      "/uni-network/other/thank": {
        "isr": true,
        "prerender": true
      },
      "/uni-promises": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/getting-started": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-app-components": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-app-types": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-cloud-components": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-cloud-types": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-components": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-types": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-ui-components": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/uni-ui-types": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/guide/why": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/other": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/other/faq": {
        "isr": true,
        "prerender": true
      },
      "/uni-typed/other/migrate-v0-to-v1": {
        "isr": true,
        "prerender": true
      },
      "/uni-use": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryonbackpress": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryonhide": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryoninit": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryonload": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryonready": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryonscopedispose": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryonshow": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/tryonunload": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useactionsheet": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useclipboarddata": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usedownloadfile": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useglobaldata": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useinterceptor": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useloading": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usemodal": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usenetwork": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useonline": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usepage": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usepages": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usepagescroll": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usepreferreddark": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usepreferredlanguage": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useprevpage": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useprevroute": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useprovider": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usequery": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/userequest": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useroute": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/userouter": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usescancode": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usescreenbrightness": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useselectorquery": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usesocket": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usestorage": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usestorageasync": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usestoragesync": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usetoast": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/useuploadfile": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/api/usevisible": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/guide": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/guide/installation": {
        "isr": true,
        "prerender": true
      },
      "/uni-use/guide/notice": {
        "isr": true,
        "prerender": true
      },
      "/unocss-preset-uni": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-components": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-layouts": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-manifest": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-middleware": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-pages": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-pages/definepage": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-pages/extension": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-pages/guide": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-pages/option": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-platform": {
        "isr": true,
        "prerender": true
      },
      "/vite-plugin-uni-platform-modifier": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started/data-fetching": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started/deployment": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started/installation": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started/introduction": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started/state-management": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started/styling": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/getting-started/views": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/guide": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/guide/auto-imports": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/guide/typescript": {
        "isr": true,
        "prerender": true
      },
      "/vitesse-uni-app/guide/uniapp-development": {
        "isr": true,
        "prerender": true
      },
      "/vs-code": {
        "isr": true,
        "prerender": true
      },
      "/vs-code/uni-app-schemas-vscode": {
        "isr": true,
        "prerender": true
      },
      "/vs-code/uni-app-snippets-vscode": {
        "isr": true,
        "prerender": true
      },
      "/vs-code/uni-cloud-snippets-vscode": {
        "isr": true,
        "prerender": true
      },
      "/vs-code/uni-create-view": {
        "isr": true,
        "prerender": true
      },
      "/vs-code/uni-helper-vscode": {
        "isr": true,
        "prerender": true
      },
      "/vs-code/uni-highlight-vscode": {
        "isr": true,
        "prerender": true
      },
      "/vs-code/uni-ui-snippets-vscode": {
        "isr": true,
        "prerender": true
      },
      "/api/_content/packages.json": {
        "swr": true,
        "prerender": true,
        "cache": {
          "swr": true
        }
      },
      "/api/_content/releases.json": {
        "swr": true,
        "prerender": true,
        "cache": {
          "swr": true
        }
      },
      "/__sitemap__/style.xsl": {
        "headers": {
          "Content-Type": "application/xslt+xml"
        }
      },
      "/sitemap.xml": {
        "redirect": {
          "to": "/sitemap_index.xml",
          "statusCode": 307
        }
      },
      "/sitemap_index.xml": {},
      "/__sitemap__/zh-CN.xml": {},
      "/api/_content/search-1767020924919": {
        "prerender": true,
        "headers": {
          "Content-Type": "text/plain; charset=utf-8"
        }
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_fonts/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_scripts/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "gtag": {
      "enabled": true,
      "initMode": "auto",
      "id": "G-249B95M763",
      "initCommands": [],
      "config": {},
      "tags": [],
      "loadingStrategy": "defer",
      "url": "https://www.googletagmanager.com/gtag/js"
    },
    "mdc": {
      "components": {
        "prose": true,
        "map": {
          "p": "prose-p",
          "a": "prose-a",
          "blockquote": "prose-blockquote",
          "code-inline": "prose-code-inline",
          "code": "ProseCodeInline",
          "em": "prose-em",
          "h1": "prose-h1",
          "h2": "prose-h2",
          "h3": "prose-h3",
          "h4": "prose-h4",
          "h5": "prose-h5",
          "h6": "prose-h6",
          "hr": "prose-hr",
          "img": "prose-img",
          "ul": "prose-ul",
          "ol": "prose-ol",
          "li": "prose-li",
          "strong": "prose-strong",
          "table": "prose-table",
          "thead": "prose-thead",
          "tbody": "prose-tbody",
          "td": "prose-td",
          "th": "prose-th",
          "tr": "prose-tr"
        }
      },
      "headings": {
        "anchorLinks": {
          "h1": false,
          "h2": true,
          "h3": true,
          "h4": true,
          "h5": false,
          "h6": false
        }
      }
    },
    "content": {
      "locales": [],
      "defaultLocale": "",
      "integrity": 1767020924919,
      "experimental": {
        "stripQueryParameters": false,
        "advanceQuery": false,
        "clientDB": false
      },
      "respectPathCase": false,
      "api": {
        "baseURL": "/api/_content"
      },
      "navigation": {
        "fields": [
          "icon",
          "navBadges",
          "navTruncate",
          "badges",
          "toc",
          "sidebar",
          "collapse",
          "editLink",
          "prevNext",
          "breadcrumb",
          "fullpage",
          "layout"
        ]
      },
      "tags": {
        "p": "prose-p",
        "a": "prose-a",
        "blockquote": "prose-blockquote",
        "code-inline": "prose-code-inline",
        "code": "ProseCodeInline",
        "em": "prose-em",
        "h1": "prose-h1",
        "h2": "prose-h2",
        "h3": "prose-h3",
        "h4": "prose-h4",
        "h5": "prose-h5",
        "h6": "prose-h6",
        "hr": "prose-hr",
        "img": "prose-img",
        "ul": "prose-ul",
        "ol": "prose-ol",
        "li": "prose-li",
        "strong": "prose-strong",
        "table": "prose-table",
        "thead": "prose-thead",
        "tbody": "prose-tbody",
        "td": "prose-td",
        "th": "prose-th",
        "tr": "prose-tr"
      },
      "highlight": {
        "theme": {
          "default": "github-light",
          "dark": "github-dark"
        },
        "preload": [
          "json",
          "js",
          "ts",
          "html",
          "css",
          "vue",
          "diff",
          "shell",
          "markdown",
          "mdc",
          "yaml",
          "bash",
          "ini",
          "dotenv"
        ]
      },
      "wsUrl": "",
      "documentDriven": {
        "page": true,
        "navigation": true,
        "surround": true,
        "globals": {},
        "layoutFallbacks": [
          "theme"
        ],
        "injectPage": true
      },
      "host": "",
      "trailingSlash": false,
      "search": {
        "indexed": true,
        "ignoredTags": [
          "script",
          "style",
          "pre"
        ],
        "filterQuery": {
          "_draft": false,
          "_partial": false
        },
        "options": {
          "fields": [
            "title",
            "content",
            "titles"
          ],
          "storeFields": [
            "title",
            "content",
            "titles"
          ],
          "searchOptions": {
            "prefix": true,
            "fuzzy": 0.2,
            "boost": {
              "title": 4,
              "content": 2,
              "titles": 1
            }
          }
        }
      },
      "contentHead": true,
      "anchorLinks": {
        "depth": 4,
        "exclude": [
          1
        ]
      }
    },
    "nuxt-scripts": {
      "version": "",
      "defaultScriptOptions": {
        "trigger": "onNuxtReady"
      }
    },
    "i18n": {
      "baseUrl": "",
      "defaultLocale": "zh",
      "rootRedirect": "",
      "redirectStatusCode": 302,
      "skipSettingLocaleOnNavigate": false,
      "locales": [
        {
          "code": "zh",
          "name": "简体中文",
          "language": "zh-CN",
          "_hreflang": "zh-CN",
          "_sitemap": "zh-CN"
        }
      ],
      "detectBrowserLanguage": {
        "alwaysRedirect": false,
        "cookieCrossOrigin": false,
        "cookieDomain": "",
        "cookieKey": "i18n_redirected",
        "cookieSecure": false,
        "fallbackLocale": "",
        "redirectOn": "root",
        "useCookie": true
      },
      "experimental": {
        "localeDetector": "",
        "typedPages": true,
        "typedOptionsAndMessages": false,
        "alternateLinkCanonicalQueries": true,
        "devCache": false,
        "cacheLifetime": "",
        "stripMessagesPayload": false,
        "preload": false,
        "strictSeo": false,
        "nitroContextDetection": true
      },
      "domainLocales": {
        "zh": {
          "domain": ""
        }
      }
    }
  },
  "sitemap": {
    "isI18nMapped": true,
    "sitemapName": "sitemap.xml",
    "isMultiSitemap": true,
    "excludeAppSources": [],
    "cacheMaxAgeSeconds": 600,
    "autoLastmod": false,
    "defaultSitemapsChunkSize": 1000,
    "minify": false,
    "sortEntries": true,
    "debug": false,
    "discoverImages": true,
    "discoverVideos": true,
    "sitemapsPathPrefix": "/__sitemap__/",
    "isNuxtContentDocumentDriven": true,
    "xsl": "/__sitemap__/style.xsl",
    "xslTips": true,
    "xslColumns": [
      {
        "label": "URL",
        "width": "50%"
      },
      {
        "label": "Images",
        "width": "25%",
        "select": "count(image:image)"
      },
      {
        "label": "Last Updated",
        "width": "25%",
        "select": "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"
      }
    ],
    "credits": true,
    "version": "7.4.7",
    "sitemaps": {
      "index": {
        "sitemapName": "index",
        "_route": "sitemap_index.xml",
        "sitemaps": [],
        "include": [],
        "exclude": []
      },
      "zh-CN": {
        "include": [],
        "exclude": [
          "/_**",
          "/_nuxt/**"
        ],
        "includeAppSources": true,
        "sitemapName": "zh-CN",
        "_route": "/__sitemap__/zh-CN.xml"
      }
    },
    "autoI18n": {
      "differentDomains": false,
      "defaultLocale": "zh",
      "locales": [
        {
          "code": "zh",
          "name": "简体中文",
          "language": "zh-CN",
          "_hreflang": "zh-CN",
          "_sitemap": "zh-CN"
        }
      ],
      "strategy": "prefix_except_default",
      "pages": {}
    }
  },
  "content": {
    "cacheVersion": 2,
    "cacheIntegrity": "fiBA5EKsWzUKyIQXekyzrRMa6OTScTV1rvWFD_D4n3o",
    "transformers": [],
    "base": "",
    "api": {
      "baseURL": "/api/_content"
    },
    "watch": {
      "ws": {
        "port": {
          "port": 4000,
          "portRange": [
            4000,
            4040
          ]
        },
        "hostname": "localhost",
        "showURL": false
      }
    },
    "sources": {},
    "ignores": [],
    "locales": [],
    "defaultLocale": "",
    "highlight": {
      "theme": {
        "default": "github-light",
        "dark": "github-dark"
      },
      "preload": [
        "json",
        "js",
        "ts",
        "html",
        "css",
        "vue",
        "diff",
        "shell",
        "markdown",
        "mdc",
        "yaml",
        "bash",
        "ini",
        "dotenv"
      ]
    },
    "markdown": {
      "tags": {
        "p": "prose-p",
        "a": "prose-a",
        "blockquote": "prose-blockquote",
        "code-inline": "prose-code-inline",
        "code": "ProseCodeInline",
        "em": "prose-em",
        "h1": "prose-h1",
        "h2": "prose-h2",
        "h3": "prose-h3",
        "h4": "prose-h4",
        "h5": "prose-h5",
        "h6": "prose-h6",
        "hr": "prose-hr",
        "img": "prose-img",
        "ul": "prose-ul",
        "ol": "prose-ol",
        "li": "prose-li",
        "strong": "prose-strong",
        "table": "prose-table",
        "thead": "prose-thead",
        "tbody": "prose-tbody",
        "td": "prose-td",
        "th": "prose-th",
        "tr": "prose-tr"
      },
      "anchorLinks": {
        "depth": 4,
        "exclude": [
          1
        ]
      },
      "remarkPlugins": {},
      "rehypePlugins": {}
    },
    "yaml": {},
    "csv": {
      "delimeter": ",",
      "json": true
    },
    "navigation": {
      "fields": [
        "icon",
        "navBadges",
        "navTruncate",
        "badges",
        "toc",
        "sidebar",
        "collapse",
        "editLink",
        "prevNext",
        "breadcrumb",
        "fullpage",
        "layout"
      ]
    },
    "contentHead": true,
    "documentDriven": true,
    "respectPathCase": false,
    "experimental": {
      "clientDB": false,
      "cacheContents": true,
      "stripQueryParameters": false,
      "advanceQuery": false,
      "search": {
        "indexed": true,
        "ignoredTags": [
          "script",
          "style",
          "pre"
        ],
        "filterQuery": {
          "_draft": false,
          "_partial": false
        },
        "options": {
          "fields": [
            "title",
            "content",
            "titles"
          ],
          "storeFields": [
            "title",
            "content",
            "titles"
          ],
          "searchOptions": {
            "prefix": true,
            "fuzzy": 0.2,
            "boost": {
              "title": 4,
              "content": 2,
              "titles": 1
            }
          }
        }
      }
    }
  },
  "icon": {
    "serverKnownCssClasses": []
  },
  "nuxt-scripts": {
    "version": "0.13.0"
  },
  "nuxt-site-config": {
    "stack": [
      {
        "_context": "system",
        "_priority": -15,
        "name": "website",
        "env": "production"
      },
      {
        "_context": "package.json",
        "_priority": -10,
        "name": "@uni-helper/website"
      },
      {
        "_priority": -3,
        "_context": "nuxt-site-config:config",
        "url": "https://uni-helper.js.org/",
        "name": "Uni Helper"
      },
      {
        "_context": "@nuxtjs/i18n",
        "defaultLocale": "zh-CN"
      }
    ],
    "version": "3.2.8",
    "debug": false,
    "multiTenancy": []
  },
  "nuxt-og-image": {
    "version": "5.1.12",
    "satoriOptions": {},
    "resvgOptions": {},
    "sharpOptions": {},
    "publicStoragePath": "root:public:",
    "defaults": {
      "emojis": "noto",
      "renderer": "satori",
      "component": "NuxtSeo",
      "extension": "png",
      "width": 1200,
      "height": 600,
      "cacheMaxAgeSeconds": 259200
    },
    "debug": false,
    "baseCacheKey": "/cache/nuxt-og-image/5.1.12",
    "fonts": [
      {
        "cacheKey": "Noto+Sans+SC:400",
        "style": "normal",
        "weight": "400",
        "name": "Noto+Sans+SC",
        "path": "",
        "key": "nuxt-og-image:fonts:Noto+Sans+SC-normal-400.ttf.base64"
      }
    ],
    "hasNuxtIcon": true,
    "colorPreference": "light",
    "strictNuxtContentPaths": "",
    "isNuxtContentDocumentDriven": true
  },
  "ipx": {
    "baseURL": "/_ipx",
    "alias": {},
    "fs": {
      "dir": "../public"
    },
    "http": {
      "domains": [
        "github.com"
      ]
    }
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
const _sharedAppConfig = _deepFreeze(klona(appConfig));
function useAppConfig(event) {
  {
    return _sharedAppConfig;
  }
}
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}

getContext("nitro-app", {
  asyncContext: false,
  AsyncLocalStorage: void 0
});

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler$1((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect$1(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          targetPath = withoutBase(targetPath, strpBase);
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString$1(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function isJsonRequest(event) {
  if (hasReqHeader(event, "accept", "text/html")) {
    return false;
  }
  return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
  const value = getRequestHeader$1(event, name);
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
  if (event.handled || isJsonRequest(event)) {
    return;
  }
  const defaultRes = await defaultHandler(error, event, { json: true });
  const statusCode = error.statusCode || 500;
  if (statusCode === 404 && defaultRes.status === 302) {
    setResponseHeaders(event, defaultRes.headers);
    setResponseStatus(event, defaultRes.status, defaultRes.statusText);
    return send$1(event, JSON.stringify(defaultRes.body, null, 2));
  }
  const errorObject = defaultRes.body;
  const url = new URL(errorObject.url);
  errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
  errorObject.message ||= "Server Error";
  errorObject.data ||= error.data;
  errorObject.statusMessage ||= error.statusMessage;
  delete defaultRes.headers["content-type"];
  delete defaultRes.headers["content-security-policy"];
  setResponseHeaders(event, defaultRes.headers);
  const reqHeaders = getRequestHeaders$1(event);
  const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
  const res = isRenderingError ? null : await useNitroApp().localFetch(
    withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject),
    {
      headers: { ...reqHeaders, "x-nuxt-error": "true" },
      redirect: "manual"
    }
  ).catch(() => null);
  if (event.handled) {
    return;
  }
  if (!res) {
    const { template } = await import('../_/error-500.mjs');
    setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
    return send$1(event, template(errorObject));
  }
  const html = await res.text();
  for (const [header, value] of res.headers.entries()) {
    if (header === "set-cookie") {
      appendResponseHeader(event, header, value);
      continue;
    }
    setResponseHeader(event, header, value);
  }
  setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
  return send$1(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send$1(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL$1(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$";
const unsafeChars = /[<>\b\f\n\r\t\0\u2028\u2029]/g;
const reserved = /^(?:do|if|in|for|int|let|new|try|var|byte|case|char|else|enum|goto|long|this|void|with|await|break|catch|class|const|final|float|short|super|throw|while|yield|delete|double|export|import|native|return|switch|throws|typeof|boolean|default|extends|finally|package|private|abstract|continue|debugger|function|volatile|interface|protected|transient|implements|instanceof|synchronized)$/;
const escaped = {
  "<": "\\u003C",
  ">": "\\u003E",
  "/": "\\u002F",
  "\\": "\\\\",
  "\b": "\\b",
  "\f": "\\f",
  "\n": "\\n",
  "\r": "\\r",
  "	": "\\t",
  "\0": "\\0",
  "\u2028": "\\u2028",
  "\u2029": "\\u2029"
};
const objectProtoOwnPropertyNames = Object.getOwnPropertyNames(Object.prototype).sort().join("\0");
function devalue(value) {
  const counts = /* @__PURE__ */ new Map();
  let logNum = 0;
  function log(message) {
    if (logNum < 100) {
      console.warn(message);
      logNum += 1;
    }
  }
  function walk(thing) {
    if (typeof thing === "function") {
      log(`Cannot stringify a function ${thing.name}`);
      return;
    }
    if (counts.has(thing)) {
      counts.set(thing, counts.get(thing) + 1);
      return;
    }
    counts.set(thing, 1);
    if (!isPrimitive(thing)) {
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
        case "Date":
        case "RegExp":
          return;
        case "Array":
          thing.forEach(walk);
          break;
        case "Set":
        case "Map":
          Array.from(thing).forEach(walk);
          break;
        default:
          const proto = Object.getPrototypeOf(thing);
          if (proto !== Object.prototype && proto !== null && Object.getOwnPropertyNames(proto).sort().join("\0") !== objectProtoOwnPropertyNames) {
            if (typeof thing.toJSON !== "function") {
              log(`Cannot stringify arbitrary non-POJOs ${thing.constructor.name}`);
            }
          } else if (Object.getOwnPropertySymbols(thing).length > 0) {
            log(`Cannot stringify POJOs with symbolic keys ${Object.getOwnPropertySymbols(thing).map((symbol) => symbol.toString())}`);
          } else {
            Object.keys(thing).forEach((key) => walk(thing[key]));
          }
      }
    }
  }
  walk(value);
  const names = /* @__PURE__ */ new Map();
  Array.from(counts).filter((entry) => entry[1] > 1).sort((a, b) => b[1] - a[1]).forEach((entry, i) => {
    names.set(entry[0], getName(i));
  });
  function stringify(thing) {
    if (names.has(thing)) {
      return names.get(thing);
    }
    if (isPrimitive(thing)) {
      return stringifyPrimitive(thing);
    }
    const type = getType(thing);
    switch (type) {
      case "Number":
      case "String":
      case "Boolean":
        return `Object(${stringify(thing.valueOf())})`;
      case "RegExp":
        return thing.toString();
      case "Date":
        return `new Date(${thing.getTime()})`;
      case "Array":
        const members = thing.map((v, i) => i in thing ? stringify(v) : "");
        const tail = thing.length === 0 || thing.length - 1 in thing ? "" : ",";
        return `[${members.join(",")}${tail}]`;
      case "Set":
      case "Map":
        return `new ${type}([${Array.from(thing).map(stringify).join(",")}])`;
      default:
        if (thing.toJSON) {
          let json = thing.toJSON();
          if (getType(json) === "String") {
            try {
              json = JSON.parse(json);
            } catch (e) {
            }
          }
          return stringify(json);
        }
        if (Object.getPrototypeOf(thing) === null) {
          if (Object.keys(thing).length === 0) {
            return "Object.create(null)";
          }
          return `Object.create(null,{${Object.keys(thing).map((key) => `${safeKey(key)}:{writable:true,enumerable:true,value:${stringify(thing[key])}}`).join(",")}})`;
        }
        return `{${Object.keys(thing).map((key) => `${safeKey(key)}:${stringify(thing[key])}`).join(",")}}`;
    }
  }
  const str = stringify(value);
  if (names.size) {
    const params = [];
    const statements = [];
    const values = [];
    names.forEach((name, thing) => {
      params.push(name);
      if (isPrimitive(thing)) {
        values.push(stringifyPrimitive(thing));
        return;
      }
      const type = getType(thing);
      switch (type) {
        case "Number":
        case "String":
        case "Boolean":
          values.push(`Object(${stringify(thing.valueOf())})`);
          break;
        case "RegExp":
          values.push(thing.toString());
          break;
        case "Date":
          values.push(`new Date(${thing.getTime()})`);
          break;
        case "Array":
          values.push(`Array(${thing.length})`);
          thing.forEach((v, i) => {
            statements.push(`${name}[${i}]=${stringify(v)}`);
          });
          break;
        case "Set":
          values.push("new Set");
          statements.push(`${name}.${Array.from(thing).map((v) => `add(${stringify(v)})`).join(".")}`);
          break;
        case "Map":
          values.push("new Map");
          statements.push(`${name}.${Array.from(thing).map(([k, v]) => `set(${stringify(k)}, ${stringify(v)})`).join(".")}`);
          break;
        default:
          values.push(Object.getPrototypeOf(thing) === null ? "Object.create(null)" : "{}");
          Object.keys(thing).forEach((key) => {
            statements.push(`${name}${safeProp(key)}=${stringify(thing[key])}`);
          });
      }
    });
    statements.push(`return ${str}`);
    return `(function(${params.join(",")}){${statements.join(";")}}(${values.join(",")}))`;
  } else {
    return str;
  }
}
function getName(num) {
  let name = "";
  do {
    name = chars[num % chars.length] + name;
    num = ~~(num / chars.length) - 1;
  } while (num >= 0);
  return reserved.test(name) ? `${name}0` : name;
}
function isPrimitive(thing) {
  return Object(thing) !== thing;
}
function stringifyPrimitive(thing) {
  if (typeof thing === "string") {
    return stringifyString(thing);
  }
  if (thing === void 0) {
    return "void 0";
  }
  if (thing === 0 && 1 / thing < 0) {
    return "-0";
  }
  const str = String(thing);
  if (typeof thing === "number") {
    return str.replace(/^(-)?0\./, "$1.");
  }
  return str;
}
function getType(thing) {
  return Object.prototype.toString.call(thing).slice(8, -1);
}
function escapeUnsafeChar(c) {
  return escaped[c] || c;
}
function escapeUnsafeChars(str) {
  return str.replace(unsafeChars, escapeUnsafeChar);
}
function safeKey(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? key : escapeUnsafeChars(JSON.stringify(key));
}
function safeProp(key) {
  return /^[_$a-zA-Z][_$a-zA-Z0-9]*$/.test(key) ? `.${key}` : `[${escapeUnsafeChars(JSON.stringify(key))}]`;
}
function stringifyString(str) {
  let result = '"';
  for (let i = 0; i < str.length; i += 1) {
    const char = str.charAt(i);
    const code = char.charCodeAt(0);
    if (char === '"') {
      result += '\\"';
    } else if (char in escaped) {
      result += escaped[char];
    } else if (code >= 55296 && code <= 57343) {
      const next = str.charCodeAt(i + 1);
      if (code <= 56319 && (next >= 56320 && next <= 57343)) {
        result += char + str[++i];
      } else {
        result += `\\u${code.toString(16).toUpperCase()}`;
      }
    } else {
      result += char;
    }
  }
  result += '"';
  return result;
}

function normalizeSiteConfig(config) {
  if (typeof config.indexable !== "undefined")
    config.indexable = String(config.indexable) !== "false";
  if (typeof config.trailingSlash !== "undefined" && !config.trailingSlash)
    config.trailingSlash = String(config.trailingSlash) !== "false";
  if (config.url && !hasProtocol(String(config.url), { acceptRelative: true, strict: false }))
    config.url = withHttps(String(config.url));
  const keys = Object.keys(config).sort((a, b) => a.localeCompare(b));
  const newConfig = {};
  for (const k of keys)
    newConfig[k] = config[k];
  return newConfig;
}
function createSiteConfigStack(options) {
  const debug = options?.debug || false;
  const stack = [];
  function push(input) {
    if (!input || typeof input !== "object" || Object.keys(input).length === 0) {
      return () => {
      };
    }
    if (!input._context && debug) {
      let lastFunctionName = new Error("tmp").stack?.split("\n")[2]?.split(" ")[5];
      if (lastFunctionName?.includes("/"))
        lastFunctionName = "anonymous";
      input._context = lastFunctionName;
    }
    const entry = {};
    for (const k in input) {
      const val = input[k];
      if (typeof val !== "undefined" && val !== "")
        entry[k] = val;
    }
    let idx;
    if (Object.keys(entry).filter((k) => !k.startsWith("_")).length > 0)
      idx = stack.push(entry);
    return () => {
      if (typeof idx !== "undefined") {
        stack.splice(idx - 1, 1);
      }
    };
  }
  function get(options2) {
    const siteConfig = {};
    if (options2?.debug)
      siteConfig._context = {};
    siteConfig._priority = {};
    for (const o in stack.sort((a, b) => (a._priority || 0) - (b._priority || 0))) {
      for (const k in stack[o]) {
        const key = k;
        const val = options2?.resolveRefs ? toValue(stack[o][k]) : stack[o][k];
        if (!k.startsWith("_") && typeof val !== "undefined" && val !== "") {
          siteConfig[k] = val;
          if (typeof stack[o]._priority !== "undefined" && stack[o]._priority !== -1) {
            siteConfig._priority[key] = stack[o]._priority;
          }
          if (options2?.debug)
            siteConfig._context[key] = stack[o]._context?.[key] || stack[o]._context || "anonymous";
        }
      }
    }
    return options2?.skipNormalize ? siteConfig : normalizeSiteConfig(siteConfig);
  }
  return {
    stack,
    push,
    get
  };
}

function envSiteConfig(env) {
  return Object.fromEntries(Object.entries(env).filter(([k]) => k.startsWith("NUXT_SITE_") || k.startsWith("NUXT_PUBLIC_SITE_")).map(([k, v]) => [
    k.replace(/^NUXT_(PUBLIC_)?SITE_/, "").split("_").map((s, i) => i === 0 ? s.toLowerCase() : s[0]?.toUpperCase() + s.slice(1).toLowerCase()).join(""),
    v
  ]));
}

function getSiteConfig(e, _options) {
  e.context.siteConfig = e.context.siteConfig || createSiteConfigStack();
  const options = defu(_options, useRuntimeConfig(e)["nuxt-site-config"], { debug: false });
  return e.context.siteConfig.get(options);
}

const _c0eGq9VvKN57O7D4INiVXnRru42bFGyKzA7Lj1MPQ = defineNitroPlugin(async (nitroApp) => {
  nitroApp.hooks.hook("render:html", async (ctx, { event }) => {
    const routeOptions = getRouteRules(event);
    const isIsland = process.env.NUXT_COMPONENT_ISLANDS && event.path.startsWith("/__nuxt_island");
    event.path;
    const noSSR = event.context.nuxt?.noSSR || routeOptions.ssr === false && !isIsland || (false);
    if (noSSR) {
      const siteConfig = Object.fromEntries(
        Object.entries(getSiteConfig(event)).map(([k, v]) => [k, toValue(v)])
      );
      ctx.body.push(`<script>window.__NUXT_SITE_CONFIG__=${devalue(siteConfig)}<\/script>`);
    }
  });
});

const DRIVER_NAME = "lru-cache";
const lruCacheDriver = defineDriver((opts = {}) => {
  const cache = new LRUCache({
    max: 1e3,
    sizeCalculation: opts.maxSize || opts.maxEntrySize ? (value, key) => {
      return key.length + byteLength(value);
    } : void 0,
    ...opts
  });
  return {
    name: DRIVER_NAME,
    options: opts,
    getInstance: () => cache,
    hasItem(key) {
      return cache.has(key);
    },
    getItem(key) {
      return cache.get(key) ?? null;
    },
    getItemRaw(key) {
      return cache.get(key) ?? null;
    },
    setItem(key, value) {
      cache.set(key, value);
    },
    setItemRaw(key, value) {
      cache.set(key, value);
    },
    removeItem(key) {
      cache.delete(key);
    },
    getKeys() {
      return [...cache.keys()];
    },
    clear() {
      cache.clear();
    },
    dispose() {
      cache.clear();
    }
  };
});
function byteLength(value) {
  if (typeof Buffer !== "undefined") {
    try {
      return Buffer.byteLength(value);
    } catch {
    }
  }
  try {
    return typeof value === "string" ? value.length : JSON.stringify(value).length;
  } catch {
  }
  return 0;
}

const htmlPayloadCache = createStorage({
  // short cache time so we don't need many entries at runtime
  driver: lruCacheDriver({ max: 50 })
});
const fontCache = createStorage({
  driver: lruCacheDriver({ max: 10 })
});
const emojiCache = createStorage({
  driver: lruCacheDriver({ max: 1e3 })
});

function resolveSitePath(pathOrUrl, options) {
  let path = pathOrUrl;
  if (hasProtocol(pathOrUrl, { strict: false, acceptRelative: true })) {
    const parsed = parseURL(pathOrUrl);
    path = parsed.pathname;
  }
  const base = withLeadingSlash(options.base || "/");
  if (base !== "/" && path.startsWith(base)) {
    path = path.slice(base.length);
  }
  let origin = withoutTrailingSlash(options.absolute ? options.siteUrl : "");
  if (base !== "/" && origin.endsWith(base)) {
    origin = origin.slice(0, origin.indexOf(base));
  }
  const baseWithOrigin = options.withBase ? withBase(base, origin || "/") : origin;
  const resolvedUrl = withBase(path, baseWithOrigin);
  return path === "/" && !options.withBase ? withTrailingSlash(resolvedUrl) : fixSlashes(options.trailingSlash, resolvedUrl);
}
const fileExtensions = [
  // Images
  "jpg",
  "jpeg",
  "png",
  "gif",
  "bmp",
  "webp",
  "svg",
  "ico",
  // Documents
  "pdf",
  "doc",
  "docx",
  "xls",
  "xlsx",
  "ppt",
  "pptx",
  "txt",
  "md",
  "markdown",
  // Archives
  "zip",
  "rar",
  "7z",
  "tar",
  "gz",
  // Audio
  "mp3",
  "wav",
  "flac",
  "ogg",
  "opus",
  "m4a",
  "aac",
  "midi",
  "mid",
  // Video
  "mp4",
  "avi",
  "mkv",
  "mov",
  "wmv",
  "flv",
  "webm",
  // Web
  "html",
  "css",
  "js",
  "json",
  "xml",
  "tsx",
  "jsx",
  "ts",
  "vue",
  "svelte",
  "xsl",
  "rss",
  "atom",
  // Programming
  "php",
  "py",
  "rb",
  "java",
  "c",
  "cpp",
  "h",
  "go",
  // Data formats
  "csv",
  "tsv",
  "sql",
  "yaml",
  "yml",
  // Fonts
  "woff",
  "woff2",
  "ttf",
  "otf",
  "eot",
  // Executables/Binaries
  "exe",
  "msi",
  "apk",
  "ipa",
  "dmg",
  "iso",
  "bin",
  // Scripts/Config
  "bat",
  "cmd",
  "sh",
  "env",
  "htaccess",
  "conf",
  "toml",
  "ini",
  // Package formats
  "deb",
  "rpm",
  "jar",
  "war",
  // E-books
  "epub",
  "mobi",
  // Common temporary/backup files
  "log",
  "tmp",
  "bak",
  "old",
  "sav"
];
function isPathFile(path) {
  const lastSegment = path.split("/").pop();
  const ext = (lastSegment || path).match(/\.[0-9a-z]+$/i)?.[0];
  return ext && fileExtensions.includes(ext.replace(".", ""));
}
function fixSlashes(trailingSlash, pathOrUrl) {
  const $url = parseURL(pathOrUrl);
  if (isPathFile($url.pathname))
    return pathOrUrl;
  const fixedPath = trailingSlash ? withTrailingSlash($url.pathname) : withoutTrailingSlash($url.pathname);
  return `${$url.protocol ? `${$url.protocol}//` : ""}${$url.host || ""}${fixedPath}${$url.search || ""}${$url.hash || ""}`;
}

function useBase(base, handler) {
  base = withoutTrailingSlash(base);
  if (!base || base === "/") {
    return handler;
  }
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _path = event._path || event.node.req.url || "/";
    event._path = withoutBase(event.path || "/", base);
    event.node.req.url = event._path;
    try {
      return await handler(event);
    } finally {
      event._path = event.node.req.url = _path;
    }
  });
}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}
function getRouterParams(event, opts = {}) {
  let params = event.context.params || {};
  if (opts.decode) {
    params = { ...params };
    for (const key in params) {
      params[key] = decode$2(params[key]);
    }
  }
  return params;
}
function getRouterParam(event, name, opts = {}) {
  const params = getRouterParams(event, opts);
  return params[name];
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const MIMES = {
  html: "text/html"};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function defaultContentType(event, type) {
  if (event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  if (!isEventHandler(input)) {
    console.warn(
      "[h3] Implicit event handler conversion is deprecated. Use `eventHandler()` or `fromNodeMiddleware()` to define event handlers.",
      "",
      `
     Handler: ${input}`
    );
  }
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function getNitroOrigin(e) {
  process.env.NITRO_SSL_CERT;
  process.env.NITRO_SSL_KEY;
  let host = process.env.NITRO_HOST || process.env.HOST || false;
  let port = false;
  let protocol = "https" ;
  if (e) {
    host = getRequestHost(e, { xForwardedHost: true }) || host;
    protocol = getRequestProtocol(e, { xForwardedProto: true }) || protocol;
  }
  if (typeof host === "string" && host.includes(":")) {
    port = host.split(":").pop();
    host = host.split(":")[0] || false;
  }
  port = port ? `:${port}` : "";
  return withTrailingSlash(`${protocol}://${host}${port}`);
}

function createSitePathResolver(e, options = {}) {
  const siteConfig = getSiteConfig(e);
  const nitroOrigin = getNitroOrigin(e);
  const nuxtBase = useRuntimeConfig(e).app.baseURL || "/";
  return (path) => {
    return resolveSitePath(path, {
      ...options,
      siteUrl: options.canonical !== false || false ? siteConfig.url : nitroOrigin,
      trailingSlash: siteConfig.trailingSlash,
      base: nuxtBase
    });
  };
}

function detectBase64MimeType(data) {
  const signatures = {
    "R0lGODdh": "image/gif",
    "R0lGODlh": "image/gif",
    "iVBORw0KGgo": "image/png",
    "/9j/": "image/jpeg",
    "UklGR": "image/webp",
    "AAABAA": "image/x-icon"
  };
  for (const s in signatures) {
    if (data.startsWith(s)) {
      return signatures[s];
    }
  }
  return "image/svg+xml";
}
function toBase64Image(data) {
  const base64 = typeof data === "string" ? data : Buffer.from(data).toString("base64");
  const type = detectBase64MimeType(base64);
  return `data:${type};base64,${base64}`;
}
function filterIsOgImageOption(key) {
  const keys = [
    "url",
    "extension",
    "width",
    "height",
    "fonts",
    "alt",
    "props",
    "renderer",
    "html",
    "component",
    "renderer",
    "emojis",
    "_query",
    "satori",
    "resvg",
    "sharp",
    "screenshot",
    "cacheMaxAgeSeconds"
  ];
  return keys.includes(key);
}
function separateProps(options, ignoreKeys = []) {
  options = options || {};
  const _props = defu(options.props, Object.fromEntries(
    Object.entries({ ...options }).filter(([k]) => !filterIsOgImageOption(k) && !ignoreKeys.includes(k))
  ));
  const props = {};
  Object.entries(_props).forEach(([key, val]) => {
    props[key.replace(/-([a-z])/g, (g) => String(g[1]).toUpperCase())] = val;
  });
  return {
    ...Object.fromEntries(
      Object.entries({ ...options }).filter(([k]) => filterIsOgImageOption(k) || ignoreKeys.includes(k))
    ),
    props
  };
}
function normaliseFontInput(fonts) {
  return fonts.map((f) => {
    if (typeof f === "string") {
      const vals = f.split(":");
      const includesStyle = vals.length === 3;
      let name, weight, style;
      if (includesStyle) {
        name = vals[0];
        style = vals[1];
        weight = vals[2];
      } else {
        name = vals[0];
        weight = vals[1];
      }
      return {
        cacheKey: f,
        name,
        weight: weight || 400,
        style: style || "normal",
        path: void 0
      };
    }
    return {
      cacheKey: f.key || `${f.name}:${f.style}:${f.weight}`,
      style: "normal",
      weight: 400,
      ...f
    };
  });
}

const theme = {"container":{"center":true,"padding":"2rem","screens":{"2xl":"1400px"}}};

function useSiteConfig(e, _options) {
  return getSiteConfig(e, _options);
}

function htmlDecodeQuotes(html) {
  return html.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#x27;/g, "'");
}
function decodeHtml(html) {
  return html.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&cent;/g, "\xA2").replace(/&pound;/g, "\xA3").replace(/&yen;/g, "\xA5").replace(/&euro;/g, "\u20AC").replace(/&copy;/g, "\xA9").replace(/&reg;/g, "\xAE").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#x27;/g, "'").replace(/&#x2F;/g, "/").replace(/&#(\d+);/g, (full, int) => {
    return String.fromCharCode(Number.parseInt(int));
  }).replace(/&amp;/g, "&");
}
function decodeObjectHtmlEntities(obj) {
  Object.entries(obj).forEach(([key, value]) => {
    if (typeof value === "string")
      obj[key] = decodeHtml(value);
  });
  return obj;
}

function fetchIsland(e, component, props) {
  const hashId = hash$1([component, props]).replaceAll("_", "-");
  return e.$fetch(`/__nuxt_island/${component}_${hashId}.json`, {
    params: {
      props: JSON.stringify(props)
    }
  });
}
function withoutQuery$1(path) {
  return path.split("?")[0];
}
function createNitroRouteRuleMatcher$1() {
  const { nitro, app } = useRuntimeConfig();
  const _routeRulesMatcher = toRouteMatcher(
    createRouter$1({
      routes: Object.fromEntries(
        Object.entries(nitro?.routeRules || {}).map(([path, rules]) => [withoutTrailingSlash(path), rules])
      )
    })
  );
  return (path) => {
    return defu({}, ..._routeRulesMatcher.matchAll(
      // radix3 does not support trailing slashes
      withoutBase(withoutTrailingSlash(withoutQuery$1(path)), app.baseURL)
    ).reverse());
  };
}

const logger$1 = createConsola({
  defaults: {
    tag: "Nuxt OG Image"
  }
});

const componentNames = [{"hash":"p9SRglF9QLydAVFQ9UbxoKq86YV8EwP8TtGTIL5PWqE","pascalName":"OgImageShadcnDocs","kebabName":"og-image-shadcn-docs","path":"/home/runner/work/website/website/node_modules/.pnpm/shadcn-docs-nuxt@1.1.4_@netlify+blobs@10.0.8_@unhead+vue@2.0.17_vue@3.5.18_typescript@5_d246e41fb1e1496a46a759a5a7da55c2/node_modules/shadcn-docs-nuxt/components/OgImage/ShadcnDocs.vue","category":"app"},{"hash":"lqi2TIJIQMafRl6atyAjEmgaOb13hjqfbfUGe7PXhOw","pascalName":"BrandedLogoDVue","kebabName":"branded-logo-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/BrandedLogo.d.vue.ts","category":"community","credits":"Full Stack Heroes <https://fullstackheroes.com/>"},{"hash":"SOHaoKfoo4fUkREsCFGw8ewxkl4-XkkHkug2VwYRtFM","pascalName":"BrandedLogo","kebabName":"branded-logo","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/BrandedLogo.vue","category":"community"},{"hash":"BMTMwASJKH3AG9ey0Y845iqbPNO7HjNX5eW2U2psVTE","pascalName":"FrameDVue","kebabName":"frame-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Frame.d.vue.ts","category":"community","credits":"@arashsheyda <https://github.com/arashsheyda>"},{"hash":"tFoYPh0fXaZR3uXybAqFEOGnQuQsvz-E-Yq-CtrFlIY","pascalName":"Frame","kebabName":"frame","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Frame.vue","category":"community"},{"hash":"XHXMYyA3oPy1eN81p4R-wv8k8tkHNooxhCRL8Zs1Pz0","pascalName":"NuxtDVue","kebabName":"nuxt-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Nuxt.d.vue.ts","category":"community"},{"hash":"NPQTTXYQ8toXx5OaJ1VlRUUcxy1SNOxg-FoM7C08ZPM","pascalName":"Nuxt","kebabName":"nuxt","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Nuxt.vue","category":"community"},{"hash":"jGeID02J5-Tz9qaGIsRVZfJSXVQS9q-3V2Qnw65GQMg","pascalName":"NuxtSeoDVue","kebabName":"nuxt-seo-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/NuxtSeo.d.vue.ts","category":"community"},{"hash":"VAHSTZlVcPHzkozocV1iTnwc4-YttdoOkHsYfoSgDZ4","pascalName":"NuxtSeo","kebabName":"nuxt-seo","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/NuxtSeo.vue","category":"community"},{"hash":"XHXMYyA3oPy1eN81p4R-wv8k8tkHNooxhCRL8Zs1Pz0","pascalName":"PergelDVue","kebabName":"pergel-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Pergel.d.vue.ts","category":"community"},{"hash":"8CNn4yU043gQFqO-sZNDPz9GKED-h7ahXJ-61c9ThHM","pascalName":"Pergel","kebabName":"pergel","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Pergel.vue","category":"community"},{"hash":"7-N5uiZ77GftW16gAKUKdbC2kTqoiWjlYDsNWxCsCG4","pascalName":"SimpleBlogDVue","kebabName":"simple-blog-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/SimpleBlog.d.vue.ts","category":"community"},{"hash":"b-Juo-FXQepo6SOCnA478MTAqbXNZuve6-MzHgTKA7s","pascalName":"SimpleBlog","kebabName":"simple-blog","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/SimpleBlog.vue","category":"community"},{"hash":"ahhiG3dVaeRX0C50qOnvcUsjBRro4ufe-6jzsUbVxBY","pascalName":"UnJsDVue","kebabName":"un-js-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/UnJs.d.vue.ts","category":"community","credits":"UnJS <https://unjs.io/>"},{"hash":"vRUm5ru-64PEHIGsBby6-vCgLBg7iUJfvFKL6VuCXtI","pascalName":"UnJs","kebabName":"un-js","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/UnJs.vue","category":"community"},{"hash":"pzp5dWaNkZa2Gbj-RXhoDiBahvrINMjPJC9-Vs2OtxE","pascalName":"WaveDVue","kebabName":"wave-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Wave.d.vue.ts","category":"community","credits":"Full Stack Heroes <https://fullstackheroes.com/>"},{"hash":"hq07GBU-Yd16ICfETt8SfSxfaYj3qBmDAiQkTcv89nw","pascalName":"Wave","kebabName":"wave","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/Wave.vue","category":"community"},{"hash":"hsZbjduIx-cfHCcgbOY44VlwFWt5bfWv-VxiGiUifDs","pascalName":"WithEmojiDVue","kebabName":"with-emoji-d-vue","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/WithEmoji.d.vue.ts","category":"community","credits":"Full Stack Heroes <https://fullstackheroes.com/>"},{"hash":"zSwOodBXcjwS1qvFqGBJqitTEEnrvVfwQYkTeIxNpws","pascalName":"WithEmoji","kebabName":"with-emoji","path":"/home/runner/work/website/website/node_modules/.pnpm/nuxt-og-image@5.1.12_@unhead+vue@2.0.17_vue@3.5.18_typescript@5.9.3___h3@1.15.4_magicas_f276b007552b05619b60916dccd455c2/node_modules/nuxt-og-image/dist/runtime/app/components/Templates/Community/WithEmoji.vue","category":"community"}];

function normaliseOptions(_options) {
  const options = { ..._options };
  if (!options)
    return options;
  if (options.component && componentNames) {
    const originalName = options.component;
    for (const component of componentNames) {
      if (component.pascalName.endsWith(originalName) || component.kebabName.endsWith(originalName)) {
        options.component = component.pascalName;
        break;
      }
    }
  } else if (!options.component) {
    options.component = componentNames[0]?.pascalName;
  }
  return options;
}

function useOgImageRuntimeConfig(e) {
  const c = useRuntimeConfig(e);
  return {
    ...c["nuxt-og-image"],
    app: {
      baseURL: c.app.baseURL
    }
  };
}

const satoriRendererInstance = { instance: void 0 };
const chromiumRendererInstance = { instance: void 0 };
async function useSatoriRenderer() {
  satoriRendererInstance.instance = satoriRendererInstance.instance || await import('../_/renderer.mjs').then((m) => m.default);
  return satoriRendererInstance.instance;
}
async function useChromiumRenderer() {
  chromiumRendererInstance.instance = chromiumRendererInstance.instance || await import('../_/empty.mjs').then((m) => m.default);
  return chromiumRendererInstance.instance;
}

function resolvePathCacheKey(e, path) {
  const siteConfig = useSiteConfig(e, {
    resolveRefs: true
  });
  const basePath = withoutTrailingSlash(withoutLeadingSlash(normalizeKey$2(path)));
  return [
    !basePath || basePath === "/" ? "index" : basePath,
    hash$1([
      basePath,
      siteConfig.url,
      hash$1(getQuery(e))
    ])
  ].join(":");
}
async function resolveContext(e) {
  const runtimeConfig = useOgImageRuntimeConfig();
  const resolvePathWithBase = createSitePathResolver(e, {
    absolute: false,
    withBase: true
  });
  const path = resolvePathWithBase(parseURL(e.path).pathname);
  const extension = path.split(".").pop();
  if (!extension) {
    return createError$2({
      statusCode: 400,
      statusMessage: `[Nuxt OG Image] Missing OG Image type.`
    });
  }
  if (!["png", "jpeg", "jpg", "svg", "html", "json"].includes(extension)) {
    return createError$2({
      statusCode: 400,
      statusMessage: `[Nuxt OG Image] Unknown OG Image type ${extension}.`
    });
  }
  const query = getQuery(e);
  let queryParams = {};
  for (const k in query) {
    const v = String(query[k]);
    if (!v)
      continue;
    if (v.startsWith("{")) {
      try {
        queryParams[k] = JSON.parse(v);
      } catch (error) {
      }
    } else {
      queryParams[k] = v;
    }
  }
  queryParams = separateProps(queryParams);
  let basePath = withoutTrailingSlash(
    path.replace(`/__og-image__/image`, "").replace(`/__og-image__/static`, "").replace(`/og.${extension}`, "")
  );
  if (queryParams._query && typeof queryParams._query === "object")
    basePath = withQuery(basePath, queryParams._query);
  const isDebugJsonPayload = extension === "json" && runtimeConfig.debug;
  const key = resolvePathCacheKey(e, basePath);
  let options = queryParams.options;
  if (!options) {
    if (!options) {
      const payload = await fetchPathHtmlAndExtractOptions(e, basePath, key);
      if (payload instanceof Error)
        return payload;
      options = payload;
    }
  }
  delete queryParams.options;
  const routeRuleMatcher = createNitroRouteRuleMatcher$1();
  const routeRules = routeRuleMatcher(basePath);
  if (typeof routeRules.ogImage === "undefined" && !options) {
    return createError$2({
      statusCode: 400,
      statusMessage: "The route is missing the Nuxt OG Image payload or route rules."
    });
  }
  const ogImageRouteRules = separateProps(routeRules.ogImage);
  options = defu(queryParams, options, ogImageRouteRules, runtimeConfig.defaults);
  if (!options) {
    return createError$2({
      statusCode: 404,
      statusMessage: "[Nuxt OG Image] OG Image not found."
    });
  }
  let renderer;
  switch (options.renderer) {
    case "satori":
      renderer = await useSatoriRenderer();
      break;
    case "chromium":
      renderer = await useChromiumRenderer();
      break;
  }
  if (!renderer || renderer.__mock__) {
    throw createError$2({
      statusCode: 400,
      statusMessage: `[Nuxt OG Image] Renderer ${options.renderer} is not enabled.`
    });
  }
  const unocss = await createGenerator({ theme }, {
    presets: [
      presetWind()
    ]
  });
  const ctx = {
    unocss,
    e,
    key,
    renderer,
    isDebugJsonPayload,
    runtimeConfig,
    publicStoragePath: runtimeConfig.publicStoragePath,
    extension,
    basePath,
    options: normaliseOptions(options),
    _nitro: useNitroApp()
  };
  await ctx._nitro.hooks.callHook("nuxt-og-image:context", ctx);
  return ctx;
}
const PAYLOAD_REGEX = /<script.+id="nuxt-og-image-options"[^>]*>(.+?)<\/script>/;
function getPayloadFromHtml(html) {
  const match = String(html).match(PAYLOAD_REGEX);
  return match ? String(match[1]) : null;
}
function extractAndNormaliseOgImageOptions(html) {
  const _payload = getPayloadFromHtml(html);
  let options = false;
  try {
    const payload2 = parse$2(_payload || "{}");
    Object.entries(payload2).forEach(([key, value]) => {
      if (!value && value !== 0)
        delete payload2[key];
    });
    options = payload2;
  } catch (e) {
  }
  if (options && typeof options?.props?.description === "undefined") {
    const description = html.match(/<meta[^>]+name="description"[^>]*>/)?.[0];
    if (description) {
      const [, content] = description.match(/content="([^"]+)"/) || [];
      if (content && !options.props.description)
        options.props.description = content;
    }
  }
  const payload = decodeObjectHtmlEntities(options || {});
  return payload;
}
async function doFetchWithErrorHandling(fetch, path) {
  const res = await fetch(path, {
    redirect: "follow",
    headers: {
      accept: "text/html"
    }
  }).catch((err) => {
    return err;
  });
  let errorDescription;
  if (res.status >= 300 && res.status < 400) {
    if (res.headers.has("location")) {
      return await doFetchWithErrorHandling(fetch, res.headers.get("location") || "");
    }
    errorDescription = `${res.status} redirected to ${res.headers.get("location") || "unknown"}`;
  } else if (res.status >= 500) {
    errorDescription = `${res.status} error: ${res.statusText}`;
  }
  if (errorDescription) {
    return [null, createError$2({
      statusCode: 500,
      statusMessage: `[Nuxt OG Image] Failed to parse \`${path}\` for og-image extraction. ${errorDescription}`
    })];
  }
  if (res._data) {
    return [res._data, null];
  } else if (res.text) {
    return [await res.text(), null];
  }
  return ["", null];
}
async function fetchPathHtmlAndExtractOptions(e, path, key) {
  const cachedHtmlPayload = await htmlPayloadCache.getItem(key);
  if (cachedHtmlPayload && cachedHtmlPayload.expiresAt < Date.now())
    return cachedHtmlPayload.value;
  let _payload = null;
  let [html, err] = await doFetchWithErrorHandling(e.fetch, path);
  if (err) {
    logger$1.warn(err);
  } else {
    _payload = getPayloadFromHtml(html);
  }
  if (!_payload) {
    const [fallbackHtml, err2] = await doFetchWithErrorHandling(globalThis.$fetch.raw, path);
    if (err2) {
      return err2;
    }
    _payload = getPayloadFromHtml(fallbackHtml);
    if (_payload) {
      html = fallbackHtml;
    }
  }
  if (!html) {
    return createError$2({
      statusCode: 500,
      statusMessage: `[Nuxt OG Image] Failed to read the path ${path} for og-image extraction, returning no HTML.`
    });
  }
  if (!_payload) {
    const payload2 = extractAndNormaliseOgImageOptions(html);
    if (payload2 && typeof payload2 === "object" && payload2.socialPreview?.og?.image) {
      const image = payload2.socialPreview.og.image;
      const p = {
        custom: true,
        url: typeof image === "string" ? image : image
      };
      if (typeof image === "object" && image["image:width"]) {
        p.width = image["image:width"];
      }
      if (typeof image === "object" && image["image:height"]) {
        p.height = image["image:height"];
      }
      return p;
    }
    return createError$2({
      statusCode: 500,
      statusMessage: `[Nuxt OG Image] HTML response from ${path} is missing the #nuxt-og-image-options script tag. Make sure you have defined an og image for this page.`
    });
  }
  const payload = extractAndNormaliseOgImageOptions(html);
  if (payload) {
    await htmlPayloadCache.setItem(key, {
      // 60 minutes for prerender, 10 seconds for runtime
      expiresAt: Date.now() + 1e3 * (10),
      value: payload
    });
  }
  return typeof payload === "object" ? payload : createError$2({
    statusCode: 500,
    statusMessage: "[Nuxt OG Image] Invalid payload type."
  });
}

const _DjK0ePnUIeriVTcFrzuHdCOnQKZ8rQhOmbZVSI2Ag6o = defineNitroPlugin(async (nitro) => {
  return;
});

function useI18nContext(event) {
  if (event.context.nuxtI18n == null) {
    throw new Error("Nuxt I18n server context has not been set up yet.");
  }
  return event.context.nuxtI18n;
}
function tryUseI18nContext(event) {
  return event.context.nuxtI18n;
}
new Headers({ "x-nuxt-i18n": "internal" });
function createI18nContext() {
  return {
    messages: {},
    slp: {},
    localeConfigs: {},
    trackMap: {},
    vueI18nOptions: void 0,
    trackKey(key, locale) {
      this.trackMap[locale] ??= /* @__PURE__ */ new Set();
      this.trackMap[locale].add(key);
    }
  };
}

/*!
  * shared v11.1.11
  * (c) 2025 kazuya kawaguchi
  * Released under the MIT License.
  */
const _create = Object.create;
const create = (obj = null) => _create(obj);
/* eslint-enable */
/**
 * Useful Utilities By Evan you
 * Modified by kazuya kawaguchi
 * MIT License
 * https://github.com/vuejs/vue-next/blob/master/packages/shared/src/index.ts
 * https://github.com/vuejs/vue-next/blob/master/packages/shared/src/codeframe.ts
 */
const isArray = Array.isArray;
const isFunction = (val) => typeof val === 'function';
const isString = (val) => typeof val === 'string';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isObject = (val) => val !== null && typeof val === 'object';
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);

const isNotObjectOrIsArray = (val) => !isObject(val) || isArray(val);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function deepCopy(src, des) {
    // src and des should both be objects, and none of them can be a array
    if (isNotObjectOrIsArray(src) || isNotObjectOrIsArray(des)) {
        throw new Error('Invalid value');
    }
    const stack = [{ src, des }];
    while (stack.length) {
        const { src, des } = stack.pop();
        // using `Object.keys` which skips prototype properties
        Object.keys(src).forEach(key => {
            if (key === '__proto__') {
                return;
            }
            // if src[key] is an object/array, set des[key]
            // to empty object/array to prevent setting by reference
            if (isObject(src[key]) && !isObject(des[key])) {
                des[key] = Array.isArray(src[key]) ? [] : create();
            }
            if (isNotObjectOrIsArray(des[key]) || isNotObjectOrIsArray(src[key])) {
                // replace with src[key] when:
                // src[key] or des[key] is not an object, or
                // src[key] or des[key] is an array
                des[key] = src[key];
            }
            else {
                // src[key] and des[key] are both objects, merge them
                stack.push({ src: src[key], des: des[key] });
            }
        });
    }
}

function matchBrowserLocale(locales, browserLocales) {
  const matchedLocales = [];
  for (const [index, browserCode] of browserLocales.entries()) {
    const matchedLocale = locales.find((l) => l.language?.toLowerCase() === browserCode.toLowerCase());
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 1 - index / browserLocales.length });
      break;
    }
  }
  for (const [index, browserCode] of browserLocales.entries()) {
    const languageCode = browserCode.split("-")[0].toLowerCase();
    const matchedLocale = locales.find((l) => l.language?.split("-")[0].toLowerCase() === languageCode);
    if (matchedLocale) {
      matchedLocales.push({ code: matchedLocale.code, score: 0.999 - index / browserLocales.length });
      break;
    }
  }
  return matchedLocales;
}
function compareBrowserLocale(a, b) {
  if (a.score === b.score) {
    return b.code.length - a.code.length;
  }
  return b.score - a.score;
}
function findBrowserLocale(locales, browserLocales) {
  const matchedLocales = matchBrowserLocale(
    locales.map((l) => ({ code: l.code, language: l.language || l.code })),
    browserLocales
  );
  return matchedLocales.sort(compareBrowserLocale).at(0)?.code ?? "";
}

// @ts-nocheck
const localeCodes =  [
  "zh"
];
const localeLoaders = {
  zh: []
};
const vueI18nConfigs = [
  () => import('../_/i18n.config.mjs' /* webpackChunkName: "config_i18n_46config_46ts_776ee377" */),
  () => import('../_/i18n.config2.mjs' /* webpackChunkName: "config_i18n_46config_46ts_260db425" */)
];
const normalizedLocales = [
  {
    code: "zh",
    name: "简体中文",
    language: "zh-CN",
    _hreflang: "zh-CN",
    _sitemap: "zh-CN"
  }
];

function createLocaleConfigs(fallbackLocale) {
  const localeConfigs = {};
  for (const locale of localeCodes) {
    const fallbacks = getFallbackLocaleCodes(fallbackLocale, [locale]);
    const cacheable = isLocaleWithFallbacksCacheable(locale, fallbacks);
    localeConfigs[locale] = { fallbacks, cacheable };
  }
  return localeConfigs;
}
function getFallbackLocaleCodes(fallback, locales) {
  if (fallback === false) return [];
  if (isArray(fallback)) return fallback;
  let fallbackLocales = [];
  if (isString(fallback)) {
    if (locales.every((locale) => locale !== fallback)) {
      fallbackLocales.push(fallback);
    }
    return fallbackLocales;
  }
  const targets = [...locales, "default"];
  for (const locale of targets) {
    if (locale in fallback == false) continue;
    fallbackLocales = [...fallbackLocales, ...fallback[locale].filter(Boolean)];
  }
  return fallbackLocales;
}
function isLocaleCacheable(locale) {
  return localeLoaders[locale] != null && localeLoaders[locale].every((loader) => loader.cache !== false);
}
function isLocaleWithFallbacksCacheable(locale, fallbackLocales) {
  return isLocaleCacheable(locale) && fallbackLocales.every((fallbackLocale) => isLocaleCacheable(fallbackLocale));
}
function getDefaultLocaleForDomain(host) {
  return normalizedLocales.find((l) => !!l.defaultForDomains?.includes(host))?.code;
}
const isSupportedLocale = (locale) => localeCodes.includes(locale || "");

const __nuxtMock = { runWithContext: async (fn) => await fn() };
const merger$1 = createDefu((obj, key, value) => {
  if (key === "messages" || key === "datetimeFormats" || key === "numberFormats") {
    obj[key] ??= create(null);
    deepCopy(value, obj[key]);
    return true;
  }
});
async function loadVueI18nOptions(vueI18nConfigs) {
  const nuxtApp = __nuxtMock;
  let vueI18nOptions = { messages: create(null) };
  for (const configFile of vueI18nConfigs) {
    const resolver = await configFile().then((x) => x.default);
    const resolved = isFunction(resolver) ? await nuxtApp.runWithContext(() => resolver()) : resolver;
    vueI18nOptions = merger$1(create(null), resolved, vueI18nOptions);
  }
  vueI18nOptions.fallbackLocale ??= false;
  return vueI18nOptions;
}
const isModule = (val) => toTypeString(val) === "[object Module]";
const isResolvedModule = (val) => isModule(val) || true;
async function getLocaleMessages(locale, loader) {
  const nuxtApp = __nuxtMock;
  try {
    const getter = await nuxtApp.runWithContext(loader.load).then((x) => isResolvedModule(x) ? x.default : x);
    return isFunction(getter) ? await nuxtApp.runWithContext(() => getter(locale)) : getter;
  } catch (e) {
    throw new Error(`Failed loading locale (${locale}): ` + e.message);
  }
}
async function getLocaleMessagesMerged(locale, loaders = []) {
  const nuxtApp = __nuxtMock;
  const merged = {};
  for (const loader of loaders) {
    deepCopy(await nuxtApp.runWithContext(async () => await getLocaleMessages(locale, loader)), merged);
  }
  return merged;
}

const setupVueI18nOptions = async (defaultLocale) => {
  const options = await loadVueI18nOptions(vueI18nConfigs);
  options.locale = defaultLocale || options.locale || "en-US";
  options.defaultLocale = defaultLocale;
  options.fallbackLocale ??= false;
  options.messages ??= {};
  for (const locale of localeCodes) {
    options.messages[locale] ??= {};
  }
  return options;
};

const appHead = {"meta":[{"name":"viewport","content":"width=device-width, initial-scale=1"},{"charset":"utf-8"},{"name":"google-site-verification","content":"hqPb74AFcL3IXb7yqjOcOY9v6MJkevvVm-IUSFc9GOk"}],"link":[],"style":[],"script":[],"noscript":[]};

const appRootTag = "div";

const appRootAttrs = {"id":"__nuxt"};

const appTeleportTag = "div";

const appTeleportAttrs = {"id":"teleports"};

const appId = "nuxt-app";

function useRuntimeI18n(nuxtApp) {
  {
    return useRuntimeConfig().public.i18n;
  }
}
function useI18nDetection(nuxtApp) {
  const detectBrowserLanguage = useRuntimeI18n().detectBrowserLanguage;
  const detect = detectBrowserLanguage || {};
  return {
    ...detect,
    enabled: !!detectBrowserLanguage,
    cookieKey: detect.cookieKey || "i18n_redirected"
  };
}
function resolveRootRedirect(config) {
  if (!config) return void 0;
  return {
    path: "/" + (isString(config) ? config : config.path).replace(/^\//, ""),
    code: !isString(config) && config.statusCode || 302
  };
}
function toArray(value) {
  return Array.isArray(value) ? value : [value];
}

const separator = "___";
const pathLanguageParser = createPathIndexLanguageParser(0);
const getLocaleFromRoutePath = (path) => pathLanguageParser(path);
const getLocaleFromRouteName = (name) => name.split(separator).at(1) ?? "";
function normalizeInput(input) {
  return typeof input !== "object" ? String(input) : String(input?.name || input?.path || "");
}
function getLocaleFromRoute(route) {
  const input = normalizeInput(route);
  return input[0] === "/" ? getLocaleFromRoutePath(input) : getLocaleFromRouteName(input);
}

function matchDomainLocale(locales, host, pathLocale) {
  const normalizeDomain = (domain = "") => domain.replace(/https?:\/\//, "");
  const matches = locales.filter(
    (locale) => normalizeDomain(locale.domain) === host || toArray(locale.domains).includes(host)
  );
  if (matches.length <= 1) {
    return matches[0]?.code;
  }
  return (
    // match by current path locale
    matches.find((l) => l.code === pathLocale)?.code || // fallback to default locale for the domain
    matches.find((l) => l.defaultForDomains?.includes(host) ?? l.domainDefault)?.code
  );
}

function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = {};
  const opt = options || {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const getCookieLocale = (event, cookieName) => {
  const cookieValue = getRequestHeader(event, "cookie") || "";
  return parse(cookieValue)[cookieName];
};
const getRouteLocale = (event, route) => getLocaleFromRoute(route);
const getHeaderLocale = (event) => {
  return findBrowserLocale(normalizedLocales, parseAcceptLanguage(getRequestHeader(event, "accept-language") || ""));
};
const getHostLocale = (event, path, domainLocales) => {
  const host = getRequestURL(event, { xForwardedHost: true }).host;
  const locales = normalizedLocales.map((l) => ({
    ...l,
    domain: domainLocales[l.code]?.domain ?? l.domain
  }));
  return matchDomainLocale(locales, host, getLocaleFromRoutePath(path));
};
const useDetectors = (event, config, nuxtApp) => {
  if (!event) {
    throw new Error("H3Event is required for server-side locale detection");
  }
  const runtimeI18n = useRuntimeI18n();
  return {
    cookie: () => getCookieLocale(event, config.cookieKey),
    header: () => getHeaderLocale(event) ,
    navigator: () => void 0,
    host: (path) => getHostLocale(event, path, runtimeI18n.domainLocales),
    route: (path) => getRouteLocale(event, path)
  };
};

// Generated by @nuxtjs/i18n
const pathToI18nConfig = {
  "/": {
    "zh": "/"
  },
  "/packages": {
    "zh": "/packages"
  },
  "/:slug(.*)*": {
    "zh": "/:slug(.*)*"
  },
  "/changelog": {
    "zh": "/changelog"
  },
  "/relations": {
    "zh": "/relations"
  },
  "/ndefined": {
    "zh": "/ndefined"
  }
};
const i18nPathToPath = {
  "/": "/",
  "/packages": "/packages",
  "/:slug(.*)*": "/:slug(.*)*",
  "/changelog": "/changelog",
  "/relations": "/relations",
  "/ndefined": "/ndefined"
};

const matcher = createRouterMatcher([], {});
for (const path of Object.keys(i18nPathToPath)) {
  matcher.addRoute({ path, component: () => "", meta: {} });
}
const getI18nPathToI18nPath = (path, locale) => {
  if (!path || !locale) return;
  const plainPath = i18nPathToPath[path];
  const i18nConfig = pathToI18nConfig[plainPath];
  if (i18nConfig && i18nConfig[locale]) {
    return i18nConfig[locale] === true ? plainPath : i18nConfig[locale];
  }
};
function isExistingNuxtRoute(path) {
  if (path === "") return;
  const resolvedMatch = matcher.resolve({ path }, { path: "/", name: "", matched: [], params: {}, meta: {} });
  return resolvedMatch.matched.length > 0 ? resolvedMatch : void 0;
}
function matchLocalized(path, locale, defaultLocale) {
  if (path === "") return;
  const parsed = parsePath(path);
  const resolvedMatch = matcher.resolve(
    { path: parsed.pathname || "/" },
    { path: "/", name: "", matched: [], params: {}, meta: {} }
  );
  if (resolvedMatch.matched.length > 0) {
    const alternate = getI18nPathToI18nPath(resolvedMatch.matched[0].path, locale);
    const match = matcher.resolve(
      { params: resolvedMatch.params },
      { path: alternate || "/", name: "", matched: [], params: {}, meta: {} }
    );
    const isPrefixable = prefixable(locale, defaultLocale);
    return withLeadingSlash(joinURL(isPrefixable ? locale : "", match.path));
  }
}
function prefixable(currentLocale, defaultLocale) {
  return   (currentLocale !== defaultLocale || "prefix_except_default" === "prefix");
}

const getHost = (event) => getRequestURL(event, { xForwardedHost: true }).host;
function* detect(detectors, detection, path) {
  if (detection.enabled) {
    yield { locale: detectors.cookie(), source: "cookie" };
    yield { locale: detectors.header(), source: "header" };
  }
  {
    yield { locale: detectors.route(path), source: "route" };
  }
  yield { locale: detection.fallbackLocale, source: "fallback" };
}
const _Lnhmmpxh8LSiFEG6sKva5KCqWZwswn26viL05KZ4Nck = defineNitroPlugin(async (nitro) => {
  const runtimeI18n = useRuntimeI18n();
  const rootRedirect = resolveRootRedirect(runtimeI18n.rootRedirect);
  const _defaultLocale = runtimeI18n.defaultLocale || "";
  try {
    const cacheStorage = useStorage("cache");
    const cachedKeys = await cacheStorage.getKeys("nitro:handlers:i18n");
    await Promise.all(cachedKeys.map((key) => cacheStorage.removeItem(key)));
  } catch {
  }
  const detection = useI18nDetection();
  const cookieOptions = {
    path: "/",
    domain: detection.cookieDomain || void 0,
    maxAge: 60 * 60 * 24 * 365,
    sameSite: "lax",
    secure: detection.cookieSecure
  };
  const createBaseUrlGetter = () => {
    isFunction(runtimeI18n.baseUrl) ? "" : runtimeI18n.baseUrl || "";
    if (isFunction(runtimeI18n.baseUrl)) {
      return () => "";
    }
    return (event, defaultLocale) => {
      return "";
    };
  };
  function resolveRedirectPath(event, path, pathLocale, defaultLocale, detector) {
    let locale = "";
    for (const detected of detect(detector, detection, event.path)) {
      if (detected.locale && isSupportedLocale(detected.locale)) {
        locale = detected.locale;
        break;
      }
    }
    locale ||= defaultLocale;
    function getLocalizedMatch(locale2) {
      const res = matchLocalized(path || "/", locale2, defaultLocale);
      if (res && res !== event.path) {
        return res;
      }
    }
    let resolvedPath = void 0;
    let redirectCode = 302;
    const requestURL = getRequestURL(event);
    if (rootRedirect && requestURL.pathname === "/") {
      locale = detection.enabled && locale || defaultLocale;
      resolvedPath = isSupportedLocale(detector.route(rootRedirect.path)) && rootRedirect.path || matchLocalized(rootRedirect.path, locale, defaultLocale);
      redirectCode = rootRedirect.code;
    } else if (runtimeI18n.redirectStatusCode) {
      redirectCode = runtimeI18n.redirectStatusCode;
    }
    switch (detection.redirectOn) {
      case "root":
        if (requestURL.pathname !== "/") break;
      // fallthrough (root has no prefix)
      case "no prefix":
        if (pathLocale) break;
      // fallthrough to resolve
      case "all":
        resolvedPath ??= getLocalizedMatch(locale);
        break;
    }
    if (requestURL.pathname === "/" && "prefix_except_default" === "prefix") ;
    return { path: resolvedPath, code: redirectCode, locale };
  }
  const baseUrlGetter = createBaseUrlGetter();
  nitro.hooks.hook("request", async (event) => {
    const options = await setupVueI18nOptions(getDefaultLocaleForDomain(getHost(event)) || _defaultLocale);
    const url = getRequestURL(event);
    const ctx = createI18nContext();
    const localeConfigs = createLocaleConfigs(options.fallbackLocale);
    ctx.vueI18nOptions = options;
    ctx.localeConfigs = localeConfigs;
    event.context.nuxtI18n = ctx;
    {
      const detector = useDetectors(event, detection);
      const localeSegment = detector.route(event.path);
      const pathLocale = isSupportedLocale(localeSegment) && localeSegment || void 0;
      const path = pathLocale && url.pathname.slice(pathLocale.length + 1) || url.pathname;
      if (!url.pathname.includes("/_i18n/") && !isExistingNuxtRoute(path)) {
        return;
      }
      const resolved = resolveRedirectPath(event, path, pathLocale, options.defaultLocale, detector);
      if (resolved.path && resolved.path !== url.pathname) {
        ctx.detectLocale = resolved.locale;
        detection.useCookie && setCookie(event, detection.cookieKey, resolved.locale, cookieOptions);
        await sendRedirect(
          event,
          joinURL(baseUrlGetter(event, options.defaultLocale), resolved.path + url.search),
          resolved.code
        );
        return;
      }
    }
  });
  nitro.hooks.hook("render:html", (htmlContext, { event }) => {
    tryUseI18nContext(event);
  });
});

const script = "\"use strict\";(()=>{const t=window,e=document.documentElement,c=[\"dark\",\"light\"],n=getStorageValue(\"localStorage\",\"nuxt-color-mode\")||\"system\";let i=n===\"system\"?u():n;const r=e.getAttribute(\"data-color-mode-forced\");r&&(i=r),l(i),t[\"__NUXT_COLOR_MODE__\"]={preference:n,value:i,getColorScheme:u,addColorScheme:l,removeColorScheme:d};function l(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.add(s):e.className+=\" \"+s,a&&e.setAttribute(\"data-\"+a,o)}function d(o){const s=\"\"+o+\"\",a=\"\";e.classList?e.classList.remove(s):e.className=e.className.replace(new RegExp(s,\"g\"),\"\"),a&&e.removeAttribute(\"data-\"+a)}function f(o){return t.matchMedia(\"(prefers-color-scheme\"+o+\")\")}function u(){if(t.matchMedia&&f(\"\").media!==\"not all\"){for(const o of c)if(f(\":\"+o).matches)return o}return\"light\"}})();function getStorageValue(t,e){switch(t){case\"localStorage\":return window.localStorage.getItem(e);case\"sessionStorage\":return window.sessionStorage.getItem(e);case\"cookie\":return getCookie(e);default:return null}}function getCookie(t){const c=(\"; \"+window.document.cookie).split(\"; \"+t+\"=\");if(c.length===2)return c.pop()?.split(\";\").shift()}";

const _wN5z9VpfxVQX93pGrWFWYwE8AJumSkkUBvyVCQAI_zM = (function(nitro) {
  nitro.hooks.hook("render:html", (htmlContext) => {
    htmlContext.head.push(`<script>${script}<\/script>`);
  });
});

const plugins = [
  _c0eGq9VvKN57O7D4INiVXnRru42bFGyKzA7Lj1MPQ,
_DjK0ePnUIeriVTcFrzuHdCOnQKZ8rQhOmbZVSI2Ag6o,
_Lnhmmpxh8LSiFEG6sKva5KCqWZwswn26viL05KZ4Nck,
_wN5z9VpfxVQX93pGrWFWYwE8AJumSkkUBvyVCQAI_zM
];

const assets = {
  "/BingSiteAuth.xml": {
    "type": "application/xml",
    "etag": "\"56-AUuuUq8bI0k71GmgqeXDuCnffnQ\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 86,
    "path": "../public/BingSiteAuth.xml"
  },
  "/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-Wvkcz9xOIGPp2N+n5i/G0I0ql7w\"",
    "mtime": "2025-12-29T15:10:29.997Z",
    "size": 486,
    "path": "../public/_payload.json"
  },
  "/ads.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"3b-ddh6TI5cdc444LBllPN48t3vIuI\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 59,
    "path": "../public/ads.txt"
  },
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"18cc-w18l9yXttlK+POU8kP6eJVcsPxc\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 6348,
    "path": "../public/favicon.ico"
  },
  "/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2fbc2-2AnyrtzTt9QSX13I4ld+m1ylHus\"",
    "mtime": "2025-12-29T15:10:09.476Z",
    "size": 195522,
    "path": "../public/index.html"
  },
  "/logo-dark.svg": {
    "type": "image/svg+xml",
    "etag": "\"934-DP7jqUNG6Z0tLsPhjE0sQx78Qlw\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 2356,
    "path": "../public/logo-dark.svg"
  },
  "/logo.svg": {
    "type": "image/svg+xml",
    "etag": "\"931-CorJECT6kD4MssVYm8ZXzfl9G5Y\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 2353,
    "path": "../public/logo.svg"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"e-fknf2XMZ9d182uqFGM9D4OjQHlo\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 14,
    "path": "../public/robots.txt"
  },
  "/_nuxt/2C8tTDkM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f05-ERzWgKFVvC1MtGlBzpnClqe1d8k\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 7941,
    "path": "../public/_nuxt/2C8tTDkM.js"
  },
  "/_nuxt/2ZfV8NB5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6c005-0SYjmhnBegXqBZL3HTdM8nJ1xB4\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 442373,
    "path": "../public/_nuxt/2ZfV8NB5.js"
  },
  "/_nuxt/2ny99B--.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5630-UJN+zo20aBm0r/v8ZZzGbVqWjZs\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 22064,
    "path": "../public/_nuxt/2ny99B--.js"
  },
  "/_nuxt/2xQHEf8i.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2823-+OpZKmqhqIZQ8ZSYTOmHYG6hcY4\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 10275,
    "path": "../public/_nuxt/2xQHEf8i.js"
  },
  "/_nuxt/9-2Bjiqo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f8b-aF1hARzVMFFzTwP9/z4KiHXRpR4\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 3979,
    "path": "../public/_nuxt/9-2Bjiqo.js"
  },
  "/_nuxt/9SxQX8dz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"66-d7N/Md9hSGVUxN5RVR2+UdOXE74\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 102,
    "path": "../public/_nuxt/9SxQX8dz.js"
  },
  "/_nuxt/B-uTGV1Z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"285-xrRHeM5KCBnvehuYNVwVLfyTgOg\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 645,
    "path": "../public/_nuxt/B-uTGV1Z.js"
  },
  "/_nuxt/B2-DQntW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"341-/foCKzFvFhHkWzBZ5akV3uK9l5A\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 833,
    "path": "../public/_nuxt/B2-DQntW.js"
  },
  "/_nuxt/B3buYAOM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2e66-ObKfi/I88JarpSucRO9n/2f2XX4\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 11878,
    "path": "../public/_nuxt/B3buYAOM.js"
  },
  "/_nuxt/B3eoks0a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"99-zxdNwbmH84F99qvcUfF5lcdtM4M\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 153,
    "path": "../public/_nuxt/B3eoks0a.js"
  },
  "/_nuxt/B4Wd7Hgd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"51a-JOnafzDNi+tEu0ZkfhzUxtSsI5g\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 1306,
    "path": "../public/_nuxt/B4Wd7Hgd.js"
  },
  "/_nuxt/B6CRwaHC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"157c-DTI6UADns4gJrGfosw/oSDLs6eI\"",
    "mtime": "2025-12-29T15:11:07.503Z",
    "size": 5500,
    "path": "../public/_nuxt/B6CRwaHC.js"
  },
  "/_nuxt/B6aJPvgy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11140-XETFItwVwxRkr1lmxpmD5HhYfw4\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 69952,
    "path": "../public/_nuxt/B6aJPvgy.js"
  },
  "/_nuxt/B6kzuGbD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"64-1STNIbPfVAQijRkP41RJ6AwWAoc\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 100,
    "path": "../public/_nuxt/B6kzuGbD.js"
  },
  "/_nuxt/B7SKdHmW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19f-F3hIQB6slrGtbshr0HRt2b6eZTY\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 415,
    "path": "../public/_nuxt/B7SKdHmW.js"
  },
  "/_nuxt/B9sguT0H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2a5-r7AEETQ25TUe9Da/65bCq3DNHtc\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 677,
    "path": "../public/_nuxt/B9sguT0H.js"
  },
  "/_nuxt/BBJ5hgfB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"40a-Y40hhSbQlO6LaJ3ezjoJ/tv+Tcw\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 1034,
    "path": "../public/_nuxt/BBJ5hgfB.js"
  },
  "/_nuxt/BCHaZ3BN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8e7-iiv8lws8s0jso7OtA7LHTGyM+Uo\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 2279,
    "path": "../public/_nuxt/BCHaZ3BN.js"
  },
  "/_nuxt/BCPYANBE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"263-CSnhPffmKkDZSkzKJjLqVRrj4nQ\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 611,
    "path": "../public/_nuxt/BCPYANBE.js"
  },
  "/_nuxt/BDQ5h-O-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7bf-x/ALE8r0I5CDKSQuP20Ku+FeX+Y\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 1983,
    "path": "../public/_nuxt/BDQ5h-O-.js"
  },
  "/_nuxt/BEwlwnbL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5f5-PZNMMq3Q3ZcnZluOhnwRXAv7MyI\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 1525,
    "path": "../public/_nuxt/BEwlwnbL.js"
  },
  "/_nuxt/BMMyXqK5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2aadf-zP5tHhmO03TaqDhN0P+7AcZ5ZIs\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 174815,
    "path": "../public/_nuxt/BMMyXqK5.js"
  },
  "/_nuxt/BPUYGL9T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"262-pTCzbXVK/kvMSd21UkoOPNWAq7o\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 610,
    "path": "../public/_nuxt/BPUYGL9T.js"
  },
  "/_nuxt/BQ2DB8kT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d64-a2WWsSFjmmYKwKGBQBNJd5bB0EA\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 3428,
    "path": "../public/_nuxt/BQ2DB8kT.js"
  },
  "/_nuxt/BQoCrLpi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2aae-Wp2O1Wt/Vi69nrvg+k5lQcbKC2Y\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 10926,
    "path": "../public/_nuxt/BQoCrLpi.js"
  },
  "/_nuxt/BSDkiEgO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"287-CDqzp5k3q2g6nIDHNE6ihh85uPg\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 647,
    "path": "../public/_nuxt/BSDkiEgO.js"
  },
  "/_nuxt/BSVnnfW9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d7-Z6UFWUjCb1DoFsO+Z5gauyI5FTg\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 215,
    "path": "../public/_nuxt/BSVnnfW9.js"
  },
  "/_nuxt/BTKQmwVy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d2c-VyWC89HF3v6/PiPI1I/Ku1JvYTc\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 3372,
    "path": "../public/_nuxt/BTKQmwVy.js"
  },
  "/_nuxt/BTms_Iwd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"10d-GqJct0hZXFh3U/YfxATsDBuXAaY\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 269,
    "path": "../public/_nuxt/BTms_Iwd.js"
  },
  "/_nuxt/BTo_xpWu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2aa-XewMPm6/2Wm55FHwOP4nwPtVHf4\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 682,
    "path": "../public/_nuxt/BTo_xpWu.js"
  },
  "/_nuxt/BTpKwRv2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18f2-CXjAns/smGG905Il7vY1x7Nckr8\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 6386,
    "path": "../public/_nuxt/BTpKwRv2.js"
  },
  "/_nuxt/BVAt4x5-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14a-NiLpo30wjOKHiuq7Xl9c0za3oc4\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 330,
    "path": "../public/_nuxt/BVAt4x5-.js"
  },
  "/_nuxt/BWvkUFHy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"56ad-4ZtrXwVk7npBM+ABb2/C2gOMoAw\"",
    "mtime": "2025-12-29T15:11:07.504Z",
    "size": 22189,
    "path": "../public/_nuxt/BWvkUFHy.js"
  },
  "/_nuxt/BXkT12tz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"320-41/cNC1BWcTNe6eCjZKM/JyQqDA\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 800,
    "path": "../public/_nuxt/BXkT12tz.js"
  },
  "/_nuxt/BYeFu_2m.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"137-AZHjSo/UU6mW43w4fNtNZvu8Oa0\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 311,
    "path": "../public/_nuxt/BYeFu_2m.js"
  },
  "/_nuxt/B_FWdlxi.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b7-BfhD0CxLSIK2+v5sZ6mSae35nKc\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 183,
    "path": "../public/_nuxt/B_FWdlxi.js"
  },
  "/_nuxt/B_HjzqPZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"da8c-FTjlz6EWe1+KdyH3nyv996rW1og\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 55948,
    "path": "../public/_nuxt/B_HjzqPZ.js"
  },
  "/_nuxt/BaGllfED.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"132d41-9hYdSR79FDTUMd1QTEGFt4vcYFg\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 1256769,
    "path": "../public/_nuxt/BaGllfED.js"
  },
  "/_nuxt/Bd2HrsGx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"292-AKsoAN3FTq1F+ERFzXxR1QHMeTY\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 658,
    "path": "../public/_nuxt/Bd2HrsGx.js"
  },
  "/_nuxt/Bf93ECBS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a6-Vp37MJqYrlSUlkNKqIZFT1cpO9g\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 166,
    "path": "../public/_nuxt/Bf93ECBS.js"
  },
  "/_nuxt/BhBbxBrG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"73cd6-pHb4OHr1AipuA69W9kirikSMySg\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 474326,
    "path": "../public/_nuxt/BhBbxBrG.js"
  },
  "/_nuxt/BhXmzMrd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"307-PWSIGBGkQWfPuv9m0BvhlsAdY0Q\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 775,
    "path": "../public/_nuxt/BhXmzMrd.js"
  },
  "/_nuxt/BimZVaFc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ebd7-ZEY09c01I4ZDq286WzcYcmZaQys\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 60375,
    "path": "../public/_nuxt/BimZVaFc.js"
  },
  "/_nuxt/Bm-8RCcY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"228-D4aFsnNBacmtq9GY1yptcmCOAig\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 552,
    "path": "../public/_nuxt/Bm-8RCcY.js"
  },
  "/_nuxt/Bm6iM8tz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"90-e91mPyqF5MN2qC0Trc6gLgc+S3o\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 144,
    "path": "../public/_nuxt/Bm6iM8tz.js"
  },
  "/_nuxt/BogkIBhp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17f-NxM/h+aIAuqdQKQcUfNQV79KvBY\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 383,
    "path": "../public/_nuxt/BogkIBhp.js"
  },
  "/_nuxt/Bookshelf.CqGTmIQM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1af-KQln6OW5J6fvJO1VfMMs9toks6k\"",
    "mtime": "2025-12-29T15:11:07.505Z",
    "size": 431,
    "path": "../public/_nuxt/Bookshelf.CqGTmIQM.css"
  },
  "/_nuxt/BqcSDV-_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6e0-jKAzmxUZJf7/dbRtEQLFo9UXpYU\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 1760,
    "path": "../public/_nuxt/BqcSDV-_.js"
  },
  "/_nuxt/BqgpNCfb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b4-a67wfh2XhtarZG16ZOKxgsxl+Zc\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 180,
    "path": "../public/_nuxt/BqgpNCfb.js"
  },
  "/_nuxt/BtXJkA3K.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"134-yEqiKn4/3F/TYhddKlSqNhxhmWA\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 308,
    "path": "../public/_nuxt/BtXJkA3K.js"
  },
  "/_nuxt/Buea-lGh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"290a-GCHC0QDId6leZ9Xhk+7ArK7tKlc\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 10506,
    "path": "../public/_nuxt/Buea-lGh.js"
  },
  "/_nuxt/ButV5y0S.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d7-ovunL57x70Mpsbv6Nr8+v4mkLf0\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 215,
    "path": "../public/_nuxt/ButV5y0S.js"
  },
  "/_nuxt/BviIZ2Kl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"138-AFUnaYEvuwCIybRCw2EsJ9lFN7o\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 312,
    "path": "../public/_nuxt/BviIZ2Kl.js"
  },
  "/_nuxt/ByAx_D5w.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"56-sPwP6B5MZGttiPNuB28d9l2+J4c\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 86,
    "path": "../public/_nuxt/ByAx_D5w.js"
  },
  "/_nuxt/C-ktNWDf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d6-EWKKuaIyvbXnFanbbXNDG02LoWw\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 470,
    "path": "../public/_nuxt/C-ktNWDf.js"
  },
  "/_nuxt/C1lzXrBd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a6-WqSLA3X8QdIqjzj5u2inJlGdRIg\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 166,
    "path": "../public/_nuxt/C1lzXrBd.js"
  },
  "/_nuxt/C2AgOMKm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"10f-Jc1YVrn3suSKrBurb1g11B/CHcw\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 271,
    "path": "../public/_nuxt/C2AgOMKm.js"
  },
  "/_nuxt/C2H-UeX1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"425-IWsEdLxg7jYhDb2vy39xxPm9vaU\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 1061,
    "path": "../public/_nuxt/C2H-UeX1.js"
  },
  "/_nuxt/C47r5Cv_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"64-bgCDTKHDhbmTFMsu1SxA3evOe/8\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 100,
    "path": "../public/_nuxt/C47r5Cv_.js"
  },
  "/_nuxt/C4B-KCzX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11c3-kQzscKmHA05AUbOLk+HVOwXMmQk\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 4547,
    "path": "../public/_nuxt/C4B-KCzX.js"
  },
  "/_nuxt/C5Ws6Zkh.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"175-DsDV5EZPpAC3cC9624x9Vo/Cdy0\"",
    "mtime": "2025-12-29T15:11:07.506Z",
    "size": 373,
    "path": "../public/_nuxt/C5Ws6Zkh.js"
  },
  "/_nuxt/C7QetKmQ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3d7c-bqROWQkPcEY9x7pPh2VeZVgxAHk\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 15740,
    "path": "../public/_nuxt/C7QetKmQ.js"
  },
  "/_nuxt/C7TZldLO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"40bc4-q4Vn231Ppp8XAYdGzRcAuWdaRGI\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 265156,
    "path": "../public/_nuxt/C7TZldLO.js"
  },
  "/_nuxt/C7kQkgiA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2d0-7fwM+bQdG/Bag7W+i49cuE6b5VI\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 720,
    "path": "../public/_nuxt/C7kQkgiA.js"
  },
  "/_nuxt/C8rxL-z0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14a-NiLpo30wjOKHiuq7Xl9c0za3oc4\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 330,
    "path": "../public/_nuxt/C8rxL-z0.js"
  },
  "/_nuxt/C8zhMQhy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"791-X5REcqXJ7F1/oSbSXdBoRlagM/s\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 1937,
    "path": "../public/_nuxt/C8zhMQhy.js"
  },
  "/_nuxt/C9R0VZJw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6a1d-u+0N8v+tTLd7NULiGyFaeH0SYUk\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 27165,
    "path": "../public/_nuxt/C9R0VZJw.js"
  },
  "/_nuxt/C9dcJim5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16bf-0j+qc5I/Ow73a0nsb6N6Gmzm+hs\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 5823,
    "path": "../public/_nuxt/C9dcJim5.js"
  },
  "/_nuxt/C9vxnU8a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d3f-4/7F1m8n4Ipf/wqkw3vZPX0mx6w\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 3391,
    "path": "../public/_nuxt/C9vxnU8a.js"
  },
  "/_nuxt/CAORconx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"59-sn3TqhDZ6j7K7R49j8ZPZ/ollP8\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 89,
    "path": "../public/_nuxt/CAORconx.js"
  },
  "/_nuxt/CAx5bA7A.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"110-ApLPxfBMqmszA585bRtbWFnpycw\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 272,
    "path": "../public/_nuxt/CAx5bA7A.js"
  },
  "/_nuxt/CC4asDF5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-WXPpT2M50i6jwoLivAXg/gpMAXY\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 78,
    "path": "../public/_nuxt/CC4asDF5.js"
  },
  "/_nuxt/CDI6NPgl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1122-bT3a7E0faCIhy2yEe0+q28664Zk\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 4386,
    "path": "../public/_nuxt/CDI6NPgl.js"
  },
  "/_nuxt/CG6Dc4jp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"97f00-rYm+CybCMCqxOZ2Np2GsfIrREbo\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 622336,
    "path": "../public/_nuxt/CG6Dc4jp.js"
  },
  "/_nuxt/CGxwM-R_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f4dd-OVSAfBjVO37I7cSlZLEhUptarG0\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 62685,
    "path": "../public/_nuxt/CGxwM-R_.js"
  },
  "/_nuxt/CH6CpI2E.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"551-ZbliBTcFQ6F0/a89SC1H2tXCXOU\"",
    "mtime": "2025-12-29T15:11:07.507Z",
    "size": 1361,
    "path": "../public/_nuxt/CH6CpI2E.js"
  },
  "/_nuxt/CI-6S19Z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"129-Zun+OJOcEC1dJKZCG43koLvqnmA\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 297,
    "path": "../public/_nuxt/CI-6S19Z.js"
  },
  "/_nuxt/CJ26IJdR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bbd-RpDIWyWsvGygPu+FmqDE5wRE1gg\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 3005,
    "path": "../public/_nuxt/CJ26IJdR.js"
  },
  "/_nuxt/CKOU7iFy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"243ae-GUXnxN+yW2HZexaAFbAMpt22CVU\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 148398,
    "path": "../public/_nuxt/CKOU7iFy.js"
  },
  "/_nuxt/CKVOJjlE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"83f9-ZkMiqBqreONj6Jes525IwZc1RMA\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 33785,
    "path": "../public/_nuxt/CKVOJjlE.js"
  },
  "/_nuxt/CL7KkeEY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"24a-nsaUzaWApq6ZbQBwRIkOSgsEffE\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 586,
    "path": "../public/_nuxt/CL7KkeEY.js"
  },
  "/_nuxt/CLeUG0X0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"13a37-nNOuwJjt0Q1HETflsCp/Tfyz1IA\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 80439,
    "path": "../public/_nuxt/CLeUG0X0.js"
  },
  "/_nuxt/CMfQ--NL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"26d-ZGS45/1PNFMqMk8FTVJkXO9bGlA\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 621,
    "path": "../public/_nuxt/CMfQ--NL.js"
  },
  "/_nuxt/CN4bKnQl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"264-5XDX5S+AxL9RwjKSD4v2x6F/DPs\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 612,
    "path": "../public/_nuxt/CN4bKnQl.js"
  },
  "/_nuxt/CQMirwYC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1415-Se5IBXtIF21vbGdqVe47UF04slg\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 5141,
    "path": "../public/_nuxt/CQMirwYC.js"
  },
  "/_nuxt/CRog2eLo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"896a-6O5b7GhhN3REPJMfkmMbbvAE3R0\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 35178,
    "path": "../public/_nuxt/CRog2eLo.js"
  },
  "/_nuxt/CT7KU_Sa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"117-ZigHXLnzPQpZEU2Q4c2YvywEcOA\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 279,
    "path": "../public/_nuxt/CT7KU_Sa.js"
  },
  "/_nuxt/CTGlW678.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"329-leFDVlOaBF3H9RsOnAZxRCd6YwU\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 809,
    "path": "../public/_nuxt/CTGlW678.js"
  },
  "/_nuxt/CTSDTqn3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11d-RX+kbgNlSy4A3NVPBbT7hYOAn2Q\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 285,
    "path": "../public/_nuxt/CTSDTqn3.js"
  },
  "/_nuxt/CX7yPW7Z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"67d-zUFj1mRlMFZgIRQDDRFIkgAL/qA\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 1661,
    "path": "../public/_nuxt/CX7yPW7Z.js"
  },
  "/_nuxt/CY9rREP9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b7-9KT/SzXWrtPsVnT14Etwti329Ho\"",
    "mtime": "2025-12-29T15:11:07.508Z",
    "size": 439,
    "path": "../public/_nuxt/CY9rREP9.js"
  },
  "/_nuxt/CZf9lKcw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dc-xbUdq1Gz5mlAFDT8nEQzFM99fQ0\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 220,
    "path": "../public/_nuxt/CZf9lKcw.js"
  },
  "/_nuxt/CcP1m6Jq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"763-K8BCshFzgekanOGYPGBT7Z82vpU\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 1891,
    "path": "../public/_nuxt/CcP1m6Jq.js"
  },
  "/_nuxt/CcT6Q_wS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b0da-QtvmaH3+xlybrMef0wl5LZSont4\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 45274,
    "path": "../public/_nuxt/CcT6Q_wS.js"
  },
  "/_nuxt/Cdu1YMRF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6a1-YChHs9NFBi17kjQf8R+HFUjQqbo\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 1697,
    "path": "../public/_nuxt/Cdu1YMRF.js"
  },
  "/_nuxt/CeLZW56q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f7-s2jbEDNxPzZ+jgm1EsAJCiYLAdg\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 247,
    "path": "../public/_nuxt/CeLZW56q.js"
  },
  "/_nuxt/CfHCTsQR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-GQfolzMDUk5UAT+riWRMN94GCd0\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 78,
    "path": "../public/_nuxt/CfHCTsQR.js"
  },
  "/_nuxt/CfPxaToZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5171-+2FMiQfi6TfS5N8GLizDN/A0UFw\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 20849,
    "path": "../public/_nuxt/CfPxaToZ.js"
  },
  "/_nuxt/ChJ_63Hw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"227-SF+6boSnBA4UW4JojL9AR7jVq8w\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 551,
    "path": "../public/_nuxt/ChJ_63Hw.js"
  },
  "/_nuxt/ChVCyUj4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11a-O0dBlcTtNbgokTwV8awDajzsnEU\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 282,
    "path": "../public/_nuxt/ChVCyUj4.js"
  },
  "/_nuxt/CiG_x4bw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cf-EhhT0TTmNR4F3d4QhX2LV373mMs\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 207,
    "path": "../public/_nuxt/CiG_x4bw.js"
  },
  "/_nuxt/CiPxF6SO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"24a03-ooe3Z6+8GG2fLV5porOSBOmtwyw\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 150019,
    "path": "../public/_nuxt/CiPxF6SO.js"
  },
  "/_nuxt/CiUBryY9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11a-IQxg/JGyz29HY7GVh+UzXAfxepo\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 282,
    "path": "../public/_nuxt/CiUBryY9.js"
  },
  "/_nuxt/CjQeeSi3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"593-MFpYZCQ+UAWnMF74XDKtQDyyn5k\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 1427,
    "path": "../public/_nuxt/CjQeeSi3.js"
  },
  "/_nuxt/ClvdYgsP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c6291-ln08MvIB5urrF/EIwhdYTAP4m3w\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 811665,
    "path": "../public/_nuxt/ClvdYgsP.js"
  },
  "/_nuxt/CmKTTxBW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4a0-QhSTpwVjrC/PVWv/HHlzrTsQTiE\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 1184,
    "path": "../public/_nuxt/CmKTTxBW.js"
  },
  "/_nuxt/Cmf0IIJI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"121-KXUQhT+lwPcDzH2uybkhtWTrAn8\"",
    "mtime": "2025-12-29T15:11:07.509Z",
    "size": 289,
    "path": "../public/_nuxt/Cmf0IIJI.js"
  },
  "/_nuxt/CneD5c8s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9bf-GxzT9arRhgIuJIrJxblZTMxrO5c\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 2495,
    "path": "../public/_nuxt/CneD5c8s.js"
  },
  "/_nuxt/Cowh-Amf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16f2-JP60k0D9InX1bDFrFUX3rNL+uUM\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 5874,
    "path": "../public/_nuxt/Cowh-Amf.js"
  },
  "/_nuxt/Cp-IABpG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b08-0dMeGWm4gC22OpAzs7TTvP5ig+w\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 2824,
    "path": "../public/_nuxt/Cp-IABpG.js"
  },
  "/_nuxt/CpaNjuB2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"290-pt5h2zDMZ6oQFqpVx+5hSE8vuUQ\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 656,
    "path": "../public/_nuxt/CpaNjuB2.js"
  },
  "/_nuxt/CrRAVe7C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2bc-M2js0mkO+KWxxBZ9mKC+NJ7VL4A\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 700,
    "path": "../public/_nuxt/CrRAVe7C.js"
  },
  "/_nuxt/CsJc9_JA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"15fd-5fwpBuZ6m0tCVSn5tWd9C598KF4\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 5629,
    "path": "../public/_nuxt/CsJc9_JA.js"
  },
  "/_nuxt/CvPGCCkR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b7-tICBr+9twjDHpuY3+u4pF/KrNRI\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 183,
    "path": "../public/_nuxt/CvPGCCkR.js"
  },
  "/_nuxt/CvXEFby9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8dc-EEVrFjLRo2LW0+GqV4/bIDii8pY\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 2268,
    "path": "../public/_nuxt/CvXEFby9.js"
  },
  "/_nuxt/Cy5Iw_mE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"107a-0beSd1QieXxlJ2WWOtM47hUAfbI\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 4218,
    "path": "../public/_nuxt/Cy5Iw_mE.js"
  },
  "/_nuxt/D33a56Y4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d1-Ip0NPbguUtVLEieNEGuMu6fTMV0\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 465,
    "path": "../public/_nuxt/D33a56Y4.js"
  },
  "/_nuxt/D3HasyVA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"384e-xpuNcZHONWV++sbSdcETJz60G4M\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 14414,
    "path": "../public/_nuxt/D3HasyVA.js"
  },
  "/_nuxt/D5JWoJ2U.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3862e-frz8dOBoRDVvMGZRcMSvrTykiu8\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 230958,
    "path": "../public/_nuxt/D5JWoJ2U.js"
  },
  "/_nuxt/D5tPW23i.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4c85-T1wbMhEWwkMGxbTtmUNbbf9/lpQ\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 19589,
    "path": "../public/_nuxt/D5tPW23i.js"
  },
  "/_nuxt/D6GZmghr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e97-s9eVJUcbs+3Lk/t/Iji19NkUtWo\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 3735,
    "path": "../public/_nuxt/D6GZmghr.js"
  },
  "/_nuxt/D70xMAc9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"119b3-zvVY/6sw3ztTN+NalNprTJ8nwsA\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 72115,
    "path": "../public/_nuxt/D70xMAc9.js"
  },
  "/_nuxt/D97Zzqfu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a09-Iv5nl+0fTHSk4kWPf95nbKZPxsM\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 2569,
    "path": "../public/_nuxt/D97Zzqfu.js"
  },
  "/_nuxt/D9c0JnCP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"352-sBKS8vuTzGyVicUpeItIbHxgpMo\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 850,
    "path": "../public/_nuxt/D9c0JnCP.js"
  },
  "/_nuxt/DAi9KRSo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2bb0-kCaePAc0SkqzEXT/m+0Gi8SfIkE\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 11184,
    "path": "../public/_nuxt/DAi9KRSo.js"
  },
  "/_nuxt/DCuJACQS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"38-U3+sQZVvhT0VFw/ebnEM9gw2MU0\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 56,
    "path": "../public/_nuxt/DCuJACQS.js"
  },
  "/_nuxt/DEw8pil6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"754a-2Lr9praJXkGkycM3wmuEu7rNrOs\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 30026,
    "path": "../public/_nuxt/DEw8pil6.js"
  },
  "/_nuxt/DGhFpbOn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"111ca-mvwl+m3+RPINotkVC2uRnGfR77I\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 70090,
    "path": "../public/_nuxt/DGhFpbOn.js"
  },
  "/_nuxt/DHJKELXO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2c8d-G52k5HF2RR+jOGOolyZJDXOaYjU\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 11405,
    "path": "../public/_nuxt/DHJKELXO.js"
  },
  "/_nuxt/DJUG8sLR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b9-ze6rSzjjzVvQJ3YK3QRLwhwxqw8\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 185,
    "path": "../public/_nuxt/DJUG8sLR.js"
  },
  "/_nuxt/DKdATPUb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"263-EEqJQ8J9RAqvKoTk9WTwjqtg8iE\"",
    "mtime": "2025-12-29T15:11:07.510Z",
    "size": 611,
    "path": "../public/_nuxt/DKdATPUb.js"
  },
  "/_nuxt/DKqGsm5v.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1dd-PT5hirufUuCfAgZSMVHN7FL7ou4\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 477,
    "path": "../public/_nuxt/DKqGsm5v.js"
  },
  "/_nuxt/DKqLVGGa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-SpLD/Ogb/GsFAz4g0hYL4CaBxGc\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 78,
    "path": "../public/_nuxt/DKqLVGGa.js"
  },
  "/_nuxt/DLmzfmQN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c2-NpoqZi1g/yjLhc6rqJyaHigO0yc\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 962,
    "path": "../public/_nuxt/DLmzfmQN.js"
  },
  "/_nuxt/DMF-CwMB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"39-0p/7pYA0dnIn9iF42h1i5WQNJUw\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 57,
    "path": "../public/_nuxt/DMF-CwMB.js"
  },
  "/_nuxt/DO3uVgqm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1e7ff-xsoYJFhBPyKKrAnT4V6Muaf3hqk\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 124927,
    "path": "../public/_nuxt/DO3uVgqm.js"
  },
  "/_nuxt/DOJia8z7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b5-h2bDtCNkQo9/1iq9fn8QIxVIRMs\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 181,
    "path": "../public/_nuxt/DOJia8z7.js"
  },
  "/_nuxt/DOWOusVO.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5bf8-td2Aywx2fwvTq9x80esDJy91GGc\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 23544,
    "path": "../public/_nuxt/DOWOusVO.js"
  },
  "/_nuxt/DPfMkruS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"bf7f-Qa1TjFLyLxQt61atfNmRBMSFw44\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 49023,
    "path": "../public/_nuxt/DPfMkruS.js"
  },
  "/_nuxt/DTsKufoV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7ea-0bOQ997hReh2K6YdZtnfnlehMsc\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 2026,
    "path": "../public/_nuxt/DTsKufoV.js"
  },
  "/_nuxt/DVl6_SQ_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17dd9-AQtKpDL6Q+TpltnQCEIzcdvP0uM\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 97753,
    "path": "../public/_nuxt/DVl6_SQ_.js"
  },
  "/_nuxt/DW9VO52q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19f-H9TNYh7F6ZpPYWcpQk9z6+KpBNc\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 415,
    "path": "../public/_nuxt/DW9VO52q.js"
  },
  "/_nuxt/DXDNz6Gv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"728-diMrX9hP9xLTsoiIc55BRmEAtPo\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 1832,
    "path": "../public/_nuxt/DXDNz6Gv.js"
  },
  "/_nuxt/Da5cRb03.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"58e-U25QluuakpO2xnTv03qF0zxBP+w\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 1422,
    "path": "../public/_nuxt/Da5cRb03.js"
  },
  "/_nuxt/Db9iuDar.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1b8-40R/zUU/3LpP3f0/FCGtemudkwY\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 440,
    "path": "../public/_nuxt/Db9iuDar.js"
  },
  "/_nuxt/DcRwDN2h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-i4z3uGIDf2s4mBXTyZieWHfwmUY\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 78,
    "path": "../public/_nuxt/DcRwDN2h.js"
  },
  "/_nuxt/DdJ8Hbpl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4bc-so/OUrPd4m79sUUGz/lanvWzA8A\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 1212,
    "path": "../public/_nuxt/DdJ8Hbpl.js"
  },
  "/_nuxt/DefJez2I.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"30b-4mt8Uu7g03oN8Q5OOQOheJU6dQU\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 779,
    "path": "../public/_nuxt/DefJez2I.js"
  },
  "/_nuxt/Des-eS-w.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c25-X/PPjzKtzZF+XWxRuaeQhmo8i2k\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 3109,
    "path": "../public/_nuxt/Des-eS-w.js"
  },
  "/_nuxt/Dex_YtR8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"90-r/Cyz/pinCelWTmafOqyiVTnt18\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 144,
    "path": "../public/_nuxt/Dex_YtR8.js"
  },
  "/_nuxt/DfsXmgCA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3f6-Lr4qUl1v3j1zqLuPn2kAYvEVoeY\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 1014,
    "path": "../public/_nuxt/DfsXmgCA.js"
  },
  "/_nuxt/DiiYFxQS.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"30c-vOIXXgIuzCmAmsoRoKPsmi/I/iE\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 780,
    "path": "../public/_nuxt/DiiYFxQS.js"
  },
  "/_nuxt/DlJ6sGCr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"21e-8e70XHTPgTaQ5CFyj0zODrBgpOc\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 542,
    "path": "../public/_nuxt/DlJ6sGCr.js"
  },
  "/_nuxt/DlfHMoPT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2c34c-AYXdu2OrEtuxgl3QSfFD3rEptZQ\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 181068,
    "path": "../public/_nuxt/DlfHMoPT.js"
  },
  "/_nuxt/DoD3LPIE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-Gp4zh/rPnFyRPTiCwkT3DHeq2R8\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 78,
    "path": "../public/_nuxt/DoD3LPIE.js"
  },
  "/_nuxt/DpHMK3M5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"db-YEZ+phn6g55UdjBREpwi0A8dalA\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 219,
    "path": "../public/_nuxt/DpHMK3M5.js"
  },
  "/_nuxt/DqJZlQQD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ac7-+oyCIFlX94pNyz9xtcNdKNnCP6M\"",
    "mtime": "2025-12-29T15:11:07.511Z",
    "size": 2759,
    "path": "../public/_nuxt/DqJZlQQD.js"
  },
  "/_nuxt/DwVLm9L_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a6d-TFQIG/gsodezOoiPDASkNDeZvHA\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 2669,
    "path": "../public/_nuxt/DwVLm9L_.js"
  },
  "/_nuxt/Dz8UgnOD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11833-SJYXgz7PcatyiB+C/yo6gOjkjtk\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 71731,
    "path": "../public/_nuxt/Dz8UgnOD.js"
  },
  "/_nuxt/FLy45hzY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-h/4jQvQXFpZV+XWM0mcQFGlfTSQ\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 78,
    "path": "../public/_nuxt/FLy45hzY.js"
  },
  "/_nuxt/Gi6I4Gst.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"93-Ddd4j0nL7FejgC/2FVPkAQwObCg\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 147,
    "path": "../public/_nuxt/Gi6I4Gst.js"
  },
  "/_nuxt/HeroSection.CsljiQRo.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"25e-j8ineuh4B1QQyq4EcyfO5fl5KPY\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 606,
    "path": "../public/_nuxt/HeroSection.CsljiQRo.css"
  },
  "/_nuxt/JhPuU2gP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"df90-vm1Dqa4n7irIagM1OYGGqKgKzHs\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 57232,
    "path": "../public/_nuxt/JhPuU2gP.js"
  },
  "/_nuxt/JoszFXJz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"33e-TTSalwtk7r62oYqOjPzgKtxxLT0\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 830,
    "path": "../public/_nuxt/JoszFXJz.js"
  },
  "/_nuxt/LXUWO03C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1709-cKpB+8XnzYxuxzE9g8YkNX5lOZ0\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 5897,
    "path": "../public/_nuxt/LXUWO03C.js"
  },
  "/_nuxt/LnduoeI7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f0-U5IXN+XNkMT32qckMjnEld/V4qM\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 496,
    "path": "../public/_nuxt/LnduoeI7.js"
  },
  "/_nuxt/MvaHKu7L.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2d1-n5P1/Q34frUeTVJzS7K89RwHmSA\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 721,
    "path": "../public/_nuxt/MvaHKu7L.js"
  },
  "/_nuxt/O1VrjNuj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"169-TZSBR6XX0eLECzoF1f9ILIBF4mw\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 361,
    "path": "../public/_nuxt/O1VrjNuj.js"
  },
  "/_nuxt/Project.03YM6AlY.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1029-ltLbdBMY8rfAW6Hzr1m+JG/ujvQ\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 4137,
    "path": "../public/_nuxt/Project.03YM6AlY.css"
  },
  "/_nuxt/ProseCode.LPvLMO9e.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5b9-1GzbK5jvzSDo95SqG2SYhckhtoM\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 1465,
    "path": "../public/_nuxt/ProseCode.LPvLMO9e.css"
  },
  "/_nuxt/ProseCodeInline.D5bVbtSg.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"92-PtN6Fp/al1JsgEOoTUqXCdZsVqE\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 146,
    "path": "../public/_nuxt/ProseCodeInline.D5bVbtSg.css"
  },
  "/_nuxt/ProsePre.B_fgAJq0.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2e-GbvrqT5j9gSWlpa8e36U/Kv6Zx0\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 46,
    "path": "../public/_nuxt/ProsePre.B_fgAJq0.css"
  },
  "/_nuxt/QEowQzF1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5092c-KJxIxxSml3mwg48kUMZ62lW8kek\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 330028,
    "path": "../public/_nuxt/QEowQzF1.js"
  },
  "/_nuxt/SponsorSection.C-LQ1UYV.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"184-Et9VwgUOf5TLjQV0vuEy7bQM4Dw\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 388,
    "path": "../public/_nuxt/SponsorSection.C-LQ1UYV.css"
  },
  "/_nuxt/T1lNAMqA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5baf-W4xG9FaZQKzcooFAjQH1hiNpWw4\"",
    "mtime": "2025-12-29T15:11:07.512Z",
    "size": 23471,
    "path": "../public/_nuxt/T1lNAMqA.js"
  },
  "/_nuxt/Testimonials.DY9jwsCn.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"225-ZZsaK51TTQkB5RzwJfetGkXpe/g\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 549,
    "path": "../public/_nuxt/Testimonials.DY9jwsCn.css"
  },
  "/_nuxt/VeA177db.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a02-rhg1oS5upLUuWm1eivcE47HClNg\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 2562,
    "path": "../public/_nuxt/VeA177db.js"
  },
  "/_nuxt/Yzrsuije.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a207-6VR5nHiV/sPzx6yPxdz5gyf5xro\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 41479,
    "path": "../public/_nuxt/Yzrsuije.js"
  },
  "/_nuxt/_I6DMx1h.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5217-s+4TNvtn/rx32A9DRgDLo4D/fvE\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 21015,
    "path": "../public/_nuxt/_I6DMx1h.js"
  },
  "/_nuxt/_X2JI73n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"292-BTQH5YTNdDD0LmgVqaBKge51slM\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 658,
    "path": "../public/_nuxt/_X2JI73n.js"
  },
  "/_nuxt/bNaE6FFb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4f-q42BFfiRogfcH1Y60YZFuPDwE5Q\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 79,
    "path": "../public/_nuxt/bNaE6FFb.js"
  },
  "/_nuxt/cVMKrrUw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"42c-dt8gMqeLmAVuhxDNufsITbOra0k\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 1068,
    "path": "../public/_nuxt/cVMKrrUw.js"
  },
  "/_nuxt/cXOl-9pK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7a-j7VKRGCqxyD1sJ0Q3Jbl2dIdPYE\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 122,
    "path": "../public/_nuxt/cXOl-9pK.js"
  },
  "/_nuxt/changelog.B8QNHpah.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"139-IKxsbGFhL56PNUpuNh1EIdRRkPM\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 313,
    "path": "../public/_nuxt/changelog.B8QNHpah.css"
  },
  "/_nuxt/eO9w5pOb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"64-u5AKF/EEWHnDuwn2vgRnSFCMVSk\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 100,
    "path": "../public/_nuxt/eO9w5pOb.js"
  },
  "/_nuxt/ehVf7--m.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"13e8c-5syghnLHu8Yd9PyXNd9Q9wT/aOg\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 81548,
    "path": "../public/_nuxt/ehVf7--m.js"
  },
  "/_nuxt/entry.6btfp5Q2.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2a202-1VZ62Y5ZG3hE8aYIf/nMx2a3rVg\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 172546,
    "path": "../public/_nuxt/entry.6btfp5Q2.css"
  },
  "/_nuxt/error-404.CpjwHO2Q.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"dce-YWhfxU+wQIXYqNuSdPcpHXn28XQ\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 3534,
    "path": "../public/_nuxt/error-404.CpjwHO2Q.css"
  },
  "/_nuxt/error-500.Cp4FTD1j.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"75c-Ztt095iAC0/8H/CHMUg6KzxSEV8\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 1884,
    "path": "../public/_nuxt/error-500.Cp4FTD1j.css"
  },
  "/_nuxt/fDDRQYhy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5de5-1F9euWDkfVLEZKa10FEay2LXEzc\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 24037,
    "path": "../public/_nuxt/fDDRQYhy.js"
  },
  "/_nuxt/gnMzh8yW.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4eb5-fTDJeraOGAGvUYlMlVFXlD74s2E\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 20149,
    "path": "../public/_nuxt/gnMzh8yW.js"
  },
  "/_nuxt/jy-mtjbr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-GB8K9Xwh350PULZlAAhkilT9mqI\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 78,
    "path": "../public/_nuxt/jy-mtjbr.js"
  },
  "/_nuxt/kkTDvnL6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1031-0nufz/1qQ+RfxGF2h1hDrCS7Pqc\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 4145,
    "path": "../public/_nuxt/kkTDvnL6.js"
  },
  "/_nuxt/lLWFzkav.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"162-h/jzPO0bFUD8O7xSBaD3RY4x8+c\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 354,
    "path": "../public/_nuxt/lLWFzkav.js"
  },
  "/_nuxt/ldfJa-Pg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6258-ojBbiLhoXHmKup0MEHnSDbgN/rQ\"",
    "mtime": "2025-12-29T15:11:07.513Z",
    "size": 25176,
    "path": "../public/_nuxt/ldfJa-Pg.js"
  },
  "/_nuxt/luKhL6Ok.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6e0-d5Pxi/iA6LYEKBHDDlmbeoSNg3Y\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 1760,
    "path": "../public/_nuxt/luKhL6Ok.js"
  },
  "/_nuxt/mtvkvA7x.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"263-iObZl0XgZuQp3yimFca4ZxFn0p0\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 611,
    "path": "../public/_nuxt/mtvkvA7x.js"
  },
  "/_nuxt/nHEvnC2O.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"151e-A7/JP/gYghfyzWSkzkStngRMZr4\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 5406,
    "path": "../public/_nuxt/nHEvnC2O.js"
  },
  "/_nuxt/oACvoWup.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"246-46d0IDnt99Br52dL0NuWE1ajycg\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 582,
    "path": "../public/_nuxt/oACvoWup.js"
  },
  "/_nuxt/police.1_QVWmWl.png": {
    "type": "image/png",
    "etag": "\"2b87-QIOsFlbl2+omKqcK7p7DiowOxRw\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 11143,
    "path": "../public/_nuxt/police.1_QVWmWl.png"
  },
  "/_nuxt/qSd0N4vn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"189-FRC35ykfyzrxLc9VtWgBhMc8u50\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 393,
    "path": "../public/_nuxt/qSd0N4vn.js"
  },
  "/_nuxt/qrhdIycK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"da-cXU1nnrVKBjnQo6M0v0LQ1jxt88\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 218,
    "path": "../public/_nuxt/qrhdIycK.js"
  },
  "/_nuxt/sqgVeKyz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9cd4-y4oN4HUfJhuAasqq8D2/4HbCLA0\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 40148,
    "path": "../public/_nuxt/sqgVeKyz.js"
  },
  "/_nuxt/tCrTb8Vw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3bc-E78GCUjAueCFaLsBEZ3iSyYZ4fg\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 956,
    "path": "../public/_nuxt/tCrTb8Vw.js"
  },
  "/_nuxt/tIGfFcyP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c2-U03vcdvbetOPyE3ctNkl812W5LQ\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 450,
    "path": "../public/_nuxt/tIGfFcyP.js"
  },
  "/_nuxt/uQIsAQFj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"38-k536yxhU9XVLT3JZPlnHbF9GYzA\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 56,
    "path": "../public/_nuxt/uQIsAQFj.js"
  },
  "/_nuxt/w-hugDzu.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"548-LzWx1Hb6Q4hzw45PQTnlnwORQ7c\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 1352,
    "path": "../public/_nuxt/w-hugDzu.js"
  },
  "/_nuxt/wymQt8xE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4e-7yLyQYF2fTv6CTPnmwBuTDhSC7c\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 78,
    "path": "../public/_nuxt/wymQt8xE.js"
  },
  "/_nuxt/x8bhDJH0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e2-yEuxjIywRZbZlFrt6ky+gkgyu2E\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 226,
    "path": "../public/_nuxt/x8bhDJH0.js"
  },
  "/_nuxt/xm6JZ6S5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8dd0-ktfhWgyac2ikHZL9NIMf19dWnI8\"",
    "mtime": "2025-12-29T15:11:07.514Z",
    "size": 36304,
    "path": "../public/_nuxt/xm6JZ6S5.js"
  },
  "/about/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-Wvkcz9xOIGPp2N+n5i/G0I0ql7w\"",
    "mtime": "2025-12-29T15:10:27.352Z",
    "size": 486,
    "path": "../public/about/_payload.json"
  },
  "/about/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"17910-xiViZaz2siOPn+jkr+h5ZAE+zYI\"",
    "mtime": "2025-12-29T15:10:09.447Z",
    "size": 96528,
    "path": "../public/about/index.html"
  },
  "/awesome-uni-app/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-Wvkcz9xOIGPp2N+n5i/G0I0ql7w\"",
    "mtime": "2025-12-29T15:10:28.373Z",
    "size": 486,
    "path": "../public/awesome-uni-app/_payload.json"
  },
  "/awesome-uni-app/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2bd23-T222YtDzU4O9qhmomJwOJOn9agU\"",
    "mtime": "2025-12-29T15:10:09.469Z",
    "size": 179491,
    "path": "../public/awesome-uni-app/index.html"
  },
  "/axios-adapter/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"121e-Hc9fFlbNVWEBD6Z/FUp3owvg3SU\"",
    "mtime": "2025-12-29T15:10:30.943Z",
    "size": 4638,
    "path": "../public/axios-adapter/_payload.json"
  },
  "/axios-adapter/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"23b27-3aqrms+kH70K4wytKEQSVRxuTkY\"",
    "mtime": "2025-12-29T15:10:09.741Z",
    "size": 146215,
    "path": "../public/axios-adapter/index.html"
  },
  "/blog/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-iSV5NLTIKwmO94KLRLqE99CYrGo\"",
    "mtime": "2025-12-29T15:10:28.235Z",
    "size": 486,
    "path": "../public/blog/_payload.json"
  },
  "/blog/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"13cb5-X2mtHVL0UrVPBuvMnUAmoByfD50\"",
    "mtime": "2025-12-29T15:10:09.469Z",
    "size": 81077,
    "path": "../public/blog/index.html"
  },
  "/changelog/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"9c4a-AnbqHpOXzFjkjbDHgGf7U4C5jEw\"",
    "mtime": "2025-12-29T15:11:05.890Z",
    "size": 40010,
    "path": "../public/changelog/_payload.json"
  },
  "/changelog/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"285c2-MYT0EboNjpJjlyNLVvkFHvTs+Qk\"",
    "mtime": "2025-12-29T15:10:28.711Z",
    "size": 165314,
    "path": "../public/changelog/index.html"
  },
  "/create-uni/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"66-cYbvI6uALnx6BgpbFUtpGu7H9IA\"",
    "mtime": "2025-12-29T15:10:09.014Z",
    "size": 102,
    "path": "../public/create-uni/index.html"
  },
  "/devtools/demo.png": {
    "type": "image/png",
    "etag": "\"1dd17-ZxNWuaPstJleuQeHh/0d6ank5wc\"",
    "mtime": "2025-12-29T15:11:07.522Z",
    "size": 122135,
    "path": "../public/devtools/demo.png"
  },
  "/eslint-config/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"15bb-g7ZZB9+nTl88whSiIemW6brEW1s\"",
    "mtime": "2025-12-29T15:10:30.180Z",
    "size": 5563,
    "path": "../public/eslint-config/_payload.json"
  },
  "/eslint-config/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1d343-hqh71Czsdx4SKYsfO8kgFjPgA0o\"",
    "mtime": "2025-12-29T15:10:09.741Z",
    "size": 119619,
    "path": "../public/eslint-config/index.html"
  },
  "/hbuilderx-cli/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1240-zUja8nDQO5KsI9tihZsfKMjwk74\"",
    "mtime": "2025-12-29T15:10:30.151Z",
    "size": 4672,
    "path": "../public/hbuilderx-cli/_payload.json"
  },
  "/hbuilderx-cli/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"19e6a-pb7HCa+Z74SPAnQxF+KdqwFgqEA\"",
    "mtime": "2025-12-29T15:10:09.741Z",
    "size": 106090,
    "path": "../public/hbuilderx-cli/index.html"
  },
  "/hbuilderx-vanilla/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"75-7yRkEDksf7ykKYyS4yzZxvcI+Kk\"",
    "mtime": "2025-12-29T15:10:09.014Z",
    "size": 117,
    "path": "../public/hbuilderx-vanilla/index.html"
  },
  "/packages/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"22f1-WReuYj0EE5ZkeZB6LCPV2JOvMKE\"",
    "mtime": "2025-12-29T15:10:32.700Z",
    "size": 8945,
    "path": "../public/packages/_payload.json"
  },
  "/packages/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1b774-yAulEFP+powhdUrpSasb7nGhOGg\"",
    "mtime": "2025-12-29T15:10:11.608Z",
    "size": 112500,
    "path": "../public/packages/index.html"
  },
  "/plugin-uni/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1255-3wBxU0juatGhNFQ69FJdy04yL/c\"",
    "mtime": "2025-12-29T15:10:32.667Z",
    "size": 4693,
    "path": "../public/plugin-uni/_payload.json"
  },
  "/plugin-uni/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1f6ef-Kh4H7g0RmvmknCMl9fw6z6v1ECw\"",
    "mtime": "2025-12-29T15:10:11.412Z",
    "size": 128751,
    "path": "../public/plugin-uni/index.html"
  },
  "/relations/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"2b88-qqetgC8LnIb7prtiBS5iRHQd+gc\"",
    "mtime": "2025-12-29T15:10:39.399Z",
    "size": 11144,
    "path": "../public/relations/_payload.json"
  },
  "/relations/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1323d-+Jh3EUih2UyiSCwI82YUd72bs2c\"",
    "mtime": "2025-12-29T15:10:14.125Z",
    "size": 78397,
    "path": "../public/relations/index.html"
  },
  "/sitemap.xml/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"68-l9jsPo6sU6PxyzeP+P1pUxbRoP0\"",
    "mtime": "2025-12-29T15:10:28.373Z",
    "size": 104,
    "path": "../public/sitemap.xml/index.html"
  },
  "/unh/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"67-+bBCdrhRC31Uzfb7Zw5KkCPqmYE\"",
    "mtime": "2025-12-29T15:10:11.193Z",
    "size": 103,
    "path": "../public/unh/index.html"
  },
  "/uni-deploy/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1231-fMv5m9srYwAa8zKZnvorENXOdhc\"",
    "mtime": "2025-12-29T15:10:32.755Z",
    "size": 4657,
    "path": "../public/uni-deploy/_payload.json"
  },
  "/uni-deploy/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"385d1-i/ZUVSktnI1VzcRXhjEBdyX2l3g\"",
    "mtime": "2025-12-29T15:10:11.655Z",
    "size": 230865,
    "path": "../public/uni-deploy/index.html"
  },
  "/uni-devtools/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1226-J5A0o5Qp2v3CzE8a6W9+YnetPbI\"",
    "mtime": "2025-12-29T15:10:35.537Z",
    "size": 4646,
    "path": "../public/uni-devtools/_payload.json"
  },
  "/uni-devtools/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1a3c5-0EU52S46gniqno9nDauIOgMEECY\"",
    "mtime": "2025-12-29T15:10:11.895Z",
    "size": 107461,
    "path": "../public/uni-devtools/index.html"
  },
  "/uni-env/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"106a-e8OhWzdwbg0xCOC0NXHjKs6OHbM\"",
    "mtime": "2025-12-29T15:10:33.928Z",
    "size": 4202,
    "path": "../public/uni-env/_payload.json"
  },
  "/uni-env/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18851-iaUSJYV56WXaodtQ8YqtqR157p4\"",
    "mtime": "2025-12-29T15:10:11.879Z",
    "size": 100433,
    "path": "../public/uni-env/index.html"
  },
  "/uni-network/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"75-sFlLgMoYQ6kEYjhTJjMWFNil9xg\"",
    "mtime": "2025-12-29T15:10:12.442Z",
    "size": 117,
    "path": "../public/uni-network/index.html"
  },
  "/uni-promises/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1082-Eq33s6eq1Sq+3X0aMUvyPMcSBvk\"",
    "mtime": "2025-12-29T15:10:42.013Z",
    "size": 4226,
    "path": "../public/uni-promises/_payload.json"
  },
  "/uni-promises/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"33eb9-f/GRlaXt/k2sHRQ8sBG6JVW4emA\"",
    "mtime": "2025-12-29T15:10:15.988Z",
    "size": 212665,
    "path": "../public/uni-promises/index.html"
  },
  "/uni-typed/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"76-YlIYNXSDkqwP3rUf++kG3af+4no\"",
    "mtime": "2025-12-29T15:10:15.878Z",
    "size": 118,
    "path": "../public/uni-typed/index.html"
  },
  "/uni-typed/uni-app-types-example.png": {
    "type": "image/png",
    "etag": "\"506e-t2Mu/FhRzRN5+xkQgbMD0z9iDKI\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 20590,
    "path": "../public/uni-typed/uni-app-types-example.png"
  },
  "/uni-typed/uni-cloud-types-example.png": {
    "type": "image/png",
    "etag": "\"7ce1-ViZcqY8R1loA0ZBYYBIzRM3q0a0\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 31969,
    "path": "../public/uni-typed/uni-cloud-types-example.png"
  },
  "/uni-typed/uni-ui-types-example.png": {
    "type": "image/png",
    "etag": "\"615c-Yaqr3l5uiAibEvPTNyp2fDzdPVU\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 24924,
    "path": "../public/uni-typed/uni-ui-types-example.png"
  },
  "/uni-typed/vsc-extension.png": {
    "type": "image/png",
    "etag": "\"573e4-zLIFOBXghgKBoremRvmP+JYRM5s\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 357348,
    "path": "../public/uni-typed/vsc-extension.png"
  },
  "/uni-typed/webstorm-settings.png": {
    "type": "image/png",
    "etag": "\"68aeb-oQfUvbXzzoUAfBqvpZu5CvL+j4A\"",
    "mtime": "2025-12-29T15:11:07.524Z",
    "size": 428779,
    "path": "../public/uni-typed/webstorm-settings.png"
  },
  "/uni-use/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"71-tMSRWVOd/fgaeqHPbISU43WayGY\"",
    "mtime": "2025-12-29T15:10:17.463Z",
    "size": 113,
    "path": "../public/uni-use/index.html"
  },
  "/unocss-preset-uni/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"15ad-ETgFq6T3kWRuUzzuqVY2HvQlxAI\"",
    "mtime": "2025-12-29T15:10:58.914Z",
    "size": 5549,
    "path": "../public/unocss-preset-uni/_payload.json"
  },
  "/unocss-preset-uni/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2f75e-BHoQk7g/x1cm1owl6yecdzC4GNk\"",
    "mtime": "2025-12-29T15:10:24.759Z",
    "size": 194398,
    "path": "../public/unocss-preset-uni/index.html"
  },
  "/vite-plugin-uni-components/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1281-hrTIejvWPhQKIcJjlHCxJZ49rX4\"",
    "mtime": "2025-12-29T15:10:58.016Z",
    "size": 4737,
    "path": "../public/vite-plugin-uni-components/_payload.json"
  },
  "/vite-plugin-uni-components/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1e45a-eww4wyRyvshxYXkQC6K/P8JsRH8\"",
    "mtime": "2025-12-29T15:10:24.487Z",
    "size": 123994,
    "path": "../public/vite-plugin-uni-components/index.html"
  },
  "/vite-plugin-uni-layouts/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1271-BJaWsXgPzClgj1BxEKXHi1qJmfk\"",
    "mtime": "2025-12-29T15:10:58.619Z",
    "size": 4721,
    "path": "../public/vite-plugin-uni-layouts/_payload.json"
  },
  "/vite-plugin-uni-layouts/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"27661-4KAdKRHIajjGRyW1rOiyha7zhUw\"",
    "mtime": "2025-12-29T15:10:24.654Z",
    "size": 161377,
    "path": "../public/vite-plugin-uni-layouts/index.html"
  },
  "/vite-plugin-uni-manifest/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1276-uHwK94a+QSc/uegGmwF0//9ipQQ\"",
    "mtime": "2025-12-29T15:10:58.909Z",
    "size": 4726,
    "path": "../public/vite-plugin-uni-manifest/_payload.json"
  },
  "/vite-plugin-uni-manifest/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1bf0a-UdbC7236NW+ZnenfBYMYRoJlvlQ\"",
    "mtime": "2025-12-29T15:10:24.693Z",
    "size": 114442,
    "path": "../public/vite-plugin-uni-manifest/index.html"
  },
  "/vite-plugin-uni-middleware/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1280-m+7VxHbu5umUn1xYCusBP5cRbSM\"",
    "mtime": "2025-12-29T15:10:58.986Z",
    "size": 4736,
    "path": "../public/vite-plugin-uni-middleware/_payload.json"
  },
  "/vite-plugin-uni-middleware/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"22d95-peGPOiNioM9P+9rCdvYpRtB4hZA\"",
    "mtime": "2025-12-29T15:10:24.759Z",
    "size": 142741,
    "path": "../public/vite-plugin-uni-middleware/index.html"
  },
  "/vite-plugin-uni-pages/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"72-xCncoWa2XQ321tmmZlEPLEjo3wg\"",
    "mtime": "2025-12-29T15:10:24.898Z",
    "size": 114,
    "path": "../public/vite-plugin-uni-pages/index.html"
  },
  "/vite-plugin-uni-platform/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1277-3zl+F4uvFE8/VsyBJik6cnGG50E\"",
    "mtime": "2025-12-29T15:10:59.541Z",
    "size": 4727,
    "path": "../public/vite-plugin-uni-platform/_payload.json"
  },
  "/vite-plugin-uni-platform/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1b2a0-bGszRnoEg3wF7WsbR/XOJmQJM1I\"",
    "mtime": "2025-12-29T15:10:25.149Z",
    "size": 111264,
    "path": "../public/vite-plugin-uni-platform/index.html"
  },
  "/vite-plugin-uni-platform-modifier/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"12a3-5FbaJuS/wVje2p9Dj/wEXTJE26c\"",
    "mtime": "2025-12-29T15:10:59.767Z",
    "size": 4771,
    "path": "../public/vite-plugin-uni-platform-modifier/_payload.json"
  },
  "/vite-plugin-uni-platform-modifier/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"22006-EshAX7j4DMAZSy/asCRk0Vc/WW8\"",
    "mtime": "2025-12-29T15:10:25.149Z",
    "size": 139270,
    "path": "../public/vite-plugin-uni-platform-modifier/index.html"
  },
  "/vitesse-uni-app/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"83-Z1qb55bpAMpVpJrmLMdA8HTq2YE\"",
    "mtime": "2025-12-29T15:10:25.221Z",
    "size": 131,
    "path": "../public/vitesse-uni-app/index.html"
  },
  "/vs-code/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-+ON9saIs5ThILeghh6CpxGqpnXc\"",
    "mtime": "2025-12-29T15:11:03.710Z",
    "size": 486,
    "path": "../public/vs-code/_payload.json"
  },
  "/vs-code/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"111ef-RjorwIWcwlCkuNbB/CVv93QF6Ng\"",
    "mtime": "2025-12-29T15:10:27.083Z",
    "size": 70127,
    "path": "../public/vs-code/index.html"
  },
  "/_ipx/_/logo-dark.svg": {
    "type": "image/svg+xml",
    "etag": "\"934-DP7jqUNG6Z0tLsPhjE0sQx78Qlw\"",
    "mtime": "2025-12-29T15:10:27.644Z",
    "size": 2356,
    "path": "../public/_ipx/_/logo-dark.svg"
  },
  "/_ipx/_/logo.svg": {
    "type": "image/svg+xml",
    "etag": "\"931-CorJECT6kD4MssVYm8ZXzfl9G5Y\"",
    "mtime": "2025-12-29T15:10:27.834Z",
    "size": 2353,
    "path": "../public/_ipx/_/logo.svg"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-/tWJucPOvsLT/v5a86H1iGDPs7E\"",
    "mtime": "2025-12-29T15:11:07.438Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/api/_content/cache.1767020924919.json": {
    "type": "application/json",
    "etag": "\"26bf02-8if91ep+wUSwIZ71r69g/cKJouw\"",
    "mtime": "2025-12-29T15:10:09.736Z",
    "size": 2539266,
    "path": "../public/api/_content/cache.1767020924919.json"
  },
  "/api/_content/packages.json": {
    "type": "application/json",
    "etag": "\"3c83-U1yE/FqOop5FvS6awMPadk6uTN4\"",
    "mtime": "2025-12-29T15:10:27.083Z",
    "size": 15491,
    "path": "../public/api/_content/packages.json"
  },
  "/api/_content/releases.json": {
    "type": "application/json",
    "etag": "\"9ee5-qKcuKNxRieiPRaRxNb/y6Nnf748\"",
    "mtime": "2025-12-29T15:10:28.274Z",
    "size": 40677,
    "path": "../public/api/_content/releases.json"
  },
  "/api/_content/search-1767020924919": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"4ff8a-QVmU3WmZPy+lG3or4ujv8acTc88\"",
    "mtime": "2025-12-29T15:10:27.106Z",
    "size": 327562,
    "path": "../public/api/_content/search-1767020924919"
  },
  "/blog/definepage/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1444-B9IxuZ7UOKr2X5y0DJ9AcnEumc8\"",
    "mtime": "2025-12-29T15:10:30.964Z",
    "size": 5188,
    "path": "../public/blog/definepage/_payload.json"
  },
  "/blog/definepage/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3c875-mNWgn3M8HmBMPr06BSw/pLr6jeo\"",
    "mtime": "2025-12-29T15:10:09.741Z",
    "size": 247925,
    "path": "../public/blog/definepage/index.html"
  },
  "/blog/unh/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1055-bekJdqyVwZaEdjNjsVRUFkOZF6o\"",
    "mtime": "2025-12-29T15:10:30.215Z",
    "size": 4181,
    "path": "../public/blog/unh/_payload.json"
  },
  "/blog/unh/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2cbb8-vWhK7EvD4DqjLOLZA0mUqIDOQgs\"",
    "mtime": "2025-12-29T15:10:09.741Z",
    "size": 183224,
    "path": "../public/blog/unh/index.html"
  },
  "/create-uni/core/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"2dde-XSybCNPonjIE2WZQYzgYxEaNwds\"",
    "mtime": "2025-12-29T15:10:31.799Z",
    "size": 11742,
    "path": "../public/create-uni/core/_payload.json"
  },
  "/create-uni/core/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"276a1-VPvbsjH1X0ERZbW9aOu9G9NSbgY\"",
    "mtime": "2025-12-29T15:10:09.742Z",
    "size": 161441,
    "path": "../public/create-uni/core/index.html"
  },
  "/create-uni/dark/cli.png": {
    "type": "image/png",
    "etag": "\"6ca09-8M6QkXc5C7TExtMZ8YWN0o9Cp0c\"",
    "mtime": "2025-12-29T15:11:07.522Z",
    "size": 444937,
    "path": "../public/create-uni/dark/cli.png"
  },
  "/create-uni/dark/gui_1.png": {
    "type": "image/png",
    "etag": "\"6af7-P+tUDZoQmKv5OYDG9P9S1xFOJl8\"",
    "mtime": "2025-12-29T15:11:07.522Z",
    "size": 27383,
    "path": "../public/create-uni/dark/gui_1.png"
  },
  "/create-uni/dark/gui_2.png": {
    "type": "image/png",
    "etag": "\"867e-8iK9FODksWmSCN4qOSYJpzDex+Y\"",
    "mtime": "2025-12-29T15:11:07.522Z",
    "size": 34430,
    "path": "../public/create-uni/dark/gui_2.png"
  },
  "/create-uni/dark/gui_3.png": {
    "type": "image/png",
    "etag": "\"6b96-FXWvTXMyepyFLEOSMmrmConWy5c\"",
    "mtime": "2025-12-29T15:11:07.522Z",
    "size": 27542,
    "path": "../public/create-uni/dark/gui_3.png"
  },
  "/create-uni/dark/gui_4.png": {
    "type": "image/png",
    "etag": "\"8f73-ms331aIlW0xA1lVb27JSIK5HrDc\"",
    "mtime": "2025-12-29T15:11:07.522Z",
    "size": 36723,
    "path": "../public/create-uni/dark/gui_4.png"
  },
  "/create-uni/dark/gui_5.png": {
    "type": "image/png",
    "etag": "\"7203-dQa9dcmNnwB9hONCwQeW8Lrp7zg\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 29187,
    "path": "../public/create-uni/dark/gui_5.png"
  },
  "/create-uni/dark/gui_6.png": {
    "type": "image/png",
    "etag": "\"7657-fdJcjm+Skf/b5T0KxKgptwcCHQ8\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 30295,
    "path": "../public/create-uni/dark/gui_6.png"
  },
  "/create-uni/gui/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1234-LdyO2OpWxCx7EoX+JUwoP3fD7KM\"",
    "mtime": "2025-12-29T15:10:30.275Z",
    "size": 4660,
    "path": "../public/create-uni/gui/_payload.json"
  },
  "/create-uni/gui/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"194bf-lDTub/hx8NhTIbrKUbgTQwsNIbU\"",
    "mtime": "2025-12-29T15:10:09.741Z",
    "size": 103615,
    "path": "../public/create-uni/gui/index.html"
  },
  "/create-uni/info/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1049-pN3RMk1FETsPx1j3ns34/wSoxqM\"",
    "mtime": "2025-12-29T15:10:30.501Z",
    "size": 4169,
    "path": "../public/create-uni/info/_payload.json"
  },
  "/create-uni/info/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2324a-Ghqj6xk5xmZra0ZZFPvL4i3xFqc\"",
    "mtime": "2025-12-29T15:10:09.741Z",
    "size": 143946,
    "path": "../public/create-uni/info/index.html"
  },
  "/create-uni/light/gui_1.png": {
    "type": "image/png",
    "etag": "\"7686-ubhhLeQflp6Th3ZqC46VIr4RroQ\"",
    "mtime": "2025-12-29T15:11:07.522Z",
    "size": 30342,
    "path": "../public/create-uni/light/gui_1.png"
  },
  "/create-uni/light/gui_2.png": {
    "type": "image/png",
    "etag": "\"9ea3-RBOTqR9KWwf92V0R3n9tQxeGv04\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 40611,
    "path": "../public/create-uni/light/gui_2.png"
  },
  "/create-uni/light/gui_3.png": {
    "type": "image/png",
    "etag": "\"7dcf-cUJ/zfGilwP9S9cYbXa5cfwPgIE\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 32207,
    "path": "../public/create-uni/light/gui_3.png"
  },
  "/create-uni/light/gui_4.png": {
    "type": "image/png",
    "etag": "\"a78f-IwRVim3WRDc6AwQXLtcYqUm8ohc\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 42895,
    "path": "../public/create-uni/light/gui_4.png"
  },
  "/create-uni/light/gui_5.png": {
    "type": "image/png",
    "etag": "\"78a4-WTV8QcafTbFuUzMKn6WRl+bEeIY\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 30884,
    "path": "../public/create-uni/light/gui_5.png"
  },
  "/create-uni/light/gui_6.png": {
    "type": "image/png",
    "etag": "\"8537-fph9wYmKgOL+d2dWlgrHZ32F2aw\"",
    "mtime": "2025-12-29T15:11:07.523Z",
    "size": 34103,
    "path": "../public/create-uni/light/gui_6.png"
  },
  "/create-uni/mcp/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-iSV5NLTIKwmO94KLRLqE99CYrGo\"",
    "mtime": "2025-12-29T15:10:30.079Z",
    "size": 486,
    "path": "../public/create-uni/mcp/_payload.json"
  },
  "/create-uni/mcp/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18cca-/5LXDJdXS41yJ6snW8gwd1XQYh4\"",
    "mtime": "2025-12-29T15:10:09.476Z",
    "size": 101578,
    "path": "../public/create-uni/mcp/index.html"
  },
  "/hbuilderx-vanilla/api/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-9CzIihUZB1GrJmILORYflLjkbYk\"",
    "mtime": "2025-12-29T15:10:31.799Z",
    "size": 486,
    "path": "../public/hbuilderx-vanilla/api/_payload.json"
  },
  "/hbuilderx-vanilla/api/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3a623-p3+DW3XVKnQSv5vgQ1q368REGeg\"",
    "mtime": "2025-12-29T15:10:10.509Z",
    "size": 239139,
    "path": "../public/hbuilderx-vanilla/api/index.html"
  },
  "/hbuilderx-vanilla/build/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-mZtBf1sns5LW4fkbHpSmiAZgEaw\"",
    "mtime": "2025-12-29T15:10:32.048Z",
    "size": 486,
    "path": "../public/hbuilderx-vanilla/build/_payload.json"
  },
  "/hbuilderx-vanilla/build/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2e538-vpVpgEgUqYvIVVDC0MP6WgWHgkg\"",
    "mtime": "2025-12-29T15:10:10.513Z",
    "size": 189752,
    "path": "../public/hbuilderx-vanilla/build/index.html"
  },
  "/hbuilderx-vanilla/introduction/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-iiEhkmJa1kJ835drLlxGUiHQNTk\"",
    "mtime": "2025-12-29T15:10:32.083Z",
    "size": 486,
    "path": "../public/hbuilderx-vanilla/introduction/_payload.json"
  },
  "/hbuilderx-vanilla/introduction/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"21856-0u/2QyITuxq5ZIgs87xhGLEAiHU\"",
    "mtime": "2025-12-29T15:10:10.775Z",
    "size": 137302,
    "path": "../public/hbuilderx-vanilla/introduction/index.html"
  },
  "/unh/alias/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-6nYpYqwI5sLmclEMlNbehJSg3HY\"",
    "mtime": "2025-12-29T15:10:34.872Z",
    "size": 486,
    "path": "../public/unh/alias/_payload.json"
  },
  "/unh/alias/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1d261-IJwbjgC1lP15EU2Z29Qc/1z3/K8\"",
    "mtime": "2025-12-29T15:10:11.880Z",
    "size": 119393,
    "path": "../public/unh/alias/index.html"
  },
  "/unh/auto-generate/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-6nYpYqwI5sLmclEMlNbehJSg3HY\"",
    "mtime": "2025-12-29T15:10:34.431Z",
    "size": 486,
    "path": "../public/unh/auto-generate/_payload.json"
  },
  "/unh/auto-generate/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1e244-9VWTCfHIBqWcvDXOpfGompmF7b8\"",
    "mtime": "2025-12-29T15:10:11.879Z",
    "size": 123460,
    "path": "../public/unh/auto-generate/index.html"
  },
  "/unh/devtools/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-VHjf1imBfdI0D9K9CgV70w1pwwA\"",
    "mtime": "2025-12-29T15:10:34.660Z",
    "size": 486,
    "path": "../public/unh/devtools/_payload.json"
  },
  "/unh/devtools/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1c7b5-bmGpiftomSf0ibUMeFknxvq2R4c\"",
    "mtime": "2025-12-29T15:10:11.879Z",
    "size": 116661,
    "path": "../public/unh/devtools/index.html"
  },
  "/unh/env/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-6nYpYqwI5sLmclEMlNbehJSg3HY\"",
    "mtime": "2025-12-29T15:10:33.962Z",
    "size": 486,
    "path": "../public/unh/env/_payload.json"
  },
  "/unh/env/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1dc8d-HEvoWXIBrhqUfmQw3/cb0LXpMtk\"",
    "mtime": "2025-12-29T15:10:11.879Z",
    "size": 121997,
    "path": "../public/unh/env/index.html"
  },
  "/unh/hooks/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-6nYpYqwI5sLmclEMlNbehJSg3HY\"",
    "mtime": "2025-12-29T15:10:34.236Z",
    "size": 486,
    "path": "../public/unh/hooks/_payload.json"
  },
  "/unh/hooks/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1da7c-NJ4ltkiHgs+OvH1ZilnuHSrKmWU\"",
    "mtime": "2025-12-29T15:10:11.879Z",
    "size": 121468,
    "path": "../public/unh/hooks/index.html"
  },
  "/unh/installation/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1bd2-nI7PM8USCAx+FeV26Bv4ppMBQkE\"",
    "mtime": "2025-12-29T15:10:35.423Z",
    "size": 7122,
    "path": "../public/unh/installation/_payload.json"
  },
  "/unh/installation/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"23c12-xFivgtPF1Xfr3dw5L3DZsOC57KY\"",
    "mtime": "2025-12-29T15:10:11.885Z",
    "size": 146450,
    "path": "../public/unh/installation/index.html"
  },
  "/uni-network/advanced/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-U6j3lwshCtk5VxnY90i2aSQotX4\"",
    "mtime": "2025-12-29T15:10:35.972Z",
    "size": 486,
    "path": "../public/uni-network/advanced/_payload.json"
  },
  "/uni-network/advanced/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"15296-Wdl3FpE2OpZJCpazOjn6LMDe1GE\"",
    "mtime": "2025-12-29T15:10:13.147Z",
    "size": 86678,
    "path": "../public/uni-network/advanced/index.html"
  },
  "/uni-network/api/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-vELhfC1f+E8dCHJj9XutW2EwZpk\"",
    "mtime": "2025-12-29T15:10:38.357Z",
    "size": 486,
    "path": "../public/uni-network/api/_payload.json"
  },
  "/uni-network/api/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1526d-XhpKf/2YQGvXY06QHh/N04AVkmI\"",
    "mtime": "2025-12-29T15:10:14.050Z",
    "size": 86637,
    "path": "../public/uni-network/api/index.html"
  },
  "/uni-network/guide/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-DJ/lMzC30xZTheB99ynGsYGrZr8\"",
    "mtime": "2025-12-29T15:10:39.844Z",
    "size": 486,
    "path": "../public/uni-network/guide/_payload.json"
  },
  "/uni-network/guide/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1527c-wYlzKccY5DikZsRAAVuxr7d/Upk\"",
    "mtime": "2025-12-29T15:10:14.142Z",
    "size": 86652,
    "path": "../public/uni-network/guide/index.html"
  },
  "/uni-network/other/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-OBq/AtGW0G5sP0SqDXStD4Khqtg\"",
    "mtime": "2025-12-29T15:10:40.463Z",
    "size": 486,
    "path": "../public/uni-network/other/_payload.json"
  },
  "/uni-network/other/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1527d-ir301A4y/wCBKglKl4UYRjlqB0M\"",
    "mtime": "2025-12-29T15:10:15.184Z",
    "size": 86653,
    "path": "../public/uni-network/other/index.html"
  },
  "/uni-typed/guide/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-hdujHdLlkuqZATaWLG64gKlrBNI\"",
    "mtime": "2025-12-29T15:10:42.239Z",
    "size": 486,
    "path": "../public/uni-typed/guide/_payload.json"
  },
  "/uni-typed/guide/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"11e12-z2Np/ftucSuzOOeQjZ5PXzdN0bI\"",
    "mtime": "2025-12-29T15:10:16.201Z",
    "size": 73234,
    "path": "../public/uni-typed/guide/index.html"
  },
  "/uni-typed/other/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-gF2EzPueZMDwdEh2I89sDa8oc1M\"",
    "mtime": "2025-12-29T15:10:45.202Z",
    "size": 486,
    "path": "../public/uni-typed/other/_payload.json"
  },
  "/uni-typed/other/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"11e13-Vu8AYX96oq1XxhxH68/zTm7Gtf0\"",
    "mtime": "2025-12-29T15:10:17.163Z",
    "size": 73235,
    "path": "../public/uni-typed/other/index.html"
  },
  "/uni-use/api/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-5dnbf2E67AiizSWaIrqS3B5h9yk\"",
    "mtime": "2025-12-29T15:10:46.310Z",
    "size": 486,
    "path": "../public/uni-use/api/_payload.json"
  },
  "/uni-use/api/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"12aff-Ix0nyw7fQ+1nJU4QUW1LL1SveM4\"",
    "mtime": "2025-12-29T15:10:17.759Z",
    "size": 76543,
    "path": "../public/uni-use/api/index.html"
  },
  "/uni-use/guide/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-hhCLBEWq5Gk4FFFiZjuVun6WM2Q\"",
    "mtime": "2025-12-29T15:10:57.405Z",
    "size": 486,
    "path": "../public/uni-use/guide/_payload.json"
  },
  "/uni-use/guide/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"12b0e-4GDidN/EZA3snBvBpriGPvfnwxc\"",
    "mtime": "2025-12-29T15:10:23.938Z",
    "size": 76558,
    "path": "../public/uni-use/guide/index.html"
  },
  "/vite-plugin-uni-pages/definepage/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"108f-gyxgd+MaV+MgnoZDZGYC6FluqFM\"",
    "mtime": "2025-12-29T15:11:01.064Z",
    "size": 4239,
    "path": "../public/vite-plugin-uni-pages/definepage/_payload.json"
  },
  "/vite-plugin-uni-pages/definepage/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"32eab-p2jm8CiXl/k3hddzZWFEJcqsQ6s\"",
    "mtime": "2025-12-29T15:10:25.265Z",
    "size": 208555,
    "path": "../public/vite-plugin-uni-pages/definepage/index.html"
  },
  "/vite-plugin-uni-pages/extension/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-zXh3XFdpEEW4XQA2GpneBBwSgzU\"",
    "mtime": "2025-12-29T15:11:00.855Z",
    "size": 486,
    "path": "../public/vite-plugin-uni-pages/extension/_payload.json"
  },
  "/vite-plugin-uni-pages/extension/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2f83f-hpP+neBcVtUlNYHMlyi6VEwg5no\"",
    "mtime": "2025-12-29T15:10:25.221Z",
    "size": 194623,
    "path": "../public/vite-plugin-uni-pages/extension/index.html"
  },
  "/vite-plugin-uni-pages/guide/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"10af-nUL26rEifQVPCYErkJpoon7Eu6k\"",
    "mtime": "2025-12-29T15:11:00.834Z",
    "size": 4271,
    "path": "../public/vite-plugin-uni-pages/guide/_payload.json"
  },
  "/vite-plugin-uni-pages/guide/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"22028-JnVWLlZ4aDcGcNSZMEvVqEqA6LA\"",
    "mtime": "2025-12-29T15:10:25.221Z",
    "size": 139304,
    "path": "../public/vite-plugin-uni-pages/guide/index.html"
  },
  "/vite-plugin-uni-pages/option/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-zXh3XFdpEEW4XQA2GpneBBwSgzU\"",
    "mtime": "2025-12-29T15:11:00.816Z",
    "size": 486,
    "path": "../public/vite-plugin-uni-pages/option/_payload.json"
  },
  "/vite-plugin-uni-pages/option/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"215f8-zFEfUdGX1hP2oRwulUgdGQhj35c\"",
    "mtime": "2025-12-29T15:10:25.221Z",
    "size": 136696,
    "path": "../public/vite-plugin-uni-pages/option/index.html"
  },
  "/vitesse-uni-app/getting-started/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"83-Z1qb55bpAMpVpJrmLMdA8HTq2YE\"",
    "mtime": "2025-12-29T15:10:26.015Z",
    "size": 131,
    "path": "../public/vitesse-uni-app/getting-started/index.html"
  },
  "/vitesse-uni-app/guide/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"79-sn9ZkHinJI10gOzlBviAtY8EpKM\"",
    "mtime": "2025-12-29T15:10:26.707Z",
    "size": 121,
    "path": "../public/vitesse-uni-app/guide/index.html"
  },
  "/vs-code/uni-app-schemas-vscode/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-+ON9saIs5ThILeghh6CpxGqpnXc\"",
    "mtime": "2025-12-29T15:11:04.939Z",
    "size": 486,
    "path": "../public/vs-code/uni-app-schemas-vscode/_payload.json"
  },
  "/vs-code/uni-app-schemas-vscode/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"15f72-NFxHZvJbgLtW3M5/ejRrL6Po/Ho\"",
    "mtime": "2025-12-29T15:10:27.139Z",
    "size": 89970,
    "path": "../public/vs-code/uni-app-schemas-vscode/index.html"
  },
  "/vs-code/uni-app-snippets-vscode/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-lZNkXzZs1cNqlVoDNN+6IeabafM\"",
    "mtime": "2025-12-29T15:11:05.002Z",
    "size": 486,
    "path": "../public/vs-code/uni-app-snippets-vscode/_payload.json"
  },
  "/vs-code/uni-app-snippets-vscode/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"16430-qXPxs2tZ7bwT7p1xYYe/DXRPFCE\"",
    "mtime": "2025-12-29T15:10:27.173Z",
    "size": 91184,
    "path": "../public/vs-code/uni-app-snippets-vscode/index.html"
  },
  "/vs-code/uni-cloud-snippets-vscode/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-Jic+vgT1pE2BJukbPPa8doOdB9I\"",
    "mtime": "2025-12-29T15:11:04.971Z",
    "size": 486,
    "path": "../public/vs-code/uni-cloud-snippets-vscode/_payload.json"
  },
  "/vs-code/uni-cloud-snippets-vscode/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"164bd-qiWCAcxZh8q1Yt02/6ZJccE4Pt4\"",
    "mtime": "2025-12-29T15:10:27.159Z",
    "size": 91325,
    "path": "../public/vs-code/uni-cloud-snippets-vscode/index.html"
  },
  "/vs-code/uni-create-view/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-TbvtijkD77XAm6A5ZuEk4MayDs0\"",
    "mtime": "2025-12-29T15:11:05.265Z",
    "size": 486,
    "path": "../public/vs-code/uni-create-view/_payload.json"
  },
  "/vs-code/uni-create-view/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"17c59-24AEFwvYKQzTj2wKhqQ6gWp4Arc\"",
    "mtime": "2025-12-29T15:10:28.036Z",
    "size": 97369,
    "path": "../public/vs-code/uni-create-view/index.html"
  },
  "/vs-code/uni-helper-vscode/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-mcIySnRpcASDQKnmyM7aFjL44tU\"",
    "mtime": "2025-12-29T15:11:05.245Z",
    "size": 486,
    "path": "../public/vs-code/uni-helper-vscode/_payload.json"
  },
  "/vs-code/uni-helper-vscode/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1c72e-WcwVdLFI9XkPgb3Qa0EQa3VkIPA\"",
    "mtime": "2025-12-29T15:10:27.947Z",
    "size": 116526,
    "path": "../public/vs-code/uni-helper-vscode/index.html"
  },
  "/vs-code/uni-highlight-vscode/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-msb5n/oysSRvzJ1mLBNIaVzbIW4\"",
    "mtime": "2025-12-29T15:11:05.850Z",
    "size": 486,
    "path": "../public/vs-code/uni-highlight-vscode/_payload.json"
  },
  "/vs-code/uni-highlight-vscode/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1a0ad-1y6ydhdh+4voGrMMyqgcp/bqzKA\"",
    "mtime": "2025-12-29T15:10:28.361Z",
    "size": 106669,
    "path": "../public/vs-code/uni-highlight-vscode/index.html"
  },
  "/vs-code/uni-ui-snippets-vscode/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-wuBTLy1cmP1BTwEz2uIiF3lAKjc\"",
    "mtime": "2025-12-29T15:11:05.321Z",
    "size": 486,
    "path": "../public/vs-code/uni-ui-snippets-vscode/_payload.json"
  },
  "/vs-code/uni-ui-snippets-vscode/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1640c-kmtxka/Tsg04m6mBXUZEKBqiPL8\"",
    "mtime": "2025-12-29T15:10:28.235Z",
    "size": 91148,
    "path": "../public/vs-code/uni-ui-snippets-vscode/index.html"
  },
  "/__og-image__/static/about/og.png": {
    "type": "image/png",
    "etag": "\"a3ce-MgvmWsrO+Gtr0HKIoDmC0+EXqpQ\"",
    "mtime": "2025-12-29T15:10:29.999Z",
    "size": 41934,
    "path": "../public/__og-image__/static/about/og.png"
  },
  "/__og-image__/static/awesome-uni-app/og.png": {
    "type": "image/png",
    "etag": "\"b3d0-s1Dm0rh3g7IBKRfpZMIDlaxDfco\"",
    "mtime": "2025-12-29T15:10:29.999Z",
    "size": 46032,
    "path": "../public/__og-image__/static/awesome-uni-app/og.png"
  },
  "/__og-image__/static/axios-adapter/og.png": {
    "type": "image/png",
    "etag": "\"a47c-HtIGLDC2W66uIu2xib/FORvr6g0\"",
    "mtime": "2025-12-29T15:10:32.754Z",
    "size": 42108,
    "path": "../public/__og-image__/static/axios-adapter/og.png"
  },
  "/__og-image__/static/blog/og.png": {
    "type": "image/png",
    "etag": "\"ab2e-aeNjwj+qqa5IwUtiUVZl8KSfoZo\"",
    "mtime": "2025-12-29T15:10:29.999Z",
    "size": 43822,
    "path": "../public/__og-image__/static/blog/og.png"
  },
  "/__og-image__/static/changelog/og.png": {
    "type": "image/png",
    "etag": "\"c15c-cvNAXb49ZodBp6X6grdus0qnQQk\"",
    "mtime": "2025-12-29T15:11:07.383Z",
    "size": 49500,
    "path": "../public/__og-image__/static/changelog/og.png"
  },
  "/__og-image__/static/eslint-config/og.png": {
    "type": "image/png",
    "etag": "\"a15f-SWBEavk2bwf+Vdo3NWQxNpOdfJc\"",
    "mtime": "2025-12-29T15:10:31.793Z",
    "size": 41311,
    "path": "../public/__og-image__/static/eslint-config/og.png"
  },
  "/__og-image__/static/hbuilderx-cli/og.png": {
    "type": "image/png",
    "etag": "\"926c-9UXljS8oiBzGQVHM6ZXIt0koDsE\"",
    "mtime": "2025-12-29T15:10:30.961Z",
    "size": 37484,
    "path": "../public/__og-image__/static/hbuilderx-cli/og.png"
  },
  "/__og-image__/static/packages/og.png": {
    "type": "image/png",
    "etag": "\"d787-zcf57PYeEmSewAygrWtOuU/9UT4\"",
    "mtime": "2025-12-29T15:10:34.660Z",
    "size": 55175,
    "path": "../public/__og-image__/static/packages/og.png"
  },
  "/__og-image__/static/plugin-uni/og.png": {
    "type": "image/png",
    "etag": "\"ca9d-kmfwNFIwT2ACA5SwwjIZS56YieY\"",
    "mtime": "2025-12-29T15:10:34.486Z",
    "size": 51869,
    "path": "../public/__og-image__/static/plugin-uni/og.png"
  },
  "/__og-image__/static/relations/og.png": {
    "type": "image/png",
    "etag": "\"9b3c-rluydebu587PB/XXR3nlJFCVz/c\"",
    "mtime": "2025-12-29T15:10:41.266Z",
    "size": 39740,
    "path": "../public/__og-image__/static/relations/og.png"
  },
  "/__og-image__/static/uni-deploy/og.png": {
    "type": "image/png",
    "etag": "\"8815-BLEa3J86N1LSwA9cJahfClKzhFg\"",
    "mtime": "2025-12-29T15:10:35.507Z",
    "size": 34837,
    "path": "../public/__og-image__/static/uni-deploy/og.png"
  },
  "/__og-image__/static/uni-devtools/og.png": {
    "type": "image/png",
    "etag": "\"9d73-5ulmVMyLd/qLg1yCudBz7cMU6+M\"",
    "mtime": "2025-12-29T15:10:37.492Z",
    "size": 40307,
    "path": "../public/__og-image__/static/uni-devtools/og.png"
  },
  "/__og-image__/static/uni-env/og.png": {
    "type": "image/png",
    "etag": "\"8861-dx0XE0wBNQRDti3i9Lybfd4Lp7U\"",
    "mtime": "2025-12-29T15:10:35.536Z",
    "size": 34913,
    "path": "../public/__og-image__/static/uni-env/og.png"
  },
  "/__og-image__/static/uni-promises/og.png": {
    "type": "image/png",
    "etag": "\"a5b1-7H+lK+9Mi4uuAPQNxtR872MMBGs\"",
    "mtime": "2025-12-29T15:10:43.732Z",
    "size": 42417,
    "path": "../public/__og-image__/static/uni-promises/og.png"
  },
  "/__og-image__/static/unocss-preset-uni/og.png": {
    "type": "image/png",
    "etag": "\"9f59-DMwikNCKIXXt5Sz1lhA81qI1CSQ\"",
    "mtime": "2025-12-29T15:11:00.796Z",
    "size": 40793,
    "path": "../public/__og-image__/static/unocss-preset-uni/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-components/og.png": {
    "type": "image/png",
    "etag": "\"d5ad-WWnyP8WaXx6rir2+hKuvjDYPkVU\"",
    "mtime": "2025-12-29T15:10:59.750Z",
    "size": 54701,
    "path": "../public/__og-image__/static/vite-plugin-uni-components/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-layouts/og.png": {
    "type": "image/png",
    "etag": "\"af42-lrEAmmxCxQsqeEI2eN02PZPKqpw\"",
    "mtime": "2025-12-29T15:11:00.556Z",
    "size": 44866,
    "path": "../public/__og-image__/static/vite-plugin-uni-layouts/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-manifest/og.png": {
    "type": "image/png",
    "etag": "\"c0fc-DozSCQz1DuAa/m4zlqpL2ddNU2g\"",
    "mtime": "2025-12-29T15:11:00.768Z",
    "size": 49404,
    "path": "../public/__og-image__/static/vite-plugin-uni-manifest/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-middleware/og.png": {
    "type": "image/png",
    "etag": "\"c577-ovtjapNCfV+8Eqplr3v9AP6xbFA\"",
    "mtime": "2025-12-29T15:11:01.026Z",
    "size": 50551,
    "path": "../public/__og-image__/static/vite-plugin-uni-middleware/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-platform/og.png": {
    "type": "image/png",
    "etag": "\"cbca-VI2B63xrhiV2oOPy+ysQcoDlxxE\"",
    "mtime": "2025-12-29T15:11:01.455Z",
    "size": 52170,
    "path": "../public/__og-image__/static/vite-plugin-uni-platform/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-platform-modifier/og.png": {
    "type": "image/png",
    "etag": "\"d6c9-ef6UutRMKTF7faTzPJoRQwidx2o\"",
    "mtime": "2025-12-29T15:11:01.701Z",
    "size": 54985,
    "path": "../public/__og-image__/static/vite-plugin-uni-platform-modifier/og.png"
  },
  "/__og-image__/static/vs-code/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:11:04.762Z",
    "size": 40520,
    "path": "../public/__og-image__/static/vs-code/og.png"
  },
  "/_i18n/sDWhWKyf/zh/messages.json": {
    "type": "application/json",
    "etag": "\"9-rGU+NmtrN9SRU4i3aiTrn2uyb20\"",
    "mtime": "2025-12-29T15:10:27.208Z",
    "size": 9,
    "path": "../public/_i18n/sDWhWKyf/zh/messages.json"
  },
  "/_ipx/_/devtools/demo.png": {
    "type": "image/png",
    "etag": "\"38264-2lXpzTJSfo41k9QXr0MgVLKrcSI\"",
    "mtime": "2025-12-29T15:10:35.964Z",
    "size": 229988,
    "path": "../public/_ipx/_/devtools/demo.png"
  },
  "/_ipx/_/uni-typed/uni-app-types-example.png": {
    "type": "image/png",
    "etag": "\"3b59-6XoAOU9R6/jYW620mq0s7MYLfTk\"",
    "mtime": "2025-12-29T15:10:44.139Z",
    "size": 15193,
    "path": "../public/_ipx/_/uni-typed/uni-app-types-example.png"
  },
  "/_ipx/_/uni-typed/uni-cloud-types-example.png": {
    "type": "image/png",
    "etag": "\"5ad8-yRtf+89xBwuW3V3zrxcyyNEEbMk\"",
    "mtime": "2025-12-29T15:10:44.059Z",
    "size": 23256,
    "path": "../public/_ipx/_/uni-typed/uni-cloud-types-example.png"
  },
  "/_ipx/_/uni-typed/uni-ui-types-example.png": {
    "type": "image/png",
    "etag": "\"478a-pfGPeSLAACvDy6/eKKEoGEnP584\"",
    "mtime": "2025-12-29T15:10:44.540Z",
    "size": 18314,
    "path": "../public/_ipx/_/uni-typed/uni-ui-types-example.png"
  },
  "/_ipx/_/uni-typed/vsc-extension.png": {
    "type": "image/png",
    "etag": "\"41723-116DlilRGtvlKYhRK0XS91CftrE\"",
    "mtime": "2025-12-29T15:10:46.061Z",
    "size": 268067,
    "path": "../public/_ipx/_/uni-typed/vsc-extension.png"
  },
  "/_ipx/_/uni-typed/webstorm-settings.png": {
    "type": "image/png",
    "etag": "\"6c158-g0ePp5DT9cPdkimH59KYEJZmouQ\"",
    "mtime": "2025-12-29T15:10:46.223Z",
    "size": 442712,
    "path": "../public/_ipx/_/uni-typed/webstorm-settings.png"
  },
  "/_nuxt/builds/meta/a11bb25b-a8a3-4885-b5ea-304859ef914c.json": {
    "type": "application/json",
    "etag": "\"1b9b-BZcXR4U0f2VqGqXmXl1qWZ/1u6Q\"",
    "mtime": "2025-12-29T15:11:07.434Z",
    "size": 7067,
    "path": "../public/_nuxt/builds/meta/a11bb25b-a8a3-4885-b5ea-304859ef914c.json"
  },
  "/api/_content/navigation/PLludsURzkInc8sroSFHgpxrIA3RTwelqBRA39GwSK4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"91c6-SUxkGD0i+VaVXMMGQV0VUtIqhzw\"",
    "mtime": "2025-12-29T15:10:27.824Z",
    "size": 37318,
    "path": "../public/api/_content/navigation/PLludsURzkInc8sroSFHgpxrIA3RTwelqBRA39GwSK4.1767020924919.json"
  },
  "/uni-network/advanced/cancellation/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1aef-OsNFfrgUha1cSiK78Jd9AyKkwnA\"",
    "mtime": "2025-12-29T15:10:36.402Z",
    "size": 6895,
    "path": "../public/uni-network/advanced/cancellation/_payload.json"
  },
  "/uni-network/advanced/cancellation/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2c7e5-zcA8/sM1W2z6rXaWZfj2ce+IIfg\"",
    "mtime": "2025-12-29T15:10:13.154Z",
    "size": 182245,
    "path": "../public/uni-network/advanced/cancellation/index.html"
  },
  "/uni-network/advanced/composition-api/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"106f-vVP/albzqGy9V3uL2zwSSkie1Z4\"",
    "mtime": "2025-12-29T15:10:36.645Z",
    "size": 4207,
    "path": "../public/uni-network/advanced/composition-api/_payload.json"
  },
  "/uni-network/advanced/composition-api/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1ec2a-k2FxRIBJ+bgNd9Zl4zzddjTx40s\"",
    "mtime": "2025-12-29T15:10:13.237Z",
    "size": 125994,
    "path": "../public/uni-network/advanced/composition-api/index.html"
  },
  "/uni-network/advanced/enhancements/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-eCEH1mlhmqOcPRVvrgXyFmqN5Yg\"",
    "mtime": "2025-12-29T15:10:36.393Z",
    "size": 486,
    "path": "../public/uni-network/advanced/enhancements/_payload.json"
  },
  "/uni-network/advanced/enhancements/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1e46a-c/UCoEya9a7Ok1N38imSeU5eavQ\"",
    "mtime": "2025-12-29T15:10:13.154Z",
    "size": 124010,
    "path": "../public/uni-network/advanced/enhancements/index.html"
  },
  "/api/_content/query/-AFQML4stQxDGpGARG5I0rdvqnbsv16ndiDboGoWv34.1767020924919.json": {
    "type": "application/json",
    "etag": "\"331-1c1cLUVdpdnkHjOmPXjTV8tEKRI\"",
    "mtime": "2025-12-29T15:10:56.729Z",
    "size": 817,
    "path": "../public/api/_content/query/-AFQML4stQxDGpGARG5I0rdvqnbsv16ndiDboGoWv34.1767020924919.json"
  },
  "/api/_content/query/-JkI69F2_fCFMAgDiqYVYuh5I0pVWi49eCWQZuaM3ME.1767020924919.json": {
    "type": "application/json",
    "etag": "\"7201-g8Z1Va1PMsXOfjcVazAsoiNdgng\"",
    "mtime": "2025-12-29T15:10:59.767Z",
    "size": 29185,
    "path": "../public/api/_content/query/-JkI69F2_fCFMAgDiqYVYuh5I0pVWi49eCWQZuaM3ME.1767020924919.json"
  },
  "/api/_content/query/-YpKhDkWnLfayzt9OKE87smj9pw_2EwN3xmg303OcwM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"192-JLCQS1IWiK3pNIdHbOXTReUZlDs\"",
    "mtime": "2025-12-29T15:11:05.895Z",
    "size": 402,
    "path": "../public/api/_content/query/-YpKhDkWnLfayzt9OKE87smj9pw_2EwN3xmg303OcwM.1767020924919.json"
  },
  "/api/_content/query/-cFA7b1AhVBx9j_ZBvyGJrDfTzhp0FXwLuepRsyxBU4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"254-Y7QH7leA35Q0Ccbu83szb0buARo\"",
    "mtime": "2025-12-29T15:10:27.187Z",
    "size": 596,
    "path": "../public/api/_content/query/-cFA7b1AhVBx9j_ZBvyGJrDfTzhp0FXwLuepRsyxBU4.1767020924919.json"
  },
  "/api/_content/query/02nn8tmlWNAF_XbvnihprezmfGv4q7kneXtsNwo8I6M.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1d05-n3lMJYbwX9XkrB8LyYXwaQxcgyM\"",
    "mtime": "2025-12-29T15:10:56.729Z",
    "size": 7429,
    "path": "../public/api/_content/query/02nn8tmlWNAF_XbvnihprezmfGv4q7kneXtsNwo8I6M.1767020924919.json"
  },
  "/api/_content/query/0NDEnU7Q2U8AejtTkJO6L3AW4rHTqSDyvA1mwmZyzJc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2df-PSv26Fbz6V2WS1NW/emW2/bMxiU\"",
    "mtime": "2025-12-29T15:10:51.573Z",
    "size": 735,
    "path": "../public/api/_content/query/0NDEnU7Q2U8AejtTkJO6L3AW4rHTqSDyvA1mwmZyzJc.1767020924919.json"
  },
  "/api/_content/query/0RjpavXyOnnaDQ1Aq17PS_lkzOVHgHUcGmsfsnCihR8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"c4e8-VBdE7zhv0Wmeo4Ta3aD/VCEitGQ\"",
    "mtime": "2025-12-29T15:10:43.730Z",
    "size": 50408,
    "path": "../public/api/_content/query/0RjpavXyOnnaDQ1Aq17PS_lkzOVHgHUcGmsfsnCihR8.1767020924919.json"
  },
  "/api/_content/query/0mUE6j3EH2bJqXFX503Gk-mCf-xHojygeGTdIdLMSxw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2cbd-vipc7SN2fyRzRkfPaHSaPuYv0BU\"",
    "mtime": "2025-12-29T15:10:37.929Z",
    "size": 11453,
    "path": "../public/api/_content/query/0mUE6j3EH2bJqXFX503Gk-mCf-xHojygeGTdIdLMSxw.1767020924919.json"
  },
  "/api/_content/query/0z-18-xO2f9oleEr2pQAoVpCLuEwvaLqxP0UDDJSyvs.1767020924919.json": {
    "type": "application/json",
    "etag": "\"50d-J2xdrsh6qQl5Q+v8xscJW1K6Zac\"",
    "mtime": "2025-12-29T15:10:32.294Z",
    "size": 1293,
    "path": "../public/api/_content/query/0z-18-xO2f9oleEr2pQAoVpCLuEwvaLqxP0UDDJSyvs.1767020924919.json"
  },
  "/api/_content/query/0zNusDOjo8YZ7dzduMRnygqS-2FpMUQomlABnb6yRwI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2b8-EyEDgMpTue+tStJN6WJ7wD62W04\"",
    "mtime": "2025-12-29T15:10:52.019Z",
    "size": 696,
    "path": "../public/api/_content/query/0zNusDOjo8YZ7dzduMRnygqS-2FpMUQomlABnb6yRwI.1767020924919.json"
  },
  "/api/_content/query/13YdwhhZucF1gxkvJbvaBL6KB4kjbxzRI-iyDwYICOg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"51a-Ko81Ya7GhHw5KxIEZWgSHHWVdLI\"",
    "mtime": "2025-12-29T15:11:01.064Z",
    "size": 1306,
    "path": "../public/api/_content/query/13YdwhhZucF1gxkvJbvaBL6KB4kjbxzRI-iyDwYICOg.1767020924919.json"
  },
  "/api/_content/query/1854jfHZqMPx37A3rx_dTIrmjL1DJbaR6oZ38RApXds.1767020924919.json": {
    "type": "application/json",
    "etag": "\"69-Lttp9y3x5OHUpfKGSRSSYax1PoA\"",
    "mtime": "2025-12-29T15:10:38.375Z",
    "size": 105,
    "path": "../public/api/_content/query/1854jfHZqMPx37A3rx_dTIrmjL1DJbaR6oZ38RApXds.1767020924919.json"
  },
  "/api/_content/query/19t0PvcycEwNuxAhe1DjEBehyP5k6YigsKzLM_d2Iwg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"304-eJap3FOjp7rWIB/W7cKN2wvM6dw\"",
    "mtime": "2025-12-29T15:10:50.274Z",
    "size": 772,
    "path": "../public/api/_content/query/19t0PvcycEwNuxAhe1DjEBehyP5k6YigsKzLM_d2Iwg.1767020924919.json"
  },
  "/api/_content/query/1EY2T6RFiE1_GVA5IVhoNzK2dAx6alb9wJRsygyVTTw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"19b6-WhN7YLbKQXTgzCtM6rxS5wtyojU\"",
    "mtime": "2025-12-29T15:10:49.139Z",
    "size": 6582,
    "path": "../public/api/_content/query/1EY2T6RFiE1_GVA5IVhoNzK2dAx6alb9wJRsygyVTTw.1767020924919.json"
  },
  "/api/_content/query/1vKczJVEjXrMdRIH5aFL7rJw4pkNvT7DWYnxo_poxH4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2220-ma8yKH4cyKJX97iIvhhmhvNo3tI\"",
    "mtime": "2025-12-29T15:10:55.321Z",
    "size": 8736,
    "path": "../public/api/_content/query/1vKczJVEjXrMdRIH5aFL7rJw4pkNvT7DWYnxo_poxH4.1767020924919.json"
  },
  "/api/_content/query/21D-kOvquV8ujo5wbWy7bfS2KI6GaE5_zUd-SriwLbg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"457-QrYcYvLgfBZZJ8/7S5Omk1fm4a8\"",
    "mtime": "2025-12-29T15:11:01.479Z",
    "size": 1111,
    "path": "../public/api/_content/query/21D-kOvquV8ujo5wbWy7bfS2KI6GaE5_zUd-SriwLbg.1767020924919.json"
  },
  "/api/_content/query/2C_6-457j-6KDzs7A4fQBTUbrcZyeBd8No6IEu-n6Yg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"229c-bplPShTmr5UisKPqghbg7UJdIO0\"",
    "mtime": "2025-12-29T15:11:05.850Z",
    "size": 8860,
    "path": "../public/api/_content/query/2C_6-457j-6KDzs7A4fQBTUbrcZyeBd8No6IEu-n6Yg.1767020924919.json"
  },
  "/api/_content/query/2HnLJoh3Wpg_REiJIwvLPfUqwJj9WqL3YsW9DzZY-i4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"f997-nMQytZQr+zP+bLPTfwpmyP12n/4\"",
    "mtime": "2025-12-29T15:11:01.064Z",
    "size": 63895,
    "path": "../public/api/_content/query/2HnLJoh3Wpg_REiJIwvLPfUqwJj9WqL3YsW9DzZY-i4.1767020924919.json"
  },
  "/api/_content/query/2LIph3-DMBZ6Nh8xWevKMiBn2HswD-ndCthFkQ-3sN4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"548a-scw/k4Yflu2mcgjlPgbZyRjpVXE\"",
    "mtime": "2025-12-29T15:10:41.247Z",
    "size": 21642,
    "path": "../public/api/_content/query/2LIph3-DMBZ6Nh8xWevKMiBn2HswD-ndCthFkQ-3sN4.1767020924919.json"
  },
  "/api/_content/query/2X4tQBEmVZMST8wELgXjycdFQykJmPTVaCQqU2Pjk7w.1767020924919.json": {
    "type": "application/json",
    "etag": "\"34e-05hROywliJGDy5XqiieVbiEVtuw\"",
    "mtime": "2025-12-29T15:10:48.336Z",
    "size": 846,
    "path": "../public/api/_content/query/2X4tQBEmVZMST8wELgXjycdFQykJmPTVaCQqU2Pjk7w.1767020924919.json"
  },
  "/api/_content/query/2_Uc01HK3DS138MSmgcgK2_ECVIUDZ2nFWtdtfcacwY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"6e-lMQYDAhO+9E1S2M50X38R7AwSpg\"",
    "mtime": "2025-12-29T15:10:57.411Z",
    "size": 110,
    "path": "../public/api/_content/query/2_Uc01HK3DS138MSmgcgK2_ECVIUDZ2nFWtdtfcacwY.1767020924919.json"
  },
  "/api/_content/query/2fezqwJMvVMxqPAV-ZSi0TXiGkPDzbsBI8AGxR37qVQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4ee-yVH1LaoxR+rayLi2ZB8vsP9myTM\"",
    "mtime": "2025-12-29T15:10:44.577Z",
    "size": 1262,
    "path": "../public/api/_content/query/2fezqwJMvVMxqPAV-ZSi0TXiGkPDzbsBI8AGxR37qVQ.1767020924919.json"
  },
  "/api/_content/query/2k2Gcg_am-3XK5UYkaZud-10JOndExzjk72GWyjm9Es.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4a3-KYxIJ1DzJTGTwTLcaeKIT3YKzEI\"",
    "mtime": "2025-12-29T15:11:00.767Z",
    "size": 1187,
    "path": "../public/api/_content/query/2k2Gcg_am-3XK5UYkaZud-10JOndExzjk72GWyjm9Es.1767020924919.json"
  },
  "/api/_content/query/3BzxAV3-ATzJtubdL_r94nkXw84aKyBusr5JyFE5Ykw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1d00-qH0U3eo4JUTbIp1Xv0sdZA7Wqgo\"",
    "mtime": "2025-12-29T15:10:30.079Z",
    "size": 7424,
    "path": "../public/api/_content/query/3BzxAV3-ATzJtubdL_r94nkXw84aKyBusr5JyFE5Ykw.1767020924919.json"
  },
  "/api/_content/query/3CqaoQA-uS7XUAFSIMPqlDzgCN2LgdCxhyLRYvm5blI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"34b-56iQoz5R6FMpbOP2PnXg+D5oXuE\"",
    "mtime": "2025-12-29T15:10:49.375Z",
    "size": 843,
    "path": "../public/api/_content/query/3CqaoQA-uS7XUAFSIMPqlDzgCN2LgdCxhyLRYvm5blI.1767020924919.json"
  },
  "/api/_content/query/3F5gRDBQqOb1r9UK8xilZtjJUjhF7ZebWV9RbiaqmFM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"51c-q5THDELmYYbc8Vpdj3sHhUNvcho\"",
    "mtime": "2025-12-29T15:10:42.007Z",
    "size": 1308,
    "path": "../public/api/_content/query/3F5gRDBQqOb1r9UK8xilZtjJUjhF7ZebWV9RbiaqmFM.1767020924919.json"
  },
  "/api/_content/query/3LSXevYiPrSH4Odmy1Oy8MgDLfJAIYLsiF9aUB520Qc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"36ac-hQLNYhUldklgdrgcNui4GRsw6wk\"",
    "mtime": "2025-12-29T15:10:34.465Z",
    "size": 13996,
    "path": "../public/api/_content/query/3LSXevYiPrSH4Odmy1Oy8MgDLfJAIYLsiF9aUB520Qc.1767020924919.json"
  },
  "/api/_content/query/3MijJg_zZa56rJqZCpCSpkwcuQh25J0XVPoMvGLIe2M.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3e9a-h1fUhy4cSv4BEoiPiVKfO+XFz/A\"",
    "mtime": "2025-12-29T15:10:32.667Z",
    "size": 16026,
    "path": "../public/api/_content/query/3MijJg_zZa56rJqZCpCSpkwcuQh25J0XVPoMvGLIe2M.1767020924919.json"
  },
  "/api/_content/query/3UcxcUE4qyQcOPGQyJUUsA6DLSzcUyGfOOVVuk-5qdw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1174-+TvOsqNvEPml124HqmQXGBYfjgw\"",
    "mtime": "2025-12-29T15:10:47.583Z",
    "size": 4468,
    "path": "../public/api/_content/query/3UcxcUE4qyQcOPGQyJUUsA6DLSzcUyGfOOVVuk-5qdw.1767020924919.json"
  },
  "/api/_content/query/3XbZVYBijJAYSlhrM-kY5biyr6LjW7CVhVReW_Oh7cI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"457-pUGzf9a6QW/7B7mIxlEe2dpew0E\"",
    "mtime": "2025-12-29T15:10:35.526Z",
    "size": 1111,
    "path": "../public/api/_content/query/3XbZVYBijJAYSlhrM-kY5biyr6LjW7CVhVReW_Oh7cI.1767020924919.json"
  },
  "/api/_content/query/4-5jWuNL-6GG7YRJNZ_cP1fHA8_QIAmKt-RhiU-QQ34.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:41.984Z",
    "size": 11,
    "path": "../public/api/_content/query/4-5jWuNL-6GG7YRJNZ_cP1fHA8_QIAmKt-RhiU-QQ34.1767020924919.json"
  },
  "/api/_content/query/43IwnTyBCaNqrJry1RnV_1ULAAsSnPXSWraWlhj3O98.1767020924919.json": {
    "type": "application/json",
    "etag": "\"45fa-6HfsYJ0Pls301C5tuBNtQc9nIlM\"",
    "mtime": "2025-12-29T15:10:46.280Z",
    "size": 17914,
    "path": "../public/api/_content/query/43IwnTyBCaNqrJry1RnV_1ULAAsSnPXSWraWlhj3O98.1767020924919.json"
  },
  "/api/_content/query/4bFVgCnUZ982jPCv1FjmCYj88y5Dw6SJa34t4Ki6IoQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"412-TUEcxeqRwDvP66dp2i4Xo+cX75s\"",
    "mtime": "2025-12-29T15:10:33.943Z",
    "size": 1042,
    "path": "../public/api/_content/query/4bFVgCnUZ982jPCv1FjmCYj88y5Dw6SJa34t4Ki6IoQ.1767020924919.json"
  },
  "/api/_content/query/4ormFR_51XM4XOu3vS9Mso3Ojm4W9_iVke8OkE7-zU8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"699e-5ofyWFZkap5DhG1QgFYP7fKbNww\"",
    "mtime": "2025-12-29T15:10:27.266Z",
    "size": 27038,
    "path": "../public/api/_content/query/4ormFR_51XM4XOu3vS9Mso3Ojm4W9_iVke8OkE7-zU8.1767020924919.json"
  },
  "/api/_content/query/4rnvOlqZ1oghOd4NvsJvjF4st82gxcIbCiSfKeU-ZK4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"316e-uRwGAmi9m4FtbYToLXZcWGwFvSM\"",
    "mtime": "2025-12-29T15:10:50.027Z",
    "size": 12654,
    "path": "../public/api/_content/query/4rnvOlqZ1oghOd4NvsJvjF4st82gxcIbCiSfKeU-ZK4.1767020924919.json"
  },
  "/api/_content/query/54-4jOff64Sq8dvBvk3CVJ1DD1oEMphbblrBbI3xmEA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"34d-pjnOVkq8/Zs+s19e3bQ0alarZeQ\"",
    "mtime": "2025-12-29T15:10:37.980Z",
    "size": 845,
    "path": "../public/api/_content/query/54-4jOff64Sq8dvBvk3CVJ1DD1oEMphbblrBbI3xmEA.1767020924919.json"
  },
  "/api/_content/query/5SyRFYLVkvKcNpupWuxPdWQlVJEsFM6lYnvbU104Waw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3ac-/tja8Z+TY/MexzDMyvOnpEpEB48\"",
    "mtime": "2025-12-29T15:10:38.559Z",
    "size": 940,
    "path": "../public/api/_content/query/5SyRFYLVkvKcNpupWuxPdWQlVJEsFM6lYnvbU104Waw.1767020924919.json"
  },
  "/api/_content/query/5Vla7jp2jirUgZafOA44FcKb9q-2UkYvjV5a3KSKgAU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"8f27-jSO9WznLJXGncwdBu22Xm9mJbIw\"",
    "mtime": "2025-12-29T15:10:28.307Z",
    "size": 36647,
    "path": "../public/api/_content/query/5Vla7jp2jirUgZafOA44FcKb9q-2UkYvjV5a3KSKgAU.1767020924919.json"
  },
  "/api/_content/query/5oC8-esW6Z0h0Zb6KrN8BMFmZsMTJ4vnJ6cNQmUieR8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"ea1-k97XGSyqjb0IHyzVLHiNt4OnaR8\"",
    "mtime": "2025-12-29T15:10:51.806Z",
    "size": 3745,
    "path": "../public/api/_content/query/5oC8-esW6Z0h0Zb6KrN8BMFmZsMTJ4vnJ6cNQmUieR8.1767020924919.json"
  },
  "/api/_content/query/5oLZSwCuFy8SXPNcCvgtIEPgmghPjxOk1JCfZTJaBTA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:40.481Z",
    "size": 11,
    "path": "../public/api/_content/query/5oLZSwCuFy8SXPNcCvgtIEPgmghPjxOk1JCfZTJaBTA.1767020924919.json"
  },
  "/api/_content/query/5tAFn9guMftSq5XCxo9-ZuXDWdc-gTvo__lNsjq0Tlw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3367-K94desMzeA4ocs07wLOCl8VQdis\"",
    "mtime": "2025-12-29T15:11:02.618Z",
    "size": 13159,
    "path": "../public/api/_content/query/5tAFn9guMftSq5XCxo9-ZuXDWdc-gTvo__lNsjq0Tlw.1767020924919.json"
  },
  "/api/_content/query/6AtxnL47jssWwzl8bjgS84bP6AMPGvklFob7otbwNaM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3e48-qgNJRyziYhxC4LQ5p6fNb8ZF8wE\"",
    "mtime": "2025-12-29T15:10:49.796Z",
    "size": 15944,
    "path": "../public/api/_content/query/6AtxnL47jssWwzl8bjgS84bP6AMPGvklFob7otbwNaM.1767020924919.json"
  },
  "/api/_content/query/6MAPRlQLQDlwPuhLY4QWqm2ZB6asVtbSZSZ6cdj16NY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2c3-Twubxznx72o0OKarArveTIHlIVs\"",
    "mtime": "2025-12-29T15:10:47.583Z",
    "size": 707,
    "path": "../public/api/_content/query/6MAPRlQLQDlwPuhLY4QWqm2ZB6asVtbSZSZ6cdj16NY.1767020924919.json"
  },
  "/api/_content/query/6SgoCsHClgA_qznf16Xg1BSLjKCwES58fJFErG7B92U.1767020924919.json": {
    "type": "application/json",
    "etag": "\"499-tYXcUmnDNIUJ68iWT/sZ1O4GTZE\"",
    "mtime": "2025-12-29T15:10:46.061Z",
    "size": 1177,
    "path": "../public/api/_content/query/6SgoCsHClgA_qznf16Xg1BSLjKCwES58fJFErG7B92U.1767020924919.json"
  },
  "/api/_content/query/6T0wYCRIpMdbEueXWbr3qB9AMM99PuedGmYgGtRdMbI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3a09-JhNtD2Xupa58+rzj2IgmN4eueLw\"",
    "mtime": "2025-12-29T15:10:34.842Z",
    "size": 14857,
    "path": "../public/api/_content/query/6T0wYCRIpMdbEueXWbr3qB9AMM99PuedGmYgGtRdMbI.1767020924919.json"
  },
  "/api/_content/query/6XA6HpGpVxQlZwLjguBL4MAsWRdBRE53B8D-h9RB5wY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1fae-RfcSv63Zm9D+fwWKQNkJU1LbC9Q\"",
    "mtime": "2025-12-29T15:10:39.419Z",
    "size": 8110,
    "path": "../public/api/_content/query/6XA6HpGpVxQlZwLjguBL4MAsWRdBRE53B8D-h9RB5wY.1767020924919.json"
  },
  "/api/_content/query/6kwhXvbJnkWzOgyKOYWsqXeQh2K9JgMYfiyf3ucBvtM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"414-aClXAtozikNuijryseazc9vS608\"",
    "mtime": "2025-12-29T15:10:58.923Z",
    "size": 1044,
    "path": "../public/api/_content/query/6kwhXvbJnkWzOgyKOYWsqXeQh2K9JgMYfiyf3ucBvtM.1767020924919.json"
  },
  "/api/_content/query/6qJVK6rGvuJcXCw8pGnQ5o4lIzcca9rNSkUWIvm-cAE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"5a3-gwcys+I8xB10bePsP+8Dxk0W5uI\"",
    "mtime": "2025-12-29T15:10:49.375Z",
    "size": 1443,
    "path": "../public/api/_content/query/6qJVK6rGvuJcXCw8pGnQ5o4lIzcca9rNSkUWIvm-cAE.1767020924919.json"
  },
  "/api/_content/query/6tNVih9OVBxCnaWyF3X-VtO3zC3fmqk-R-vA1OmCIrA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"5d7-xa8e3WCW/EdU6RdSUh8Jqz1X1Ds\"",
    "mtime": "2025-12-29T15:10:30.681Z",
    "size": 1495,
    "path": "../public/api/_content/query/6tNVih9OVBxCnaWyF3X-VtO3zC3fmqk-R-vA1OmCIrA.1767020924919.json"
  },
  "/api/_content/query/7-uu3jOQA2O_h2hgOEg7MI9fEyUBaVgufobfUd5kqLk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1181-vf6UR1mh+56w4S5152uh7qaQQ9c\"",
    "mtime": "2025-12-29T15:10:47.630Z",
    "size": 4481,
    "path": "../public/api/_content/query/7-uu3jOQA2O_h2hgOEg7MI9fEyUBaVgufobfUd5kqLk.1767020924919.json"
  },
  "/api/_content/query/786VMpgX-W4MbQyvsc5DUXQ3yHF-hYlXl_-fsHsqOkA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4a08-VPKJeShN+cpCQ3ZRKrVJP/Avb04\"",
    "mtime": "2025-12-29T15:10:59.518Z",
    "size": 18952,
    "path": "../public/api/_content/query/786VMpgX-W4MbQyvsc5DUXQ3yHF-hYlXl_-fsHsqOkA.1767020924919.json"
  },
  "/api/_content/query/7BpNo7bhCquXKl_aO3cfHWfRA26ItDwWV36grNUnJ4U.1767020924919.json": {
    "type": "application/json",
    "etag": "\"795f-F6rMSvhrU7fpKf3aByuFn/ohklU\"",
    "mtime": "2025-12-29T15:10:37.465Z",
    "size": 31071,
    "path": "../public/api/_content/query/7BpNo7bhCquXKl_aO3cfHWfRA26ItDwWV36grNUnJ4U.1767020924919.json"
  },
  "/api/_content/query/7SQ1dybcKtzKgZAa-eMmhKvm_v4CTTEgncHV-tW4His.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4c5-qEQzFTUtnUvUGDHEZc6hXXu4xk0\"",
    "mtime": "2025-12-29T15:10:44.194Z",
    "size": 1221,
    "path": "../public/api/_content/query/7SQ1dybcKtzKgZAa-eMmhKvm_v4CTTEgncHV-tW4His.1767020924919.json"
  },
  "/api/_content/query/7Van5ThrOm4tAb_KC8IdDlfYQN8kyonmX1-XfWbzZhQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3bb5-pVIxuOdXctXtC++ala98X4fK5XQ\"",
    "mtime": "2025-12-29T15:10:58.016Z",
    "size": 15285,
    "path": "../public/api/_content/query/7Van5ThrOm4tAb_KC8IdDlfYQN8kyonmX1-XfWbzZhQ.1767020924919.json"
  },
  "/api/_content/query/8Xz9_vMgsh9Q9ileSaxV4R7EB3lTWKw1QAwvDGH3pQo.1767020924919.json": {
    "type": "application/json",
    "etag": "\"6284-scJ08vyd/9adopw4CYN9bieIa1Y\"",
    "mtime": "2025-12-29T15:10:58.973Z",
    "size": 25220,
    "path": "../public/api/_content/query/8Xz9_vMgsh9Q9ileSaxV4R7EB3lTWKw1QAwvDGH3pQo.1767020924919.json"
  },
  "/api/_content/query/8zPaQY8ZOwhxhTVBANgDs0ogQvqG3PMvuQkV5Whf-o4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4e2-PBLymeAllWi06j38ijBLLfBncDw\"",
    "mtime": "2025-12-29T15:10:27.219Z",
    "size": 1250,
    "path": "../public/api/_content/query/8zPaQY8ZOwhxhTVBANgDs0ogQvqG3PMvuQkV5Whf-o4.1767020924919.json"
  },
  "/api/_content/query/946sKdxnUyv1e6Y1iUV0r92oUiKQRRYo_IWb7CCM44o.1767020924919.json": {
    "type": "application/json",
    "etag": "\"a66-terrHeLvFq3WXgepynujbhR+41Q\"",
    "mtime": "2025-12-29T15:11:05.002Z",
    "size": 2662,
    "path": "../public/api/_content/query/946sKdxnUyv1e6Y1iUV0r92oUiKQRRYo_IWb7CCM44o.1767020924919.json"
  },
  "/api/_content/query/95SKTqiGzGiEovUzF6lwUPRQZrZbHo0K3qtxODJjb1A.1767020924919.json": {
    "type": "application/json",
    "etag": "\"317-g+fs59/WT4ztfJFC11WxmOaA5LU\"",
    "mtime": "2025-12-29T15:10:43.476Z",
    "size": 791,
    "path": "../public/api/_content/query/95SKTqiGzGiEovUzF6lwUPRQZrZbHo0K3qtxODJjb1A.1767020924919.json"
  },
  "/api/_content/query/96qxBVCOHJqvknZvj_UGq5JdGvDxc20YjbRtB8-cOwE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"466-YpssqVMicUXIF4ElCPWgLYQzyxY\"",
    "mtime": "2025-12-29T15:10:33.972Z",
    "size": 1126,
    "path": "../public/api/_content/query/96qxBVCOHJqvknZvj_UGq5JdGvDxc20YjbRtB8-cOwE.1767020924919.json"
  },
  "/api/_content/query/9M7x11Ye5yvbhD6E0dSptOgxxT0r_A-FrLEl0J0YqAw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"38a-5lpJ7caFt81XE+BCEPD+pF6T4nk\"",
    "mtime": "2025-12-29T15:10:37.507Z",
    "size": 906,
    "path": "../public/api/_content/query/9M7x11Ye5yvbhD6E0dSptOgxxT0r_A-FrLEl0J0YqAw.1767020924919.json"
  },
  "/api/_content/query/9Pg8Z8V2iuhlqQpJHb1IqfurJddmIPQCiu7LnX79Rl0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:30.964Z",
    "size": 11,
    "path": "../public/api/_content/query/9Pg8Z8V2iuhlqQpJHb1IqfurJddmIPQCiu7LnX79Rl0.1767020924919.json"
  },
  "/api/_content/query/9vVEtNsZR6GN6gOQ-IsbxQyZLuJmJHYa7pf1FVJUsT0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"120f-Uv9pSglcrHgphUJR5izUxqKqFa4\"",
    "mtime": "2025-12-29T15:10:47.698Z",
    "size": 4623,
    "path": "../public/api/_content/query/9vVEtNsZR6GN6gOQ-IsbxQyZLuJmJHYa7pf1FVJUsT0.1767020924919.json"
  },
  "/api/_content/query/9w_1CVNa_DjW66MPgFCv8HgGBlpxZ7UvcGww1gICrHE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"f1a2-BisCuLKvGURjK83LDtBr0Bs2wIA\"",
    "mtime": "2025-12-29T15:11:02.557Z",
    "size": 61858,
    "path": "../public/api/_content/query/9w_1CVNa_DjW66MPgFCv8HgGBlpxZ7UvcGww1gICrHE.1767020924919.json"
  },
  "/api/_content/query/B7bi14Et3SOrwJIGILtX4q6CfIXndES0WbMN3bSyEHA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2cf-qzQxNjYc4xFtaYjEkIU+3wVckz0\"",
    "mtime": "2025-12-29T15:10:53.095Z",
    "size": 719,
    "path": "../public/api/_content/query/B7bi14Et3SOrwJIGILtX4q6CfIXndES0WbMN3bSyEHA.1767020924919.json"
  },
  "/api/_content/query/BG6go_dRu635vHi2shuhH7Bfu75o7Izkra4SINln_G4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4ae-hj+9121B/uvl5pYTzhUB3WS+Gg4\"",
    "mtime": "2025-12-29T15:10:43.476Z",
    "size": 1198,
    "path": "../public/api/_content/query/BG6go_dRu635vHi2shuhH7Bfu75o7Izkra4SINln_G4.1767020924919.json"
  },
  "/api/_content/query/Besd38zBRjj7_18yJ58F7xj955zzmRYYC-UmhzpeLOY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4d0-hEb4A9lK/0xWKB6404OUK4aueKs\"",
    "mtime": "2025-12-29T15:11:00.556Z",
    "size": 1232,
    "path": "../public/api/_content/query/Besd38zBRjj7_18yJ58F7xj955zzmRYYC-UmhzpeLOY.1767020924919.json"
  },
  "/api/_content/query/Bgk3t1x22ufZodXiipKZZkBVGmYOJ2nKYyehFc_bVw4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"544-p/zJLeTyXdIjh9b1bvuqseG0dGY\"",
    "mtime": "2025-12-29T15:10:59.310Z",
    "size": 1348,
    "path": "../public/api/_content/query/Bgk3t1x22ufZodXiipKZZkBVGmYOJ2nKYyehFc_bVw4.1767020924919.json"
  },
  "/api/_content/query/CKPAvjpVVg95caOfAPQUohFVLkfcfBFEVCT_BiCxPYE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"82dc-72n+eXyUnjNzg+lhiz/pBQMQHlk\"",
    "mtime": "2025-12-29T15:10:36.422Z",
    "size": 33500,
    "path": "../public/api/_content/query/CKPAvjpVVg95caOfAPQUohFVLkfcfBFEVCT_BiCxPYE.1767020924919.json"
  },
  "/api/_content/query/COHGJhpS0uMzF6yYT5zyQlnMQgPQ5G1oM_3j1vdzdDc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"5342-XjrvipumEQYUqENOqnWD0BTunVs\"",
    "mtime": "2025-12-29T15:10:34.236Z",
    "size": 21314,
    "path": "../public/api/_content/query/COHGJhpS0uMzF6yYT5zyQlnMQgPQ5G1oM_3j1vdzdDc.1767020924919.json"
  },
  "/api/_content/query/CQeGjqkAQuldDtsuLDE0ZsqnvIKWe8nS62IFgroUTX4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4b8-8TWcj2dKL+LBIeiSES7fbCLILRw\"",
    "mtime": "2025-12-29T15:10:30.961Z",
    "size": 1208,
    "path": "../public/api/_content/query/CQeGjqkAQuldDtsuLDE0ZsqnvIKWe8nS62IFgroUTX4.1767020924919.json"
  },
  "/api/_content/query/Ci2fRZzwIGCA5yJFfANpcK0W7gURX2dBx7Nn_9dEzm8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"195f-AOxL6v+7K77D2croxuZ/sp9fUuQ\"",
    "mtime": "2025-12-29T15:10:53.558Z",
    "size": 6495,
    "path": "../public/api/_content/query/Ci2fRZzwIGCA5yJFfANpcK0W7gURX2dBx7Nn_9dEzm8.1767020924919.json"
  },
  "/api/_content/query/D03WCcU7X8C_Nk1s5kJ4rCNJKDaxSNmlY3Qu2hzjukc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4fb-Y2rK7dzNkFRwHxUaWnR4cbP4Yc4\"",
    "mtime": "2025-12-29T15:10:44.200Z",
    "size": 1275,
    "path": "../public/api/_content/query/D03WCcU7X8C_Nk1s5kJ4rCNJKDaxSNmlY3Qu2hzjukc.1767020924919.json"
  },
  "/api/_content/query/D7AARh7yqNkeQYG4BePmnxb09tRDKDKNWbLYc0gr4mM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3ca-qwBtnITnvEpaxitALSrflWADUr0\"",
    "mtime": "2025-12-29T15:10:36.422Z",
    "size": 970,
    "path": "../public/api/_content/query/D7AARh7yqNkeQYG4BePmnxb09tRDKDKNWbLYc0gr4mM.1767020924919.json"
  },
  "/api/_content/query/DLrDcsjO1uaWzuvyzD2SD1KynC8ViRHbSjRLfWDHEmU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"f83-HHqzjRIp/lNVhQRThgTh1sRPSgU\"",
    "mtime": "2025-12-29T15:11:00.539Z",
    "size": 3971,
    "path": "../public/api/_content/query/DLrDcsjO1uaWzuvyzD2SD1KynC8ViRHbSjRLfWDHEmU.1767020924919.json"
  },
  "/api/_content/query/DcmPAhYcV6SLMBmMlAHVZAlPbscOJrpPq0Ux7-p8iug.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2f3-IUez7eVBx2pBaf+O7wGORR5DdRw\"",
    "mtime": "2025-12-29T15:10:53.740Z",
    "size": 755,
    "path": "../public/api/_content/query/DcmPAhYcV6SLMBmMlAHVZAlPbscOJrpPq0Ux7-p8iug.1767020924919.json"
  },
  "/api/_content/query/De3Dgz3nHfq0zeZ_wrD-uKA1Vy2GqSG8JY3dvsK8nJ8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4b1-obozxCjB9E5bnW3uvC6ca4PO79w\"",
    "mtime": "2025-12-29T15:10:33.687Z",
    "size": 1201,
    "path": "../public/api/_content/query/De3Dgz3nHfq0zeZ_wrD-uKA1Vy2GqSG8JY3dvsK8nJ8.1767020924919.json"
  },
  "/api/_content/query/Do7QG-bIAVKcaclFDVoVWHJmhKsFok-jVUGwSLpNXFk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"499-LGIh4XNNTn6XAENWtws6woG/Z94\"",
    "mtime": "2025-12-29T15:10:34.872Z",
    "size": 1177,
    "path": "../public/api/_content/query/Do7QG-bIAVKcaclFDVoVWHJmhKsFok-jVUGwSLpNXFk.1767020924919.json"
  },
  "/api/_content/query/DrY652E9f5qrlLimn7nIEjqDFZPFjYwlGbfkw-YiVk8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"a76-zl2EW6XBgZQM6FXDfIT//LnYTGA\"",
    "mtime": "2025-12-29T15:11:04.971Z",
    "size": 2678,
    "path": "../public/api/_content/query/DrY652E9f5qrlLimn7nIEjqDFZPFjYwlGbfkw-YiVk8.1767020924919.json"
  },
  "/api/_content/query/DvSKI48-VKIFk_r3ti_LdB7QrLhkTJch6DOl0upPFa4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"bf4-ZJerRw9bEkV2M8Anz3GSRgd2iuI\"",
    "mtime": "2025-12-29T15:10:27.388Z",
    "size": 3060,
    "path": "../public/api/_content/query/DvSKI48-VKIFk_r3ti_LdB7QrLhkTJch6DOl0upPFa4.1767020924919.json"
  },
  "/api/_content/query/E6HY9CoP6bmvjTGNntHrASaIlGPoIRnHLiY2wTIxqUw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2b2-adBq7dsACEygQKbJileTdDEfIfE\"",
    "mtime": "2025-12-29T15:10:50.867Z",
    "size": 690,
    "path": "../public/api/_content/query/E6HY9CoP6bmvjTGNntHrASaIlGPoIRnHLiY2wTIxqUw.1767020924919.json"
  },
  "/api/_content/query/EG2AI7knoZlKtww6qFi2GxqXFmzzTSiaXN-TGZoT9-w.1767020924919.json": {
    "type": "application/json",
    "etag": "\"c5fe-f43a58PxJLaKECLGHFbxRB+2OVA\"",
    "mtime": "2025-12-29T15:10:36.865Z",
    "size": 50686,
    "path": "../public/api/_content/query/EG2AI7knoZlKtww6qFi2GxqXFmzzTSiaXN-TGZoT9-w.1767020924919.json"
  },
  "/api/_content/query/ENXhP03pijQMG8HnBr8uUFhwXPDWRAoseaUAYUnNh6M.1767020924919.json": {
    "type": "application/json",
    "etag": "\"580-HbOD6Wc+P9hVEfiL5TyVp8ar6/Q\"",
    "mtime": "2025-12-29T15:11:04.963Z",
    "size": 1408,
    "path": "../public/api/_content/query/ENXhP03pijQMG8HnBr8uUFhwXPDWRAoseaUAYUnNh6M.1767020924919.json"
  },
  "/api/_content/query/EZvqNXNIDzXf00gVkvX7jbR16n-m1nrOdN83CsGZai4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"16c9-IpBGWXir9PhXy6w2ktse3HKUsUM\"",
    "mtime": "2025-12-29T15:10:33.943Z",
    "size": 5833,
    "path": "../public/api/_content/query/EZvqNXNIDzXf00gVkvX7jbR16n-m1nrOdN83CsGZai4.1767020924919.json"
  },
  "/api/_content/query/FMnp3LRlwDQmXVga0p2_ktK1QGvT8OjiR14zPGdBa1o.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4f7-3X1R3N4do66aa8Y0fIsdkXqlfpU\"",
    "mtime": "2025-12-29T15:10:58.016Z",
    "size": 1271,
    "path": "../public/api/_content/query/FMnp3LRlwDQmXVga0p2_ktK1QGvT8OjiR14zPGdBa1o.1767020924919.json"
  },
  "/api/_content/query/FV0XSbrTk2hKl7BJKId9sjRcQGPQIEoDR9hZ0I8Ujuk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4a37-H5cmER3uEVcq4mW8y/S4Oi1/o98\"",
    "mtime": "2025-12-29T15:10:34.449Z",
    "size": 18999,
    "path": "../public/api/_content/query/FV0XSbrTk2hKl7BJKId9sjRcQGPQIEoDR9hZ0I8Ujuk.1767020924919.json"
  },
  "/api/_content/query/FaHKXfyFRZ4P7f81YrjEl89nb9DXmFTw9hlP0AmoGhY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"118e-TYjTLHvAoK8WCvYgGjYbujYkYIA\"",
    "mtime": "2025-12-29T15:10:48.102Z",
    "size": 4494,
    "path": "../public/api/_content/query/FaHKXfyFRZ4P7f81YrjEl89nb9DXmFTw9hlP0AmoGhY.1767020924919.json"
  },
  "/api/_content/query/FgO2QoeTho6mwuVFy6s8ZYIAC5_W-iI3Wr_uu3veILE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2e8-t9b8rjONaXGNR+inK3XxRgWLdUg\"",
    "mtime": "2025-12-29T15:10:54.824Z",
    "size": 744,
    "path": "../public/api/_content/query/FgO2QoeTho6mwuVFy6s8ZYIAC5_W-iI3Wr_uu3veILE.1767020924919.json"
  },
  "/api/_content/query/Fhd5I2WdWtreJayzrRHKrGRoaoWhUPp0FMk_-NQN1D0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2fb-T+ZqgjxR+deo8HYaROW92HU/0Ms\"",
    "mtime": "2025-12-29T15:10:55.917Z",
    "size": 763,
    "path": "../public/api/_content/query/Fhd5I2WdWtreJayzrRHKrGRoaoWhUPp0FMk_-NQN1D0.1767020924919.json"
  },
  "/api/_content/query/Fjlkt2Pz1LCFqDgzQpqWzXfauaA2ndcXfXrx7YY6cqg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"9c8-UwEg1/4YWOpdZxeBdNLhRsqHi8I\"",
    "mtime": "2025-12-29T15:10:30.316Z",
    "size": 2504,
    "path": "../public/api/_content/query/Fjlkt2Pz1LCFqDgzQpqWzXfauaA2ndcXfXrx7YY6cqg.1767020924919.json"
  },
  "/api/_content/query/FpV0Gtw6jNXF3mgBK39gSQfUXMI06UAxxhEB8m3DzNk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3737-W6JfgzNUDkT7BE2+EnzToBP/v3o\"",
    "mtime": "2025-12-29T15:10:38.559Z",
    "size": 14135,
    "path": "../public/api/_content/query/FpV0Gtw6jNXF3mgBK39gSQfUXMI06UAxxhEB8m3DzNk.1767020924919.json"
  },
  "/api/_content/query/G-JMWhHPyqaDjt-QFnFpcA9jZN89T0GGpj8S2fX478U.1767020924919.json": {
    "type": "application/json",
    "etag": "\"564-/K6UDvEA4CSETHg+yhL32rp8Vbc\"",
    "mtime": "2025-12-29T15:11:01.054Z",
    "size": 1380,
    "path": "../public/api/_content/query/G-JMWhHPyqaDjt-QFnFpcA9jZN89T0GGpj8S2fX478U.1767020924919.json"
  },
  "/api/_content/query/Ga2NVO2yzyAmU0Y-nMI0liL-62Q45K8EZeoQFx6y16Q.1767020924919.json": {
    "type": "application/json",
    "etag": "\"ba82-dDeId9HzKW/+3KHYA/36iQ1/Cn0\"",
    "mtime": "2025-12-29T15:10:37.500Z",
    "size": 47746,
    "path": "../public/api/_content/query/Ga2NVO2yzyAmU0Y-nMI0liL-62Q45K8EZeoQFx6y16Q.1767020924919.json"
  },
  "/api/_content/query/Gjv18cgny3pVXpKwi6fxNOb-SpimIyz1mPhmGonLMbQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"38b-Y63apavG4emHD8U73Payqv0HRGw\"",
    "mtime": "2025-12-29T15:10:47.394Z",
    "size": 907,
    "path": "../public/api/_content/query/Gjv18cgny3pVXpKwi6fxNOb-SpimIyz1mPhmGonLMbQ.1767020924919.json"
  },
  "/api/_content/query/Gq4xOe3vyGYfYdDyFAn4-MSzqHszEVlK-OEhUuvCUVM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"363-sC2wxcCc/OnKyoDotbl62+vm48o\"",
    "mtime": "2025-12-29T15:10:49.796Z",
    "size": 867,
    "path": "../public/api/_content/query/Gq4xOe3vyGYfYdDyFAn4-MSzqHszEVlK-OEhUuvCUVM.1767020924919.json"
  },
  "/api/_content/query/GqTVfMAPqI62LcfpvakXwIHH9wd3EkBpg0xLbq87ucs.1767020924919.json": {
    "type": "application/json",
    "etag": "\"6d0d-7UKuuDijhFCxsgNdtcru8CwTDQ4\"",
    "mtime": "2025-12-29T15:10:40.013Z",
    "size": 27917,
    "path": "../public/api/_content/query/GqTVfMAPqI62LcfpvakXwIHH9wd3EkBpg0xLbq87ucs.1767020924919.json"
  },
  "/api/_content/query/Gt9_oWxxiyGJi33cTtjpxvCH-xIg-vmgr4KRn3pCx6g.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2ec4-EtKVadXmPOoWD3stbjG4JNLDGTM\"",
    "mtime": "2025-12-29T15:10:37.929Z",
    "size": 11972,
    "path": "../public/api/_content/query/Gt9_oWxxiyGJi33cTtjpxvCH-xIg-vmgr4KRn3pCx6g.1767020924919.json"
  },
  "/api/_content/query/H6BC2OOXeb80jgGIsO2CZaafXvCDTke88Ctgp8FcEpw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1174-4ma9PEUcpf/j6oe6MQh91h7zHfg\"",
    "mtime": "2025-12-29T15:10:46.913Z",
    "size": 4468,
    "path": "../public/api/_content/query/H6BC2OOXeb80jgGIsO2CZaafXvCDTke88Ctgp8FcEpw.1767020924919.json"
  },
  "/api/_content/query/I8G5OFbS94I8WSCjojSwqTrP89LFUOEqY873p6kiddk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"364-Xig+yO5dKYYZ3OC450mm5n8ODUw\"",
    "mtime": "2025-12-29T15:10:36.645Z",
    "size": 868,
    "path": "../public/api/_content/query/I8G5OFbS94I8WSCjojSwqTrP89LFUOEqY873p6kiddk.1767020924919.json"
  },
  "/api/_content/query/Ip2scWlzdURMEW55AJn_MSoPBNAv_azCGu7w8HI_emY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"328-Gd5NQYRiDcVaCwZJx9jr6POiGYU\"",
    "mtime": "2025-12-29T15:10:42.628Z",
    "size": 808,
    "path": "../public/api/_content/query/Ip2scWlzdURMEW55AJn_MSoPBNAv_azCGu7w8HI_emY.1767020924919.json"
  },
  "/api/_content/query/JBjQNF72MXEFrVM9feUPpdCUixvbtxu7SYhJDKt6_v8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3b01-B0gfuKe3e2R6Y+n6SFXTopZDCno\"",
    "mtime": "2025-12-29T15:11:05.245Z",
    "size": 15105,
    "path": "../public/api/_content/query/JBjQNF72MXEFrVM9feUPpdCUixvbtxu7SYhJDKt6_v8.1767020924919.json"
  },
  "/api/_content/query/JDjUJYsR-YjeCgM9PdGHsHmUoyVFJzfjMzmLCc8ChTg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3c8-IewWzbMpZWeMGCN4Qh75SAtypp0\"",
    "mtime": "2025-12-29T15:10:35.971Z",
    "size": 968,
    "path": "../public/api/_content/query/JDjUJYsR-YjeCgM9PdGHsHmUoyVFJzfjMzmLCc8ChTg.1767020924919.json"
  },
  "/api/_content/query/JM2ntvjvX1_Niq-v9Oab1vnuct5Pz1eXUoaQJY4Sd-8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"477-ZAM+DH2b7th6mVjLMurMAKxTSdk\"",
    "mtime": "2025-12-29T15:11:03.260Z",
    "size": 1143,
    "path": "../public/api/_content/query/JM2ntvjvX1_Niq-v9Oab1vnuct5Pz1eXUoaQJY4Sd-8.1767020924919.json"
  },
  "/api/_content/query/JWxMgRYq0QDlrLDNOoBzbFf7q3m1MlNcKYbGK7FyjQ0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"11fa1-NxQ5ZrLQSlKz9XeYKPoJZX7h5os\"",
    "mtime": "2025-12-29T15:11:01.026Z",
    "size": 73633,
    "path": "../public/api/_content/query/JWxMgRYq0QDlrLDNOoBzbFf7q3m1MlNcKYbGK7FyjQ0.1767020924919.json"
  },
  "/api/_content/query/JZ_84V-2WvTHVjG200aKJkaQ_NTxsFCLbydiRVqct7k.1767020924919.json": {
    "type": "application/json",
    "etag": "\"359-6+Me0hrGtWKgLdjhXceN6tXB1Wo\"",
    "mtime": "2025-12-29T15:10:55.729Z",
    "size": 857,
    "path": "../public/api/_content/query/JZ_84V-2WvTHVjG200aKJkaQ_NTxsFCLbydiRVqct7k.1767020924919.json"
  },
  "/api/_content/query/JiZEZqtrUmP-m4Db_xRUyHfNnHDQ9ksRnzmefu8p85M.1767020924919.json": {
    "type": "application/json",
    "etag": "\"24fe-8OlIOHLpQfXFhGmRE2AC/29SuYA\"",
    "mtime": "2025-12-29T15:10:47.394Z",
    "size": 9470,
    "path": "../public/api/_content/query/JiZEZqtrUmP-m4Db_xRUyHfNnHDQ9ksRnzmefu8p85M.1767020924919.json"
  },
  "/api/_content/query/JkmR1t97EJLob3zUp6lsp3l3vmqHTqC0flP4j0GAIvU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"49f-mCNaRIdURTvwH7aNzgGOtODW7Qw\"",
    "mtime": "2025-12-29T15:11:05.245Z",
    "size": 1183,
    "path": "../public/api/_content/query/JkmR1t97EJLob3zUp6lsp3l3vmqHTqC0flP4j0GAIvU.1767020924919.json"
  },
  "/api/_content/query/JyyY2oiFSOCUMlSEDZtNuGCJfw0sxBoPRJV_Csgn3kE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"327-0nbVtO1a1Qjm/nmfhPKL8NxV+b4\"",
    "mtime": "2025-12-29T15:10:53.490Z",
    "size": 807,
    "path": "../public/api/_content/query/JyyY2oiFSOCUMlSEDZtNuGCJfw0sxBoPRJV_Csgn3kE.1767020924919.json"
  },
  "/api/_content/query/KAshOVmUeVUX-A55mA4xdfqA5gM2mIN54vRnx8-0mmw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"190b-61Xd8X6fJ2nOQh4l7uQBmK2d6fw\"",
    "mtime": "2025-12-29T15:10:54.187Z",
    "size": 6411,
    "path": "../public/api/_content/query/KAshOVmUeVUX-A55mA4xdfqA5gM2mIN54vRnx8-0mmw.1767020924919.json"
  },
  "/api/_content/query/KDE0uV_pdyY2xYlo4gLpCFm1j3Pz53AfEgiurPY8DRs.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1d6-Lk8yVthmByeeBf2T2MtNPqyg7Rs\"",
    "mtime": "2025-12-29T15:11:00.556Z",
    "size": 470,
    "path": "../public/api/_content/query/KDE0uV_pdyY2xYlo4gLpCFm1j3Pz53AfEgiurPY8DRs.1767020924919.json"
  },
  "/api/_content/query/KTyZI5Ed9EV0XtB4wV9gIuIWGVHCzw9G9RC0UdE-R1E.1767020924919.json": {
    "type": "application/json",
    "etag": "\"7c5f-kbqjcCBOi9A67Uhpnr1oRhxXOSw\"",
    "mtime": "2025-12-29T15:10:30.501Z",
    "size": 31839,
    "path": "../public/api/_content/query/KTyZI5Ed9EV0XtB4wV9gIuIWGVHCzw9G9RC0UdE-R1E.1767020924919.json"
  },
  "/api/_content/query/KcaVnzsaBxnbdju0uLHetDSkP4ERuIUHhTNdA0n2Qfs.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1822f-9iFDbsmONRWcoED+wm7pq3l/Zns\"",
    "mtime": "2025-12-29T15:10:53.308Z",
    "size": 98863,
    "path": "../public/api/_content/query/KcaVnzsaBxnbdju0uLHetDSkP4ERuIUHhTNdA0n2Qfs.1767020924919.json"
  },
  "/api/_content/query/Kddq8BeXlAN2yC1ObNrX_607GNBDdl-pMPPgm4bUBWk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"591-TScEEVrxgVIoSFswIbs0uaI/zhU\"",
    "mtime": "2025-12-29T15:10:59.531Z",
    "size": 1425,
    "path": "../public/api/_content/query/Kddq8BeXlAN2yC1ObNrX_607GNBDdl-pMPPgm4bUBWk.1767020924919.json"
  },
  "/api/_content/query/KtYfpVMo-DZvNFhHs21bwSuijsH-QHpLd2EUyP-xPB4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3c2-NMsnKcV6OD+pdowJ5B0RjAmoMaQ\"",
    "mtime": "2025-12-29T15:10:36.865Z",
    "size": 962,
    "path": "../public/api/_content/query/KtYfpVMo-DZvNFhHs21bwSuijsH-QHpLd2EUyP-xPB4.1767020924919.json"
  },
  "/api/_content/query/L3yMhH8Bmn5SeXpDIRd2ThA1OnE0stx8DdgXkOkZ5CM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"585-1zLmacvuUKuC8+tmJTBng/sA0H0\"",
    "mtime": "2025-12-29T15:11:05.017Z",
    "size": 1413,
    "path": "../public/api/_content/query/L3yMhH8Bmn5SeXpDIRd2ThA1OnE0stx8DdgXkOkZ5CM.1767020924919.json"
  },
  "/api/_content/query/LSVNHr7UMZEyGXu_E4ejarZpeCFp-VIXWTWzrouR5d4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4f8-q/NIrAuOVg8F+lfqb2PjLschIl4\"",
    "mtime": "2025-12-29T15:10:32.682Z",
    "size": 1272,
    "path": "../public/api/_content/query/LSVNHr7UMZEyGXu_E4ejarZpeCFp-VIXWTWzrouR5d4.1767020924919.json"
  },
  "/api/_content/query/LUkXnxsU3PgT21RAmk-1F0ia_V7kH44E6TKK3yXgifU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2e7-CbG7TWLiQRlLPTXcYDLMMhg2+ao\"",
    "mtime": "2025-12-29T15:10:48.102Z",
    "size": 743,
    "path": "../public/api/_content/query/LUkXnxsU3PgT21RAmk-1F0ia_V7kH44E6TKK3yXgifU.1767020924919.json"
  },
  "/api/_content/query/LgyVGjMluw3B8bOWy-p1ScsNCZGUdUzIzrR8rfhpe9s.1767020924919.json": {
    "type": "application/json",
    "etag": "\"885-w9tGPaFPjl3yYbyUjspJdiwVpxI\"",
    "mtime": "2025-12-29T15:11:04.963Z",
    "size": 2181,
    "path": "../public/api/_content/query/LgyVGjMluw3B8bOWy-p1ScsNCZGUdUzIzrR8rfhpe9s.1767020924919.json"
  },
  "/api/_content/query/Ll2Dv--lgfW6NnWCl7WhwUnKHIr8KU4d3rg2hrHeX8U.1767020924919.json": {
    "type": "application/json",
    "etag": "\"6c-CG463FWhqi14sMR42uF8UQu7jvs\"",
    "mtime": "2025-12-29T15:10:42.213Z",
    "size": 108,
    "path": "../public/api/_content/query/Ll2Dv--lgfW6NnWCl7WhwUnKHIr8KU4d3rg2hrHeX8U.1767020924919.json"
  },
  "/api/_content/query/LoACna2Zp-zJH16sIKi_aOOKjZZo7gNQ-8pCv5OOyJQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"323-hKognQK7om26ZWXCtV1Nxnh1+ZI\"",
    "mtime": "2025-12-29T15:10:44.565Z",
    "size": 803,
    "path": "../public/api/_content/query/LoACna2Zp-zJH16sIKi_aOOKjZZo7gNQ-8pCv5OOyJQ.1767020924919.json"
  },
  "/api/_content/query/MAoPekHMoQhuMcqw00vQQObKsWlbkQ6l6lyV0CNqlmw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"345-/1KJ4oSem7HoL2Hndna+BlbQAHA\"",
    "mtime": "2025-12-29T15:10:55.288Z",
    "size": 837,
    "path": "../public/api/_content/query/MAoPekHMoQhuMcqw00vQQObKsWlbkQ6l6lyV0CNqlmw.1767020924919.json"
  },
  "/api/_content/query/MPqti5j3g6aw8gPCxb_PPcQpuyHDusKUOkbp9gsCD2k.1767020924919.json": {
    "type": "application/json",
    "etag": "\"507-/D3fnj7vhAsH/gINIKkfDgR7y7k\"",
    "mtime": "2025-12-29T15:11:03.514Z",
    "size": 1287,
    "path": "../public/api/_content/query/MPqti5j3g6aw8gPCxb_PPcQpuyHDusKUOkbp9gsCD2k.1767020924919.json"
  },
  "/api/_content/query/M_0Vk0yBJFuqyvnQqPEfSa4FNpSiDjRuRTmhXUrKQOU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3746-+Bx+jD76hx/4skK6KiwRunAEDgY\"",
    "mtime": "2025-12-29T15:10:48.308Z",
    "size": 14150,
    "path": "../public/api/_content/query/M_0Vk0yBJFuqyvnQqPEfSa4FNpSiDjRuRTmhXUrKQOU.1767020924919.json"
  },
  "/api/_content/query/Miqe7YwFJtVihCEWA_D6DZpZm6yUxt63vMTEjCnSXJ8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"a7f-IhU0syqVJ4AT0cn/AOD1zuhXGGs\"",
    "mtime": "2025-12-29T15:10:41.537Z",
    "size": 2687,
    "path": "../public/api/_content/query/Miqe7YwFJtVihCEWA_D6DZpZm6yUxt63vMTEjCnSXJ8.1767020924919.json"
  },
  "/api/_content/query/Mygtev9dWE-QsPYQ9yhjjPlSmpCv_HVG2fWmjeIh8cw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2dd-Dm6MtZSOFqN/Qk82/jKj31tEYI8\"",
    "mtime": "2025-12-29T15:10:52.050Z",
    "size": 733,
    "path": "../public/api/_content/query/Mygtev9dWE-QsPYQ9yhjjPlSmpCv_HVG2fWmjeIh8cw.1767020924919.json"
  },
  "/api/_content/query/N0ZlNkbQvjtykqlaPk-xXa_2kzyq45vPOsNioHc8gU4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"67-mJHKrxSS6Uj/d9+aznwQhzXwHD4\"",
    "mtime": "2025-12-29T15:10:46.310Z",
    "size": 103,
    "path": "../public/api/_content/query/N0ZlNkbQvjtykqlaPk-xXa_2kzyq45vPOsNioHc8gU4.1767020924919.json"
  },
  "/api/_content/query/NLcs_h2UB4qLDT5JClY46Fk61YnW3N21OsUOMsgSyGE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:27.251Z",
    "size": 11,
    "path": "../public/api/_content/query/NLcs_h2UB4qLDT5JClY46Fk61YnW3N21OsUOMsgSyGE.1767020924919.json"
  },
  "/api/_content/query/NOaWZBLi8U_9_o1z8KcCXvRJ2DuCWTdesdGgNLMZbkI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2b1-JFO/1PaIh+/r+gJ2XzknC1GKmmU\"",
    "mtime": "2025-12-29T15:10:53.972Z",
    "size": 689,
    "path": "../public/api/_content/query/NOaWZBLi8U_9_o1z8KcCXvRJ2DuCWTdesdGgNLMZbkI.1767020924919.json"
  },
  "/api/_content/query/O-oKDMv7vfizd2__Te67xOkSvulL0i1V8UX4zwHq1Ic.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2ba-ouX5rGWRrrtTjs75KmtfyI0AYsM\"",
    "mtime": "2025-12-29T15:10:53.990Z",
    "size": 698,
    "path": "../public/api/_content/query/O-oKDMv7vfizd2__Te67xOkSvulL0i1V8UX4zwHq1Ic.1767020924919.json"
  },
  "/api/_content/query/O4Lr2DY8g2RHAwV2HAVoHzRKNGtfvcjVQUty0Gdl-z0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2fc-0zhZKeu9IqnjXDMMSi0aTxvI+rw\"",
    "mtime": "2025-12-29T15:10:54.758Z",
    "size": 764,
    "path": "../public/api/_content/query/O4Lr2DY8g2RHAwV2HAVoHzRKNGtfvcjVQUty0Gdl-z0.1767020924919.json"
  },
  "/api/_content/query/O9wZkVObhV-UE2BkDYDvgKDSW-MWOrQAMjqdo1tb-m0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"485-TUJPNPi1gpMYgCVWpoNjkzwj2Jo\"",
    "mtime": "2025-12-29T15:11:03.066Z",
    "size": 1157,
    "path": "../public/api/_content/query/O9wZkVObhV-UE2BkDYDvgKDSW-MWOrQAMjqdo1tb-m0.1767020924919.json"
  },
  "/api/_content/query/OxAfAbjwF4Mwt-kpLnDoLU6llUJzjr7cq2draTdvfmk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"411-iCBZnIZLbQvRNku/gbAxCPhZ0Pc\"",
    "mtime": "2025-12-29T15:10:41.777Z",
    "size": 1041,
    "path": "../public/api/_content/query/OxAfAbjwF4Mwt-kpLnDoLU6llUJzjr7cq2draTdvfmk.1767020924919.json"
  },
  "/api/_content/query/P065-lTv25Ph5kLBoVAgf6HicJI0qerj5O_uC7fHPqI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"151-rJaDuGQh8GYWp+Pw/WRgeghMN1c\"",
    "mtime": "2025-12-29T15:10:32.700Z",
    "size": 337,
    "path": "../public/api/_content/query/P065-lTv25Ph5kLBoVAgf6HicJI0qerj5O_uC7fHPqI.1767020924919.json"
  },
  "/api/_content/query/P1_q3Z0cdP-zwO-iVH1NwGUaeFy0f2z7m4XsK8YmutM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:35.964Z",
    "size": 11,
    "path": "../public/api/_content/query/P1_q3Z0cdP-zwO-iVH1NwGUaeFy0f2z7m4XsK8YmutM.1767020924919.json"
  },
  "/api/_content/query/PRxC1Fzai6ooBmPgMb5drVPYOiu3I-ZVdFodTQUbrgU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:28.430Z",
    "size": 11,
    "path": "../public/api/_content/query/PRxC1Fzai6ooBmPgMb5drVPYOiu3I-ZVdFodTQUbrgU.1767020924919.json"
  },
  "/api/_content/query/PigTFw_CxE7CQTNCPg2L2mAMM1JA2lMpXwyh0d9xAhg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"40f-E26JBwlup8IaUKtRVAYljodPwJA\"",
    "mtime": "2025-12-29T15:10:42.026Z",
    "size": 1039,
    "path": "../public/api/_content/query/PigTFw_CxE7CQTNCPg2L2mAMM1JA2lMpXwyh0d9xAhg.1767020924919.json"
  },
  "/api/_content/query/PtxvrfKC9kcObeOvwjaE3zSCDstmLyOkgatHI7RzlUo.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1174-3C7YMx7x5z+jZjEdREeBhBp83CQ\"",
    "mtime": "2025-12-29T15:10:47.711Z",
    "size": 4468,
    "path": "../public/api/_content/query/PtxvrfKC9kcObeOvwjaE3zSCDstmLyOkgatHI7RzlUo.1767020924919.json"
  },
  "/api/_content/query/QPjtjILDveKuNAKAriu32UmxH1jGsKJMS6t33Mw6dXE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:38.375Z",
    "size": 11,
    "path": "../public/api/_content/query/QPjtjILDveKuNAKAriu32UmxH1jGsKJMS6t33Mw6dXE.1767020924919.json"
  },
  "/api/_content/query/QY5BEJBh6eRzvNFMz1ScRs7nKqOHHDKJAagPiOdlWkQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"ebc-mt0Dbzmq2DAxUD1Iw0Rpp4ioboQ\"",
    "mtime": "2025-12-29T15:10:52.050Z",
    "size": 3772,
    "path": "../public/api/_content/query/QY5BEJBh6eRzvNFMz1ScRs7nKqOHHDKJAagPiOdlWkQ.1767020924919.json"
  },
  "/api/_content/query/SK1HAQHqHJOcgG4BwMdkddx2obNfGMwPUakRCyiJS2I.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:27.219Z",
    "size": 11,
    "path": "../public/api/_content/query/SK1HAQHqHJOcgG4BwMdkddx2obNfGMwPUakRCyiJS2I.1767020924919.json"
  },
  "/api/_content/query/T4R2IyfUqbQnIYf55SZZo_jvMq2camUAO-dQIeyGiqw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"437-FRVHc+G3rP5o6RvSx3vx6FpmIno\"",
    "mtime": "2025-12-29T15:10:57.786Z",
    "size": 1079,
    "path": "../public/api/_content/query/T4R2IyfUqbQnIYf55SZZo_jvMq2camUAO-dQIeyGiqw.1767020924919.json"
  },
  "/api/_content/query/TKg5IdypJ2RF-gHz33D2Lz87prhwodBIegE_nXFnGuI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:11:00.535Z",
    "size": 11,
    "path": "../public/api/_content/query/TKg5IdypJ2RF-gHz33D2Lz87prhwodBIegE_nXFnGuI.1767020924919.json"
  },
  "/api/_content/query/TcCoRQf-kzG6F5eR-wC1N9l9ZDLfXRa1FkhcNx_5BtM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"be51-yQ3qawcnjcZEUeTfnyTjGY8gD7c\"",
    "mtime": "2025-12-29T15:10:31.850Z",
    "size": 48721,
    "path": "../public/api/_content/query/TcCoRQf-kzG6F5eR-wC1N9l9ZDLfXRa1FkhcNx_5BtM.1767020924919.json"
  },
  "/api/_content/query/TtUR429oVBcuFOHFCSAO1he1qCZ2wwBVnFCHO0w2OjY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"326f-UD+DbF/65Lf1u0hPPSxIlYK1Ek4\"",
    "mtime": "2025-12-29T15:10:45.808Z",
    "size": 12911,
    "path": "../public/api/_content/query/TtUR429oVBcuFOHFCSAO1he1qCZ2wwBVnFCHO0w2OjY.1767020924919.json"
  },
  "/api/_content/query/U0x-DMUAhdH6iSU0Yw85ilx6dIpSs_s-aCHCHxHXRUc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:30.209Z",
    "size": 11,
    "path": "../public/api/_content/query/U0x-DMUAhdH6iSU0Yw85ilx6dIpSs_s-aCHCHxHXRUc.1767020924919.json"
  },
  "/api/_content/query/U3xqmFd-T9Usx0HjxVZtJeRvGtcm-SsfD27_VPgMkTw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"6c-lIUGxn8J3o0rDUBV1PdflXCe+bE\"",
    "mtime": "2025-12-29T15:10:44.597Z",
    "size": 108,
    "path": "../public/api/_content/query/U3xqmFd-T9Usx0HjxVZtJeRvGtcm-SsfD27_VPgMkTw.1767020924919.json"
  },
  "/api/_content/query/U7xv37Cp0BWonatNS6aVsXZkoqlWWFA-Z_LUhsj1EP8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"e1f-nH///ttQ/fG27rOUkf59x6128yA\"",
    "mtime": "2025-12-29T15:10:39.399Z",
    "size": 3615,
    "path": "../public/api/_content/query/U7xv37Cp0BWonatNS6aVsXZkoqlWWFA-Z_LUhsj1EP8.1767020924919.json"
  },
  "/api/_content/query/UH9hDxBFLcBnSAbb1ibSut8qVs-FcXiL_QqmkGVB5uU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"919f-XFpf+pvFp4PeB1pKuj03TfvYpIA\"",
    "mtime": "2025-12-29T15:11:02.669Z",
    "size": 37279,
    "path": "../public/api/_content/query/UH9hDxBFLcBnSAbb1ibSut8qVs-FcXiL_QqmkGVB5uU.1767020924919.json"
  },
  "/api/_content/query/UHSfTjMwhzfqW9HABypwF17X4vfvaLkwKCvP3JFx7hY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"f44-JXgmoIQl0GoE1jrUtSlRrasCOaQ\"",
    "mtime": "2025-12-29T15:10:50.894Z",
    "size": 3908,
    "path": "../public/api/_content/query/UHSfTjMwhzfqW9HABypwF17X4vfvaLkwKCvP3JFx7hY.1767020924919.json"
  },
  "/api/_content/query/UP4-U7AXiNMHEY_YxQCc4_-DKX9wl-rgEXt5vN1MeLw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1902-H/xcO5hvVxA8zZnz/KOdSqAs724\"",
    "mtime": "2025-12-29T15:10:50.260Z",
    "size": 6402,
    "path": "../public/api/_content/query/UP4-U7AXiNMHEY_YxQCc4_-DKX9wl-rgEXt5vN1MeLw.1767020924919.json"
  },
  "/api/_content/query/UfWbMXKuNe5JHkao_S4CgSTHup2rHxzUS1Kp3rOmtBg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"6203-8eOLF+GAy6KwZlFZsA1KoyAO6b8\"",
    "mtime": "2025-12-29T15:10:27.219Z",
    "size": 25091,
    "path": "../public/api/_content/query/UfWbMXKuNe5JHkao_S4CgSTHup2rHxzUS1Kp3rOmtBg.1767020924919.json"
  },
  "/api/_content/query/UpZSop1CBqnkWaA_fM2rEGTqQoOIMSNGD9RHJX_X_7U.1767020924919.json": {
    "type": "application/json",
    "etag": "\"57e-R0PBYxJwQEnD2yDCkdPK6JwjXeE\"",
    "mtime": "2025-12-29T15:10:32.027Z",
    "size": 1406,
    "path": "../public/api/_content/query/UpZSop1CBqnkWaA_fM2rEGTqQoOIMSNGD9RHJX_X_7U.1767020924919.json"
  },
  "/api/_content/query/UpaOMDTvg_V6meL79NdHOM0jMmHCVbOM8S0IyICmqrg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3aa-cQcQ/hfThM47XNLm8fa40B41hIk\"",
    "mtime": "2025-12-29T15:10:37.474Z",
    "size": 938,
    "path": "../public/api/_content/query/UpaOMDTvg_V6meL79NdHOM0jMmHCVbOM8S0IyICmqrg.1767020924919.json"
  },
  "/api/_content/query/V6IeVwIe5fK7__1PqLa854f2-uSrfqiBrfI-LKu6JlQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:59.501Z",
    "size": 11,
    "path": "../public/api/_content/query/V6IeVwIe5fK7__1PqLa854f2-uSrfqiBrfI-LKu6JlQ.1767020924919.json"
  },
  "/api/_content/query/V6flIgQ3uyF8MJfmxSf8soAvGN6SkwE9qp6d_ikGbXQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2c3-C9/LU61vTOb77DXtOD1afKeCZsQ\"",
    "mtime": "2025-12-29T15:10:47.698Z",
    "size": 707,
    "path": "../public/api/_content/query/V6flIgQ3uyF8MJfmxSf8soAvGN6SkwE9qp6d_ikGbXQ.1767020924919.json"
  },
  "/api/_content/query/VEOX1StE27WIp6y3Ri4EXc6QZnnzDna_xf1GCSsrzZM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2e5a-INfqc7M4ZAY1qpJUYc26SW7aH9I\"",
    "mtime": "2025-12-29T15:10:30.193Z",
    "size": 11866,
    "path": "../public/api/_content/query/VEOX1StE27WIp6y3Ri4EXc6QZnnzDna_xf1GCSsrzZM.1767020924919.json"
  },
  "/api/_content/query/VKFynqJ31r7Me7vC9EnqMZHKFCUq4aGxCORSsFrdkHw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:57.411Z",
    "size": 11,
    "path": "../public/api/_content/query/VKFynqJ31r7Me7vC9EnqMZHKFCUq4aGxCORSsFrdkHw.1767020924919.json"
  },
  "/api/_content/query/VO_iB8IsytwO_0Mhjpgn0jI5DW0OXFk58xcX9AsV2_Y.1767020924919.json": {
    "type": "application/json",
    "etag": "\"8d03-hBhyLGCQQhtbjTYPprArzsQDptg\"",
    "mtime": "2025-12-29T15:10:58.619Z",
    "size": 36099,
    "path": "../public/api/_content/query/VO_iB8IsytwO_0Mhjpgn0jI5DW0OXFk58xcX9AsV2_Y.1767020924919.json"
  },
  "/api/_content/query/VUrJzYFIQSwCFPG7PUdMJOhd4OPcih5aFFdQEWwGxdk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"309-X5m+IwWOuv5aUtXGizz9ktqKPUE\"",
    "mtime": "2025-12-29T15:10:50.201Z",
    "size": 777,
    "path": "../public/api/_content/query/VUrJzYFIQSwCFPG7PUdMJOhd4OPcih5aFFdQEWwGxdk.1767020924919.json"
  },
  "/api/_content/query/Vcq4ctZ67fx7Dyt4cR2NfxDOQnDuKN13khUR-amuqI4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"548-9Jpf8CshVkKkh+nbR9KsOPTSyAo\"",
    "mtime": "2025-12-29T15:10:30.501Z",
    "size": 1352,
    "path": "../public/api/_content/query/Vcq4ctZ67fx7Dyt4cR2NfxDOQnDuKN13khUR-amuqI4.1767020924919.json"
  },
  "/api/_content/query/VjOBquQBPYcwme99hFnQ1ZHMA9pXFbx9gvwE-tsAPoA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1650e-kln3EB/Hr1ABgyYeiTVK+9vgjd0\"",
    "mtime": "2025-12-29T15:10:30.964Z",
    "size": 91406,
    "path": "../public/api/_content/query/VjOBquQBPYcwme99hFnQ1ZHMA9pXFbx9gvwE-tsAPoA.1767020924919.json"
  },
  "/api/_content/query/WAdG9kuHQDVxRxeef8MtgN_6tBJMlT1bt40Cpk80XAw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1fa-sGXvJIq7AZVveH4ciAL/jrWO+6w\"",
    "mtime": "2025-12-29T15:10:59.501Z",
    "size": 506,
    "path": "../public/api/_content/query/WAdG9kuHQDVxRxeef8MtgN_6tBJMlT1bt40Cpk80XAw.1767020924919.json"
  },
  "/api/_content/query/WFrHivBqH0c8Cwvi5Mve7ule8gofnIklApXbttWPWl8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"449-wFbGsg0xRiNvVgsvAPb2x3jfrsM\"",
    "mtime": "2025-12-29T15:10:28.322Z",
    "size": 1097,
    "path": "../public/api/_content/query/WFrHivBqH0c8Cwvi5Mve7ule8gofnIklApXbttWPWl8.1767020924919.json"
  },
  "/api/_content/query/WKrlXyc3awgr_57swNikBytMkUkqRNmht2e83oKDcSM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"18862-upzhLFUB7ftR9Bt92x6A9XHc16o\"",
    "mtime": "2025-12-29T15:10:31.840Z",
    "size": 100450,
    "path": "../public/api/_content/query/WKrlXyc3awgr_57swNikBytMkUkqRNmht2e83oKDcSM.1767020924919.json"
  },
  "/api/_content/query/WOpa6zqoXa9sd0w06pXE9sSGYMWvEYeZL1CDegltgTY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"e4e6-C+e93XpiRSf6NjbL3iar8WLnDDQ\"",
    "mtime": "2025-12-29T15:10:44.145Z",
    "size": 58598,
    "path": "../public/api/_content/query/WOpa6zqoXa9sd0w06pXE9sSGYMWvEYeZL1CDegltgTY.1767020924919.json"
  },
  "/api/_content/query/WkJbvq54GaSC7EROHLJqZCS3996aAFZ5Xyt1KIehU0w.1767020924919.json": {
    "type": "application/json",
    "etag": "\"d0f8-BaQYXaQOzMg7QW0ZAgWZiQaaU2w\"",
    "mtime": "2025-12-29T15:10:45.833Z",
    "size": 53496,
    "path": "../public/api/_content/query/WkJbvq54GaSC7EROHLJqZCS3996aAFZ5Xyt1KIehU0w.1767020924919.json"
  },
  "/api/_content/query/WyTQKWbPgkhaMrP2Kswv3463TFhbrFY4PVZHd7S2muc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"436-O8H1ntNEgAIP6Id2geBhAKvuIpc\"",
    "mtime": "2025-12-29T15:11:02.618Z",
    "size": 1078,
    "path": "../public/api/_content/query/WyTQKWbPgkhaMrP2Kswv3463TFhbrFY4PVZHd7S2muc.1767020924919.json"
  },
  "/api/_content/query/X2O0MPiBaNf2XEsta-T5T3M2c-UzGyebycGnnmAeiq8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"edb-/FoQw0wlFSIBHyBystlCN0phnec\"",
    "mtime": "2025-12-29T15:10:53.095Z",
    "size": 3803,
    "path": "../public/api/_content/query/X2O0MPiBaNf2XEsta-T5T3M2c-UzGyebycGnnmAeiq8.1767020924919.json"
  },
  "/api/_content/query/X3PYtZaBe2E2BHt2OIj7XjVe3uSCOCJx0T-Yp2VNUWg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"70-Zy3W7oBcSHte1GyV+ZtHePOezjE\"",
    "mtime": "2025-12-29T15:10:40.481Z",
    "size": 112,
    "path": "../public/api/_content/query/X3PYtZaBe2E2BHt2OIj7XjVe3uSCOCJx0T-Yp2VNUWg.1767020924919.json"
  },
  "/api/_content/query/XQMz00tDf3kCSVhCLc910uqfeoitEyKVXja7FZjXyuI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"46f-Jp4C7xtbIqr3dMgoa5s69abOoSg\"",
    "mtime": "2025-12-29T15:10:59.767Z",
    "size": 1135,
    "path": "../public/api/_content/query/XQMz00tDf3kCSVhCLc910uqfeoitEyKVXja7FZjXyuI.1767020924919.json"
  },
  "/api/_content/query/XyU9Uxztcum_Ya4FWoaPoaI2_uIsqvhxL4MWRBfZSto.1767020924919.json": {
    "type": "application/json",
    "etag": "\"29b-Chksg5EyrSepLLIZXcYs/edlu4M\"",
    "mtime": "2025-12-29T15:10:51.806Z",
    "size": 667,
    "path": "../public/api/_content/query/XyU9Uxztcum_Ya4FWoaPoaI2_uIsqvhxL4MWRBfZSto.1767020924919.json"
  },
  "/api/_content/query/YHsopaTu4Nlx5LGHIEDhhYZ57-X71yUtN-op1EjKBMI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4f0-8p7okAo60H0FqOB11UPOTFL/alc\"",
    "mtime": "2025-12-29T15:10:43.410Z",
    "size": 1264,
    "path": "../public/api/_content/query/YHsopaTu4Nlx5LGHIEDhhYZ57-X71yUtN-op1EjKBMI.1767020924919.json"
  },
  "/api/_content/query/YJpJHhq_C2Uk_XFIZVGxhkqTSm0GQaurdFURcxLj0MU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"508-diXIKacpvzVZP6JAx/oWTDVTmxs\"",
    "mtime": "2025-12-29T15:10:44.145Z",
    "size": 1288,
    "path": "../public/api/_content/query/YJpJHhq_C2Uk_XFIZVGxhkqTSm0GQaurdFURcxLj0MU.1767020924919.json"
  },
  "/api/_content/query/YScnEV-U6-Aq32NXRGS7Yh60Rl8blBsZZtalQrhm5oY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"8c93-2ic7296bG9M5uPWmOwAFMjF4jb4\"",
    "mtime": "2025-12-29T15:10:46.061Z",
    "size": 35987,
    "path": "../public/api/_content/query/YScnEV-U6-Aq32NXRGS7Yh60Rl8blBsZZtalQrhm5oY.1767020924919.json"
  },
  "/api/_content/query/Yz-N9LzBLkzU59GJbyp0kRARRyqZKb3Mbs2yMfKATEI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2abf-7+xhluGRm6vjrZfRAxyJQVIkHJw\"",
    "mtime": "2025-12-29T15:10:58.909Z",
    "size": 10943,
    "path": "../public/api/_content/query/Yz-N9LzBLkzU59GJbyp0kRARRyqZKb3Mbs2yMfKATEI.1767020924919.json"
  },
  "/api/_content/query/Z-2ApQnpJHknZRFNyUmxmn7Huad0rT44jmpY46aDYgE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"16b6-k3ohjXJ32DhPpy4WPhQi3W7nV9k\"",
    "mtime": "2025-12-29T15:10:49.812Z",
    "size": 5814,
    "path": "../public/api/_content/query/Z-2ApQnpJHknZRFNyUmxmn7Huad0rT44jmpY46aDYgE.1767020924919.json"
  },
  "/api/_content/query/Z76uJ0lcCX5rkzv-G9UHJVE45iarlvP5MqVwhtjc3tU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2d32-EjB2nDrO1qCDRUI5djMXJ0xeUys\"",
    "mtime": "2025-12-29T15:10:59.541Z",
    "size": 11570,
    "path": "../public/api/_content/query/Z76uJ0lcCX5rkzv-G9UHJVE45iarlvP5MqVwhtjc3tU.1767020924919.json"
  },
  "/api/_content/query/ZB8Dt-sORfTvuSnsxPR8T0hNUZbCu1HEk2PXWvixbTs.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:27.336Z",
    "size": 11,
    "path": "../public/api/_content/query/ZB8Dt-sORfTvuSnsxPR8T0hNUZbCu1HEk2PXWvixbTs.1767020924919.json"
  },
  "/api/_content/query/ZBoD6EgIgaSY8XxyzHId4DVL8omFrH_SFw65sQWKEmI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"588-wI/Vfq1Z1tUZkPhFkPOqfnSQlBQ\"",
    "mtime": "2025-12-29T15:10:59.541Z",
    "size": 1416,
    "path": "../public/api/_content/query/ZBoD6EgIgaSY8XxyzHId4DVL8omFrH_SFw65sQWKEmI.1767020924919.json"
  },
  "/api/_content/query/ZES4sdgg2RumORpDfKaVr9JIovn0Ze_ILhARmSofy00.1767020924919.json": {
    "type": "application/json",
    "etag": "\"537-BmCVbAJc0VQu/Trc2w/g1GTZBTk\"",
    "mtime": "2025-12-29T15:10:45.833Z",
    "size": 1335,
    "path": "../public/api/_content/query/ZES4sdgg2RumORpDfKaVr9JIovn0Ze_ILhARmSofy00.1767020924919.json"
  },
  "/api/_content/query/ZHTeQw7k4jfTGoxy4SJ7Ow_yMMXvcFbsuX8dlboMPWY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"70-gqGlV4aeZDDcVROcCWh6BIImRHM\"",
    "mtime": "2025-12-29T15:10:39.845Z",
    "size": 112,
    "path": "../public/api/_content/query/ZHTeQw7k4jfTGoxy4SJ7Ow_yMMXvcFbsuX8dlboMPWY.1767020924919.json"
  },
  "/api/_content/query/ZJjsofx6wB_bN_u2rc6xbdUplD-autU_QMOoJolStJI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"5f3-qfULoGzQ3jgrfsJG5KE9/VBTNOQ\"",
    "mtime": "2025-12-29T15:10:55.276Z",
    "size": 1523,
    "path": "../public/api/_content/query/ZJjsofx6wB_bN_u2rc6xbdUplD-autU_QMOoJolStJI.1767020924919.json"
  },
  "/api/_content/query/ZMYdxj5nST1LZMyIBYsp9d3yEj8hvrbPvv7ww7iwA1o.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4a1-xKKwuKWenSvU43THquSzuv6j6rI\"",
    "mtime": "2025-12-29T15:10:46.280Z",
    "size": 1185,
    "path": "../public/api/_content/query/ZMYdxj5nST1LZMyIBYsp9d3yEj8hvrbPvv7ww7iwA1o.1767020924919.json"
  },
  "/api/_content/query/ZiPsG4YZzpAiXT4iArWC2jwQYe9TYUHTeRVSSsMxcp8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3bf4-U4AjHu0K/BhwXIWk0TkJN8F1+CU\"",
    "mtime": "2025-12-29T15:11:03.066Z",
    "size": 15348,
    "path": "../public/api/_content/query/ZiPsG4YZzpAiXT4iArWC2jwQYe9TYUHTeRVSSsMxcp8.1767020924919.json"
  },
  "/api/_content/query/ZpCXX9ltrvo3VRtvaHXCRvDSZ-TFP6CO7r3-V1Vxu8E.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2d8-3WHfiKHNvu1MAyY4IjRXWkA38N0\"",
    "mtime": "2025-12-29T15:10:55.282Z",
    "size": 728,
    "path": "../public/api/_content/query/ZpCXX9ltrvo3VRtvaHXCRvDSZ-TFP6CO7r3-V1Vxu8E.1767020924919.json"
  },
  "/api/_content/query/ZpETDPjSnYM3I3rqm8kCrZqGNhJwYwSdzTxBmHgu-0o.1767020924919.json": {
    "type": "application/json",
    "etag": "\"d367-cEgKKdQW0YHyDRkQ9AGXlImlV8w\"",
    "mtime": "2025-12-29T15:10:30.209Z",
    "size": 54119,
    "path": "../public/api/_content/query/ZpETDPjSnYM3I3rqm8kCrZqGNhJwYwSdzTxBmHgu-0o.1767020924919.json"
  },
  "/api/_content/query/_0S3WCll6piL1jeRBvXXOmCEDgqXHfUIToux0YyQMa0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"56c-qP0gJinZhRjIMlZajYiuLiYTC0o\"",
    "mtime": "2025-12-29T15:11:05.874Z",
    "size": 1388,
    "path": "../public/api/_content/query/_0S3WCll6piL1jeRBvXXOmCEDgqXHfUIToux0YyQMa0.1767020924919.json"
  },
  "/api/_content/query/_B0ES4u0MLRyKMl5xyN3Htk76wR4q-tm4uPcav4wBxM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"522-+ZebrTUpjv+gBDWhijoBTfjYWdQ\"",
    "mtime": "2025-12-29T15:10:43.730Z",
    "size": 1314,
    "path": "../public/api/_content/query/_B0ES4u0MLRyKMl5xyN3Htk76wR4q-tm4uPcav4wBxM.1767020924919.json"
  },
  "/api/_content/query/_SGxbsPyXP1vl1XlvwkhaX10NQTH4QW57gT3XMABhyE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"327-zoV12obmJjPE8DF48r+7GUapTBw\"",
    "mtime": "2025-12-29T15:10:47.881Z",
    "size": 807,
    "path": "../public/api/_content/query/_SGxbsPyXP1vl1XlvwkhaX10NQTH4QW57gT3XMABhyE.1767020924919.json"
  },
  "/api/_content/query/_f2l3MhuiySJdntNIKr1vXhSpX-pMBGmcBmBoANlu5s.1767020924919.json": {
    "type": "application/json",
    "etag": "\"36f-P3Awom9gaa5mnubUHkZdgH7+VyU\"",
    "mtime": "2025-12-29T15:10:39.371Z",
    "size": 879,
    "path": "../public/api/_content/query/_f2l3MhuiySJdntNIKr1vXhSpX-pMBGmcBmBoANlu5s.1767020924919.json"
  },
  "/api/_content/query/_kPQS8NMR17HlONdyqgm--4uCvH_RbG7sKFOJAQ8X8E.1767020924919.json": {
    "type": "application/json",
    "etag": "\"330-/LRsMfbIBwXCu+M2pNlaHEkMnuw\"",
    "mtime": "2025-12-29T15:10:41.247Z",
    "size": 816,
    "path": "../public/api/_content/query/_kPQS8NMR17HlONdyqgm--4uCvH_RbG7sKFOJAQ8X8E.1767020924919.json"
  },
  "/api/_content/query/aLWqpI8LFM1sm2KQVA8-9njFPqS3DB7QSj5h3CwNGkY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"23ab-Rq+JPQHutaMas5nFibzPjBI4gCs\"",
    "mtime": "2025-12-29T15:11:03.083Z",
    "size": 9131,
    "path": "../public/api/_content/query/aLWqpI8LFM1sm2KQVA8-9njFPqS3DB7QSj5h3CwNGkY.1767020924919.json"
  },
  "/api/_content/query/ajr_1F1ypR8jRd84j4_P9aG2Uh4efk5iIlTU6Te4PpA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4de-ol8hHvVtmsMyIquHp3MkSAoxNwk\"",
    "mtime": "2025-12-29T15:10:45.597Z",
    "size": 1246,
    "path": "../public/api/_content/query/ajr_1F1ypR8jRd84j4_P9aG2Uh4efk5iIlTU6Te4PpA.1767020924919.json"
  },
  "/api/_content/query/aw0xNqD_Z2k01ox5Y2znxf6blpy2fFXQzTUb9T2SPYA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4f7-xjad/0CMIRkiprbLyZgsAOxe8zk\"",
    "mtime": "2025-12-29T15:10:30.089Z",
    "size": 1271,
    "path": "../public/api/_content/query/aw0xNqD_Z2k01ox5Y2znxf6blpy2fFXQzTUb9T2SPYA.1767020924919.json"
  },
  "/api/_content/query/bOjURkcREBm0AfZKFNcFlT1U6roI__k7uGSG9y9dWKQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"47e-MjT8CQk0EupjbKmdKuNCobB9v/4\"",
    "mtime": "2025-12-29T15:10:34.398Z",
    "size": 1150,
    "path": "../public/api/_content/query/bOjURkcREBm0AfZKFNcFlT1U6roI__k7uGSG9y9dWKQ.1767020924919.json"
  },
  "/api/_content/query/bSJ6mXVHTtW-AU6WvDqHbQNVzA4qoVFHWVis-GisFns.1767020924919.json": {
    "type": "application/json",
    "etag": "\"76-YBem7+sGdRaoxOQh0Kru+r/G/TU\"",
    "mtime": "2025-12-29T15:10:35.971Z",
    "size": 118,
    "path": "../public/api/_content/query/bSJ6mXVHTtW-AU6WvDqHbQNVzA4qoVFHWVis-GisFns.1767020924919.json"
  },
  "/api/_content/query/bknxKbqgekNbjWtc5cr1zGFPZcYQNnYukbZiUTHX_6s.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b4e-ahEpAZkopULUNLCP8gv+SHTLvMg\"",
    "mtime": "2025-12-29T15:10:35.965Z",
    "size": 2894,
    "path": "../public/api/_content/query/bknxKbqgekNbjWtc5cr1zGFPZcYQNnYukbZiUTHX_6s.1767020924919.json"
  },
  "/api/_content/query/c1eKCpNczIkZ7zX7Fv4IV09aT6hU7uhcl7a9NqfJOeQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"335-sEKqhgR51Ac981PvNXxGHs5NeAA\"",
    "mtime": "2025-12-29T15:10:47.122Z",
    "size": 821,
    "path": "../public/api/_content/query/c1eKCpNczIkZ7zX7Fv4IV09aT6hU7uhcl7a9NqfJOeQ.1767020924919.json"
  },
  "/api/_content/query/ce7Ezt4F_lDvaf7pO4MBprxSsTzK_WnNxdeKGqYJN34.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:11:01.455Z",
    "size": 11,
    "path": "../public/api/_content/query/ce7Ezt4F_lDvaf7pO4MBprxSsTzK_WnNxdeKGqYJN34.1767020924919.json"
  },
  "/api/_content/query/cyk1JYt03izRorxyxFnNhy7uR2-W66jh_Co6x2L73Mc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:11:03.083Z",
    "size": 11,
    "path": "../public/api/_content/query/cyk1JYt03izRorxyxFnNhy7uR2-W66jh_Co6x2L73Mc.1767020924919.json"
  },
  "/api/_content/query/dEl5zrzhMDlhbLvBpmSpEVskSLWpmpvd4hSAJFwovyU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:35.971Z",
    "size": 11,
    "path": "../public/api/_content/query/dEl5zrzhMDlhbLvBpmSpEVskSLWpmpvd4hSAJFwovyU.1767020924919.json"
  },
  "/api/_content/query/dF5SdsJUMqZ_A8DZd6tFE9ZknkbchPPOOUeQvJb9a-s.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2a70-4EVQzt4JgKG7qCT481hNtGLeeT4\"",
    "mtime": "2025-12-29T15:10:36.392Z",
    "size": 10864,
    "path": "../public/api/_content/query/dF5SdsJUMqZ_A8DZd6tFE9ZknkbchPPOOUeQvJb9a-s.1767020924919.json"
  },
  "/api/_content/query/dcyIMYGBb2HyK4DS-qRY_dYX8wg4454BIJOjOxWIGeY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"35a-v2iHGHIRyTS/oo188J5M+NuPlt4\"",
    "mtime": "2025-12-29T15:11:05.895Z",
    "size": 858,
    "path": "../public/api/_content/query/dcyIMYGBb2HyK4DS-qRY_dYX8wg4454BIJOjOxWIGeY.1767020924919.json"
  },
  "/api/_content/query/dpWBdvxYA1WFLbCteUXQYH0215skwGgN-7_-jZtfqjY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2d01-ieWt16imeVm2BKYUoH62w3fETDI\"",
    "mtime": "2025-12-29T15:10:55.729Z",
    "size": 11521,
    "path": "../public/api/_content/query/dpWBdvxYA1WFLbCteUXQYH0215skwGgN-7_-jZtfqjY.1767020924919.json"
  },
  "/api/_content/query/eOZWsjdz3ixeKUgWeLOSXcCXsx7QmOqVweGvBrAsVYA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2194-nlpRdzG5hZG0a4kkfBxBdRuWLRE\"",
    "mtime": "2025-12-29T15:10:55.282Z",
    "size": 8596,
    "path": "../public/api/_content/query/eOZWsjdz3ixeKUgWeLOSXcCXsx7QmOqVweGvBrAsVYA.1767020924919.json"
  },
  "/api/_content/query/eSVLcrK2K7f8ZpuovJYW133GTt157lsaF1VFfmTZsDk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"18c-9U7kyX7TciwobVrAsOWFeazrKa0\"",
    "mtime": "2025-12-29T15:10:46.280Z",
    "size": 396,
    "path": "../public/api/_content/query/eSVLcrK2K7f8ZpuovJYW133GTt157lsaF1VFfmTZsDk.1767020924919.json"
  },
  "/api/_content/query/enD2AGOkccknYMESHJNZdhDmAh_n4vtUs3Ct5CSC3n8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1b4-NvP9w9M8WnDVTVFueAgEMoIUO5I\"",
    "mtime": "2025-12-29T15:10:35.964Z",
    "size": 436,
    "path": "../public/api/_content/query/enD2AGOkccknYMESHJNZdhDmAh_n4vtUs3Ct5CSC3n8.1767020924919.json"
  },
  "/api/_content/query/f2Jq1_qq9MlvQAuiOQECpzHeJ0xHzU2BhKtFg7oeBXM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"43f1-fVRM3oaYNEhQgkH5gPOZtzDG4x4\"",
    "mtime": "2025-12-29T15:10:32.293Z",
    "size": 17393,
    "path": "../public/api/_content/query/f2Jq1_qq9MlvQAuiOQECpzHeJ0xHzU2BhKtFg7oeBXM.1767020924919.json"
  },
  "/api/_content/query/f8-ICmXymcLP7sAtzhBWfeDxr0bTDaQGMWaIUsg24MA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"520-N/10Go8FThSAT0QutisiCE5JQcE\"",
    "mtime": "2025-12-29T15:10:30.097Z",
    "size": 1312,
    "path": "../public/api/_content/query/f8-ICmXymcLP7sAtzhBWfeDxr0bTDaQGMWaIUsg24MA.1767020924919.json"
  },
  "/api/_content/query/fF5ks0711eaFfB3byks9AmlBPUFupzKwNI-G_w4Vzqs.1767020924919.json": {
    "type": "application/json",
    "etag": "\"44a-YaCMZxB5EkOp4F2EsN2mK6cSGtQ\"",
    "mtime": "2025-12-29T15:11:02.687Z",
    "size": 1098,
    "path": "../public/api/_content/query/fF5ks0711eaFfB3byks9AmlBPUFupzKwNI-G_w4Vzqs.1767020924919.json"
  },
  "/api/_content/query/fK3W4kcxcNf3QX525iBTayntzaxSmvThNX8mYmgx-e4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"13fd3-UevhDIgw/zpgctt+a5faMQUMw3E\"",
    "mtime": "2025-12-29T15:10:38.771Z",
    "size": 81875,
    "path": "../public/api/_content/query/fK3W4kcxcNf3QX525iBTayntzaxSmvThNX8mYmgx-e4.1767020924919.json"
  },
  "/api/_content/query/gMMkuhY2VVp_O1DPIKfH0PVMpUdPiG89eAIWVD2BU0w.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1a4c-j0CKG/W97CMZb9ri14eNk41VwTc\"",
    "mtime": "2025-12-29T15:10:50.867Z",
    "size": 6732,
    "path": "../public/api/_content/query/gMMkuhY2VVp_O1DPIKfH0PVMpUdPiG89eAIWVD2BU0w.1767020924919.json"
  },
  "/api/_content/query/gRsTdFHZPjE6Jx53E2iLAqXZqVQV3jmfhXUKY7nAoYI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1e19-wa3S3wfRyuBuQzJIRyE60kg3Wlg\"",
    "mtime": "2025-12-29T15:10:32.700Z",
    "size": 7705,
    "path": "../public/api/_content/query/gRsTdFHZPjE6Jx53E2iLAqXZqVQV3jmfhXUKY7nAoYI.1767020924919.json"
  },
  "/api/_content/query/gV1eMe9d4g641NMKNv8HR-RUM8PDq1GaL8PpssL9LoA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"576-KGcR2Hfem1kQFulau3trAOHOY9Y\"",
    "mtime": "2025-12-29T15:10:53.972Z",
    "size": 1398,
    "path": "../public/api/_content/query/gV1eMe9d4g641NMKNv8HR-RUM8PDq1GaL8PpssL9LoA.1767020924919.json"
  },
  "/api/_content/query/gkLHnE4-ZmSWVzolfh9wVsujfGTA0fBU3ZwBT7hJWug.1767020924919.json": {
    "type": "application/json",
    "etag": "\"55c2-BZM9mINvV5Eqt+ZFWoXvpSjUjxM\"",
    "mtime": "2025-12-29T15:10:57.786Z",
    "size": 21954,
    "path": "../public/api/_content/query/gkLHnE4-ZmSWVzolfh9wVsujfGTA0fBU3ZwBT7hJWug.1767020924919.json"
  },
  "/api/_content/query/gxFAdnkvdQX0TQmHYhB9iMvw14PjP1W5PkGQB-HUEhI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"19e2-eA7CYD7RHQYpOkC5D9SSrtYrFOo\"",
    "mtime": "2025-12-29T15:10:42.007Z",
    "size": 6626,
    "path": "../public/api/_content/query/gxFAdnkvdQX0TQmHYhB9iMvw14PjP1W5PkGQB-HUEhI.1767020924919.json"
  },
  "/api/_content/query/hA9ZojdC9Y-6ScCS4wJVdFEtP9DwcR5sqsgLCGV7vd0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:42.259Z",
    "size": 11,
    "path": "../public/api/_content/query/hA9ZojdC9Y-6ScCS4wJVdFEtP9DwcR5sqsgLCGV7vd0.1767020924919.json"
  },
  "/api/_content/query/hL3qdjgO1_wHuXivbqUy-mVqK4NQ9qOwk4ValRPozQI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2db-x24k3sCqdamCG8xw7mYMI/XhUo8\"",
    "mtime": "2025-12-29T15:10:55.339Z",
    "size": 731,
    "path": "../public/api/_content/query/hL3qdjgO1_wHuXivbqUy-mVqK4NQ9qOwk4ValRPozQI.1767020924919.json"
  },
  "/api/_content/query/hS1SquDufhz4jHPK8U9kEUGXZ3ZCtLjqxPu3vlDMR7k.1767020924919.json": {
    "type": "application/json",
    "etag": "\"18e-IuM1WMgK8M8g3AJ86nEKycBjNrg\"",
    "mtime": "2025-12-29T15:10:27.251Z",
    "size": 398,
    "path": "../public/api/_content/query/hS1SquDufhz4jHPK8U9kEUGXZ3ZCtLjqxPu3vlDMR7k.1767020924919.json"
  },
  "/api/_content/query/hT0NQSsyQdeeP2BL8NEpBieXAM73h1997jHYABnEy7c.1767020924919.json": {
    "type": "application/json",
    "etag": "\"553-f7YKMvPLax3EVk9hiu0nwIvHOaA\"",
    "mtime": "2025-12-29T15:10:30.207Z",
    "size": 1363,
    "path": "../public/api/_content/query/hT0NQSsyQdeeP2BL8NEpBieXAM73h1997jHYABnEy7c.1767020924919.json"
  },
  "/api/_content/query/hf-PKjXa8PZPtt4xjlOpncVJsQeacbsK_6SKQYW8kQg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"204c-68VfQ2fqYKnKMWud/5fVNHloVDk\"",
    "mtime": "2025-12-29T15:10:55.906Z",
    "size": 8268,
    "path": "../public/api/_content/query/hf-PKjXa8PZPtt4xjlOpncVJsQeacbsK_6SKQYW8kQg.1767020924919.json"
  },
  "/api/_content/query/hxrke_BVJkt6YeoodoJOV1Borxo-0E6-0SU0JPoAWyE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:32.278Z",
    "size": 11,
    "path": "../public/api/_content/query/hxrke_BVJkt6YeoodoJOV1Borxo-0E6-0SU0JPoAWyE.1767020924919.json"
  },
  "/api/_content/query/i6kl072h8vWM_q7VS7BcccM4T11ABWfy6ErjQr5_tJk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"78c-bJnBa3YjImn/tw3Gytb69Nff9Tk\"",
    "mtime": "2025-12-29T15:10:41.717Z",
    "size": 1932,
    "path": "../public/api/_content/query/i6kl072h8vWM_q7VS7BcccM4T11ABWfy6ErjQr5_tJk.1767020924919.json"
  },
  "/api/_content/query/i88wozNmKK87k8-EbTeB-AzxQp_lOMsHEJtW18wznsU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:46.252Z",
    "size": 11,
    "path": "../public/api/_content/query/i88wozNmKK87k8-EbTeB-AzxQp_lOMsHEJtW18wznsU.1767020924919.json"
  },
  "/api/_content/query/iKAX6QmOo_KYisFeuggxdJLXIPDVdXXLAqxQsZHpqIo.1767020924919.json": {
    "type": "application/json",
    "etag": "\"563-m2QXQSwxbWee4ADzGkRmIHers94\"",
    "mtime": "2025-12-29T15:10:58.619Z",
    "size": 1379,
    "path": "../public/api/_content/query/iKAX6QmOo_KYisFeuggxdJLXIPDVdXXLAqxQsZHpqIo.1767020924919.json"
  },
  "/api/_content/query/iWCBgC7pEik2tIgK9A0PeXMhA53qSnNPbS4T4vN3L04.1767020924919.json": {
    "type": "application/json",
    "etag": "\"478-xM0zhR5ud2Hn0qc6fYzVRf+ykak\"",
    "mtime": "2025-12-29T15:10:34.449Z",
    "size": 1144,
    "path": "../public/api/_content/query/iWCBgC7pEik2tIgK9A0PeXMhA53qSnNPbS4T4vN3L04.1767020924919.json"
  },
  "/api/_content/query/ieNOljOYp_QzsXNofNu6NecIgcA2ioRgDdhZDUQoouc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"29d-mJNCXdjj69wLfSHCQJYqmxMbkFw\"",
    "mtime": "2025-12-29T15:10:51.392Z",
    "size": 669,
    "path": "../public/api/_content/query/ieNOljOYp_QzsXNofNu6NecIgcA2ioRgDdhZDUQoouc.1767020924919.json"
  },
  "/api/_content/query/ihM3XgbzA7nZibg6DH12z54T5hMug4L9HAsRbHzy3Vk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2bf9-ikJLVY1UZOfS7dxPAiIxNwnRhDU\"",
    "mtime": "2025-12-29T15:10:54.823Z",
    "size": 11257,
    "path": "../public/api/_content/query/ihM3XgbzA7nZibg6DH12z54T5hMug4L9HAsRbHzy3Vk.1767020924919.json"
  },
  "/api/_content/query/izLXXr6uj0uMQjnuXlB60gf1GKGAUI_XUL60H0opdFg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"a5b-KUvOXW1K+DmpjqxB7WDPMkWb6D4\"",
    "mtime": "2025-12-29T15:11:05.321Z",
    "size": 2651,
    "path": "../public/api/_content/query/izLXXr6uj0uMQjnuXlB60gf1GKGAUI_XUL60H0opdFg.1767020924919.json"
  },
  "/api/_content/query/jq3hEJKVsNq5WTAIJStYbvDIfm4eYP-RUMgf8omJyVI.1767020924919.json": {
    "type": "application/json",
    "etag": "\"9466-p7xt/ekmeAnAoFYts2RaREsxWFY\"",
    "mtime": "2025-12-29T15:11:00.558Z",
    "size": 37990,
    "path": "../public/api/_content/query/jq3hEJKVsNq5WTAIJStYbvDIfm4eYP-RUMgf8omJyVI.1767020924919.json"
  },
  "/api/_content/query/jrLRTA_ugEvbGHLXZ5zIQp0RaCmOSDyf8Ch1rGrb3bM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"e319-NmXeHB90s1PKrkdC94yPc2he/gA\"",
    "mtime": "2025-12-29T15:10:44.128Z",
    "size": 58137,
    "path": "../public/api/_content/query/jrLRTA_ugEvbGHLXZ5zIQp0RaCmOSDyf8Ch1rGrb3bM.1767020924919.json"
  },
  "/api/_content/query/kh7qgh2uWAcbr9z83XfJnwuPfU2od9tVWOhnnNuppuo.1767020924919.json": {
    "type": "application/json",
    "etag": "\"31b-ufVVWiqwZjeV+IVKIJu0fAY4Q5k\"",
    "mtime": "2025-12-29T15:10:47.630Z",
    "size": 795,
    "path": "../public/api/_content/query/kh7qgh2uWAcbr9z83XfJnwuPfU2od9tVWOhnnNuppuo.1767020924919.json"
  },
  "/api/_content/query/kyVN7TSGj0NFigh60reEUsguClEBvgAUUghxo682z0k.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2bd-Hllsut1TMOAPHO7ovxdyoA2MSzc\"",
    "mtime": "2025-12-29T15:10:47.376Z",
    "size": 701,
    "path": "../public/api/_content/query/kyVN7TSGj0NFigh60reEUsguClEBvgAUUghxo682z0k.1767020924919.json"
  },
  "/api/_content/query/l2jWlYFkuOa0yy_W5-ry1ceLHyPMiv3UJb9jFaCITe0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"545-rLt+ZwEovi9Tv0xVrFLwFSIsKcg\"",
    "mtime": "2025-12-29T15:10:58.909Z",
    "size": 1349,
    "path": "../public/api/_content/query/l2jWlYFkuOa0yy_W5-ry1ceLHyPMiv3UJb9jFaCITe0.1767020924919.json"
  },
  "/api/_content/query/l4-MDrh8FdDfwXBPQJkpkGrGAjIAiRyvJak7Wpa1CUA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"ec5-GcvgFl1YHxAX8tTPDkqUmjGC9Wc\"",
    "mtime": "2025-12-29T15:10:57.333Z",
    "size": 3781,
    "path": "../public/api/_content/query/l4-MDrh8FdDfwXBPQJkpkGrGAjIAiRyvJak7Wpa1CUA.1767020924919.json"
  },
  "/api/_content/query/lExToPlXSLXa9I-zMCjFvYwHssO06pYnRP-ccDSmI90.1767020924919.json": {
    "type": "application/json",
    "etag": "\"12f2-aG8hyUcxesRiFwYOQkMRN9aKy+c\"",
    "mtime": "2025-12-29T15:10:51.849Z",
    "size": 4850,
    "path": "../public/api/_content/query/lExToPlXSLXa9I-zMCjFvYwHssO06pYnRP-ccDSmI90.1767020924919.json"
  },
  "/api/_content/query/lK8dzeW2FYchJq115Hj0H_oDXmvRfVZZYzSyALWarU0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:11:03.700Z",
    "size": 11,
    "path": "../public/api/_content/query/lK8dzeW2FYchJq115Hj0H_oDXmvRfVZZYzSyALWarU0.1767020924919.json"
  },
  "/api/_content/query/mOKSNL-x-24FHmH8WH4YLK5KpBswAIQ1cRWdzpYj-Gw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"c027-uEgSIyd/Tbp2eDFmMkE08y+trQc\"",
    "mtime": "2025-12-29T15:11:01.490Z",
    "size": 49191,
    "path": "../public/api/_content/query/mOKSNL-x-24FHmH8WH4YLK5KpBswAIQ1cRWdzpYj-Gw.1767020924919.json"
  },
  "/api/_content/query/mQqSBsdrwGZXcbPJp_zFaXYxB4oaphi1HRq8ltRk_Lk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"438-JASArq9BpzjmZKPbX8qdKgze+vA\"",
    "mtime": "2025-12-29T15:11:01.517Z",
    "size": 1080,
    "path": "../public/api/_content/query/mQqSBsdrwGZXcbPJp_zFaXYxB4oaphi1HRq8ltRk_Lk.1767020924919.json"
  },
  "/api/_content/query/mR_UNrz_VHlCOisT904gbIK8HqtTgK6iC8rbDWykOhM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"208-BNrDL1xelxK8TCOPDl6/0nKr9Q8\"",
    "mtime": "2025-12-29T15:11:03.700Z",
    "size": 520,
    "path": "../public/api/_content/query/mR_UNrz_VHlCOisT904gbIK8HqtTgK6iC8rbDWykOhM.1767020924919.json"
  },
  "/api/_content/query/mSkNaJfgYvShYWwT7TRHtepDekV-f9QSCDVNV0aCi3k.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:46.829Z",
    "size": 11,
    "path": "../public/api/_content/query/mSkNaJfgYvShYWwT7TRHtepDekV-f9QSCDVNV0aCi3k.1767020924919.json"
  },
  "/api/_content/query/mYaAnw-VtBYBJHAcNcVNDm-UZB-zvpNg4VTmIfAqx-g.1767020924919.json": {
    "type": "application/json",
    "etag": "\"419-OM1ekMR2TmBD/KzOZxJn/NqPIYA\"",
    "mtime": "2025-12-29T15:10:57.354Z",
    "size": 1049,
    "path": "../public/api/_content/query/mYaAnw-VtBYBJHAcNcVNDm-UZB-zvpNg4VTmIfAqx-g.1767020924919.json"
  },
  "/api/_content/query/n7padsnVLjgPLRq9VJUTTRxU-AMMQcfBZ1irAKnJwwQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"30f-uF6KEdQEcnkMa++A6u/NQDDNXf8\"",
    "mtime": "2025-12-29T15:10:49.139Z",
    "size": 783,
    "path": "../public/api/_content/query/n7padsnVLjgPLRq9VJUTTRxU-AMMQcfBZ1irAKnJwwQ.1767020924919.json"
  },
  "/api/_content/query/nlimdM2fOI986Mf49CjEB24kjHFrdePrgnL0SgO0d1o.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3f2-OR4uIqGYuNq62gEyYNBmT6hlzq0\"",
    "mtime": "2025-12-29T15:11:04.544Z",
    "size": 1010,
    "path": "../public/api/_content/query/nlimdM2fOI986Mf49CjEB24kjHFrdePrgnL0SgO0d1o.1767020924919.json"
  },
  "/api/_content/query/npXyK4uGqhRqFViVRP1oKTGw4vd8w3oJFjPE9BwEuR0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2c1-eSq3ewNMPWf6WkVob7Pqw5n25Uw\"",
    "mtime": "2025-12-29T15:10:52.882Z",
    "size": 705,
    "path": "../public/api/_content/query/npXyK4uGqhRqFViVRP1oKTGw4vd8w3oJFjPE9BwEuR0.1767020924919.json"
  },
  "/api/_content/query/oCXiBp1uoIpT7tLZ-6uuwAZEUXXyLwkq7iRrN8AjRQE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b8-WNXZ6KW4nzxdzuX2zZW1mZAIjd8\"",
    "mtime": "2025-12-29T15:11:03.076Z",
    "size": 184,
    "path": "../public/api/_content/query/oCXiBp1uoIpT7tLZ-6uuwAZEUXXyLwkq7iRrN8AjRQE.1767020924919.json"
  },
  "/api/_content/query/oOHrISxn-Ymx8UZK3YeoMbGEmgegY1qK2BLpqsRqsS8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3b7-+V2gxFZSqelIMgjTEVxwxV9yymk\"",
    "mtime": "2025-12-29T15:10:36.392Z",
    "size": 951,
    "path": "../public/api/_content/query/oOHrISxn-Ymx8UZK3YeoMbGEmgegY1qK2BLpqsRqsS8.1767020924919.json"
  },
  "/api/_content/query/oiPWG4A0paOA7NdUpUS0ze2E-x70P3OnBVe1zgTugX4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"21f0-+xgdPp1v1O2o5uZO+n8oCJtgVPs\"",
    "mtime": "2025-12-29T15:10:35.526Z",
    "size": 8688,
    "path": "../public/api/_content/query/oiPWG4A0paOA7NdUpUS0ze2E-x70P3OnBVe1zgTugX4.1767020924919.json"
  },
  "/api/_content/query/omad0o2hnUf-UM82osey9NUEphcANY0oSIA3aWNpslM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"45bf-wMGqnotm2njJWcf//QzEDCg0ns4\"",
    "mtime": "2025-12-29T15:10:33.972Z",
    "size": 17855,
    "path": "../public/api/_content/query/omad0o2hnUf-UM82osey9NUEphcANY0oSIA3aWNpslM.1767020924919.json"
  },
  "/api/_content/query/pkoftkngG_EEMrqF7uCV6XW5Q6R6FxXxhkHMWcpbLLk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"371-A2XlcZ3Xds5iDgDYYXc21i/f8+A\"",
    "mtime": "2025-12-29T15:10:41.560Z",
    "size": 881,
    "path": "../public/api/_content/query/pkoftkngG_EEMrqF7uCV6XW5Q6R6FxXxhkHMWcpbLLk.1767020924919.json"
  },
  "/api/_content/query/plj4iIwtXw3R5VcUocT5BdiwP7qsSMX-VzckRTYnQ7w.1767020924919.json": {
    "type": "application/json",
    "etag": "\"591-i03v/wDbme8pSxIGOvFcy2V3usg\"",
    "mtime": "2025-12-29T15:10:56.972Z",
    "size": 1425,
    "path": "../public/api/_content/query/plj4iIwtXw3R5VcUocT5BdiwP7qsSMX-VzckRTYnQ7w.1767020924919.json"
  },
  "/api/_content/query/qL-Yrk1273CUvH1oEj3WqbFoJZQ_VrUodWRN9VWOK6w.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1d0-NAQjTX/XUNx/PX2KvSXykrhOWTc\"",
    "mtime": "2025-12-29T15:10:32.278Z",
    "size": 464,
    "path": "../public/api/_content/query/qL-Yrk1273CUvH1oEj3WqbFoJZQ_VrUodWRN9VWOK6w.1767020924919.json"
  },
  "/api/_content/query/qh9pO7F1mBBht_L2MxAoMnUiait0XirSvPIs1vYRIo0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"e88-2pX/kF8H3wl/cHV+K7NonMhUaRM\"",
    "mtime": "2025-12-29T15:10:51.392Z",
    "size": 3720,
    "path": "../public/api/_content/query/qh9pO7F1mBBht_L2MxAoMnUiait0XirSvPIs1vYRIo0.1767020924919.json"
  },
  "/api/_content/query/qi1v0nrY8uMgk9FKAAvrg91lxt5hX52KIyWHOcOgCrw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:39.845Z",
    "size": 11,
    "path": "../public/api/_content/query/qi1v0nrY8uMgk9FKAAvrg91lxt5hX52KIyWHOcOgCrw.1767020924919.json"
  },
  "/api/_content/query/r47nrSjoH6rS45wiRr_tfeH5gz97aR8VBUJuIbNQlHQ.1767020924919.json": {
    "type": "application/json",
    "etag": "\"372-fOpVTwSSsmIMtzxHDWoBNHigtTI\"",
    "mtime": "2025-12-29T15:10:37.929Z",
    "size": 882,
    "path": "../public/api/_content/query/r47nrSjoH6rS45wiRr_tfeH5gz97aR8VBUJuIbNQlHQ.1767020924919.json"
  },
  "/api/_content/query/rX80UGm-s30IJMVCRbvBK8UOaGQwlZuVhS0Mx96gGXY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2c8-RMLofanmcXK7MMCn4Tbp7Xp424Y\"",
    "mtime": "2025-12-29T15:10:53.558Z",
    "size": 712,
    "path": "../public/api/_content/query/rX80UGm-s30IJMVCRbvBK8UOaGQwlZuVhS0Mx96gGXY.1767020924919.json"
  },
  "/api/_content/query/rgXq08FOFA_IDP_x30mFwmGsBuXpqkpyuBdzboL-jGM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"5ab-0QxkFGYC0RH3zU8w25FO7c9pibQ\"",
    "mtime": "2025-12-29T15:11:04.982Z",
    "size": 1451,
    "path": "../public/api/_content/query/rgXq08FOFA_IDP_x30mFwmGsBuXpqkpyuBdzboL-jGM.1767020924919.json"
  },
  "/api/_content/query/s1DDjS4YCJdIMDuqEsA-OgmnZocCHzY66z-RqpttTSM.1767020924919.json": {
    "type": "application/json",
    "etag": "\"518-qYZMIL8/+2ayVx1dHVg+2U7aTHM\"",
    "mtime": "2025-12-29T15:10:42.628Z",
    "size": 1304,
    "path": "../public/api/_content/query/s1DDjS4YCJdIMDuqEsA-OgmnZocCHzY66z-RqpttTSM.1767020924919.json"
  },
  "/api/_content/query/s2iJ2GF3jvI8UEZsPm2KXflGB1wWLVBTF6m7cAk4LeA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"16cfc-DmxxE4f7fJm9dfBj5b37H3M9WzE\"",
    "mtime": "2025-12-29T15:10:33.686Z",
    "size": 93436,
    "path": "../public/api/_content/query/s2iJ2GF3jvI8UEZsPm2KXflGB1wWLVBTF6m7cAk4LeA.1767020924919.json"
  },
  "/api/_content/query/sHuDfF-3rLGC93Gv8L2QkH34kX0Rg02r-3S9Zj9P3UU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"332-aTgiERid8NBGFwQU3K30gLJ751g\"",
    "mtime": "2025-12-29T15:10:43.410Z",
    "size": 818,
    "path": "../public/api/_content/query/sHuDfF-3rLGC93Gv8L2QkH34kX0Rg02r-3S9Zj9P3UU.1767020924919.json"
  },
  "/api/_content/query/sVhZrB43uXNeibCrZSC4oL7JJI5dC7xgRINVsiw2NIA.1767020924919.json": {
    "type": "application/json",
    "etag": "\"283-dsiRFx3cg8WBrO5LzXt+MHYXSbc\"",
    "mtime": "2025-12-29T15:10:51.113Z",
    "size": 643,
    "path": "../public/api/_content/query/sVhZrB43uXNeibCrZSC4oL7JJI5dC7xgRINVsiw2NIA.1767020924919.json"
  },
  "/api/_content/query/sZo0nPBRoZl_J_JpiexueB6G5pZxYXIiXV0sQAQ5Ttw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"ee03-zU4OLODCBrzXsFDiuvraelOIB7Q\"",
    "mtime": "2025-12-29T15:10:58.923Z",
    "size": 60931,
    "path": "../public/api/_content/query/sZo0nPBRoZl_J_JpiexueB6G5pZxYXIiXV0sQAQ5Ttw.1767020924919.json"
  },
  "/api/_content/query/seN4XRRsACTzbUMVKFm_3iSSe8_OmzDxTTMObvwuWdc.1767020924919.json": {
    "type": "application/json",
    "etag": "\"a83d-yeC6a9agNLi7uNjJINzUGqvu4f0\"",
    "mtime": "2025-12-29T15:10:40.072Z",
    "size": 43069,
    "path": "../public/api/_content/query/seN4XRRsACTzbUMVKFm_3iSSe8_OmzDxTTMObvwuWdc.1767020924919.json"
  },
  "/api/_content/query/sqIRHRrzGF8Bgjna1U4aMSqDBk4X9uLi6c08ZGjc1-M.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3916-6l3/D/p8LaAvitFOsOCfJt5ao3U\"",
    "mtime": "2025-12-29T15:11:01.479Z",
    "size": 14614,
    "path": "../public/api/_content/query/sqIRHRrzGF8Bgjna1U4aMSqDBk4X9uLi6c08ZGjc1-M.1767020924919.json"
  },
  "/api/_content/query/sslFD2yWReY09Efs54MoNcc7tMQ_Uoo0pJeY5RTPSXw.1767020924919.json": {
    "type": "application/json",
    "etag": "\"115e-lAtDgdr6IJTlrTXNNaU+6EnboNA\"",
    "mtime": "2025-12-29T15:11:03.514Z",
    "size": 4446,
    "path": "../public/api/_content/query/sslFD2yWReY09Efs54MoNcc7tMQ_Uoo0pJeY5RTPSXw.1767020924919.json"
  },
  "/api/_content/query/t-7x_dF7VKbb5zSFdgmCPc_0yesL26sHcaFZheYOCYE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"4b4-cwj4aAEn0RI+eMjKkSJZOPXlvzY\"",
    "mtime": "2025-12-29T15:10:34.659Z",
    "size": 1204,
    "path": "../public/api/_content/query/t-7x_dF7VKbb5zSFdgmCPc_0yesL26sHcaFZheYOCYE.1767020924919.json"
  },
  "/api/_content/query/tNzn8M9WQFe1TZKQJKfmxZ3FqZD0DRV4LEaZyAScHVY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"8478-ynBYlabesW0iMy2HUyXnC7Vh4j4\"",
    "mtime": "2025-12-29T15:10:30.754Z",
    "size": 33912,
    "path": "../public/api/_content/query/tNzn8M9WQFe1TZKQJKfmxZ3FqZD0DRV4LEaZyAScHVY.1767020924919.json"
  },
  "/api/_content/query/t_NxFYFcjGyodeHNcYEFKVGhyO-DqlL-yuTUpFFEFFk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"19e-+ydNeYKC71y2FJlc188C2oOa0qo\"",
    "mtime": "2025-12-29T15:10:28.424Z",
    "size": 414,
    "path": "../public/api/_content/query/t_NxFYFcjGyodeHNcYEFKVGhyO-DqlL-yuTUpFFEFFk.1767020924919.json"
  },
  "/api/_content/query/te_ic1Eb_NcX4gDxQ2ZbIdqytJVhMkwWbz1oTd7jzq4.1767020924919.json": {
    "type": "application/json",
    "etag": "\"464-kK3k5NyHaTnpjZyH0UWxjrjVXX8\"",
    "mtime": "2025-12-29T15:11:02.576Z",
    "size": 1124,
    "path": "../public/api/_content/query/te_ic1Eb_NcX4gDxQ2ZbIdqytJVhMkwWbz1oTd7jzq4.1767020924919.json"
  },
  "/api/_content/query/tgT9mvHLUqQidnOnBPy3lK1R2VZXj3l9tVX-qWoKet8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:27.482Z",
    "size": 11,
    "path": "../public/api/_content/query/tgT9mvHLUqQidnOnBPy3lK1R2VZXj3l9tVX-qWoKet8.1767020924919.json"
  },
  "/api/_content/query/tuYJIzBI57ELyDxCtNqaTis1wlB2qNhrhp-liMFMw0M.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1420-bTaZXIATvfFpV7t/zv1cO6wgzyQ\"",
    "mtime": "2025-12-29T15:10:36.629Z",
    "size": 5152,
    "path": "../public/api/_content/query/tuYJIzBI57ELyDxCtNqaTis1wlB2qNhrhp-liMFMw0M.1767020924919.json"
  },
  "/api/_content/query/u0FxGZO9X415TJZum21RFO-A6MH3N67_RqFQCqqjlF0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"ea1-ifHoYbZe0cX0HqexuaB4G94zqac\"",
    "mtime": "2025-12-29T15:10:53.739Z",
    "size": 3745,
    "path": "../public/api/_content/query/u0FxGZO9X415TJZum21RFO-A6MH3N67_RqFQCqqjlF0.1767020924919.json"
  },
  "/api/_content/query/uD7bzAlNk2demLg7r5CGhk2b_oOdq_afRbUeSJCTW1M.1767020924919.json": {
    "type": "application/json",
    "etag": "\"567-M3algq7vuw30qtfMLyWAyneZTeQ\"",
    "mtime": "2025-12-29T15:10:31.850Z",
    "size": 1383,
    "path": "../public/api/_content/query/uD7bzAlNk2demLg7r5CGhk2b_oOdq_afRbUeSJCTW1M.1767020924919.json"
  },
  "/api/_content/query/uDv7Kt_b8JP9cYCs3m8wlz3hBQRhJw-7A_JpC7lvuQk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1f35-1iToxfdt+ESrtL1TCjSM+mAqzBw\"",
    "mtime": "2025-12-29T15:10:30.097Z",
    "size": 7989,
    "path": "../public/api/_content/query/uDv7Kt_b8JP9cYCs3m8wlz3hBQRhJw-7A_JpC7lvuQk.1767020924919.json"
  },
  "/api/_content/query/uIs_BSvnrCc-G1XJF8VfrsqYa74WBeQW6JO0NbwjG68.1767020924919.json": {
    "type": "application/json",
    "etag": "\"38ff-Fth7+LTvXL0nhEUTjrpzMhqQ6QY\"",
    "mtime": "2025-12-29T15:10:27.336Z",
    "size": 14591,
    "path": "../public/api/_content/query/uIs_BSvnrCc-G1XJF8VfrsqYa74WBeQW6JO0NbwjG68.1767020924919.json"
  },
  "/api/_content/query/uWsKPbz0NAZgcsHhQaudj9uFXgWU1m-xlokEzsoVmfg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"382-/cP8SyABShJTffFWOsM+zqcrmSY\"",
    "mtime": "2025-12-29T15:10:41.717Z",
    "size": 898,
    "path": "../public/api/_content/query/uWsKPbz0NAZgcsHhQaudj9uFXgWU1m-xlokEzsoVmfg.1767020924919.json"
  },
  "/api/_content/query/vTq32oj9elvvzO_InzFA8SOH9MkCVUq1AZCTr1sC7UE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"dc-dFxCuD2L8ZF9jQ1DWM2rq0WCi6w\"",
    "mtime": "2025-12-29T15:11:01.455Z",
    "size": 220,
    "path": "../public/api/_content/query/vTq32oj9elvvzO_InzFA8SOH9MkCVUq1AZCTr1sC7UE.1767020924919.json"
  },
  "/api/_content/query/vqJbDXfMnyOeakwkE_fuoPBhNEPjG_tVHzeWLc2MyG0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1174-MJFspPmPem/SN3kM80Sk3BJiusY\"",
    "mtime": "2025-12-29T15:10:47.376Z",
    "size": 4468,
    "path": "../public/api/_content/query/vqJbDXfMnyOeakwkE_fuoPBhNEPjG_tVHzeWLc2MyG0.1767020924919.json"
  },
  "/api/_content/query/w36hi28uQ9-rsQAfyRJAlffMxe6t_MgadeNRRwTcKIE.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2b2-bhwCs2vN5Lc5zkV4WrtbiWi0BAY\"",
    "mtime": "2025-12-29T15:10:56.972Z",
    "size": 690,
    "path": "../public/api/_content/query/w36hi28uQ9-rsQAfyRJAlffMxe6t_MgadeNRRwTcKIE.1767020924919.json"
  },
  "/api/_content/query/wK80IvyDXzmB75XeNhJBQyASk6KlqTCsxr0dF8fqvBs.1767020924919.json": {
    "type": "application/json",
    "etag": "\"5a0-UM/ysaiTMCeuR+eHWKbgdsVM9Hc\"",
    "mtime": "2025-12-29T15:11:05.336Z",
    "size": 1440,
    "path": "../public/api/_content/query/wK80IvyDXzmB75XeNhJBQyASk6KlqTCsxr0dF8fqvBs.1767020924919.json"
  },
  "/api/_content/query/wPQtKnU1NwEcheX_H13Ws-VCi0c4NYBULXfVABHVj_I.1767020924919.json": {
    "type": "application/json",
    "etag": "\"3ed5-9gjmKsXAjMNVq0M2fp9qtlS8JDU\"",
    "mtime": "2025-12-29T15:10:54.150Z",
    "size": 16085,
    "path": "../public/api/_content/query/wPQtKnU1NwEcheX_H13Ws-VCi0c4NYBULXfVABHVj_I.1767020924919.json"
  },
  "/api/_content/query/weo4WgKt9ZJ2FUuvO98665LFhbSISP7GQ1-rhZl0b6k.1767020924919.json": {
    "type": "application/json",
    "etag": "\"1598-QXNXbJkmmf6gotFi8S7Fbdt0he8\"",
    "mtime": "2025-12-29T15:11:05.265Z",
    "size": 5528,
    "path": "../public/api/_content/query/weo4WgKt9ZJ2FUuvO98665LFhbSISP7GQ1-rhZl0b6k.1767020924919.json"
  },
  "/api/_content/query/wuUYFjP3jX74HKUzJIpU9wGCIvs2ogBcGYA7_ABbODk.1767020924919.json": {
    "type": "application/json",
    "etag": "\"38f-Ia9ogdaQ79gb5X+Ax73M9Lhxcrs\"",
    "mtime": "2025-12-29T15:10:40.013Z",
    "size": 911,
    "path": "../public/api/_content/query/wuUYFjP3jX74HKUzJIpU9wGCIvs2ogBcGYA7_ABbODk.1767020924919.json"
  },
  "/api/_content/query/xHUCe0mignZ6dMltw8_CSAkvt0m_Dq3Ce7bpUvsfVd0.1767020924919.json": {
    "type": "application/json",
    "etag": "\"460-JisW0bb2/oNHofCfCoMC8MeWV8Y\"",
    "mtime": "2025-12-29T15:11:04.544Z",
    "size": 1120,
    "path": "../public/api/_content/query/xHUCe0mignZ6dMltw8_CSAkvt0m_Dq3Ce7bpUvsfVd0.1767020924919.json"
  },
  "/api/_content/query/xWtAVQ-SvpLBqR835UlLlP1wxwP6DbNPnDjZIGNnifU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"ece1-nIPpeWts1n/f0UImtWDXx77PF3w\"",
    "mtime": "2025-12-29T15:10:42.013Z",
    "size": 60641,
    "path": "../public/api/_content/query/xWtAVQ-SvpLBqR835UlLlP1wxwP6DbNPnDjZIGNnifU.1767020924919.json"
  },
  "/api/_content/query/xZ3dXMpqYW2WO_EkfcpgbFIm2M-lu5FitoBUWPA0QK8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"53c-cg/ICK0LHpl57Oavz9GwoLjUFok\"",
    "mtime": "2025-12-29T15:10:44.128Z",
    "size": 1340,
    "path": "../public/api/_content/query/xZ3dXMpqYW2WO_EkfcpgbFIm2M-lu5FitoBUWPA0QK8.1767020924919.json"
  },
  "/api/_content/query/y8w7EF3eYPsY2TBNKyi-Lfe9hLY3LEWyXt8eLJsQ9W8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"35e-rN0cw1nNenc0iECq6fyMul/ha4o\"",
    "mtime": "2025-12-29T15:10:40.398Z",
    "size": 862,
    "path": "../public/api/_content/query/y8w7EF3eYPsY2TBNKyi-Lfe9hLY3LEWyXt8eLJsQ9W8.1767020924919.json"
  },
  "/api/_content/query/yHZu8BXq3BeZ_WSGs4NRGq1ygQANIseRAkjf_STaH64.1767020924919.json": {
    "type": "application/json",
    "etag": "\"f0b-q7kku9HXnsn3hziqNWF3russpko\"",
    "mtime": "2025-12-29T15:10:51.573Z",
    "size": 3851,
    "path": "../public/api/_content/query/yHZu8BXq3BeZ_WSGs4NRGq1ygQANIseRAkjf_STaH64.1767020924919.json"
  },
  "/api/_content/query/yZ9kubUpfmQJsIb19WBaQrZd7TIoibVH15NhsPKCWbg.1767020924919.json": {
    "type": "application/json",
    "etag": "\"2dd-QlC9OvroTzc7v6qKJvJ3G8a7QCY\"",
    "mtime": "2025-12-29T15:11:05.279Z",
    "size": 733,
    "path": "../public/api/_content/query/yZ9kubUpfmQJsIb19WBaQrZd7TIoibVH15NhsPKCWbg.1767020924919.json"
  },
  "/api/_content/query/yb5W03_c3VlMpAlYGyQuQMiayZY4KIg3ZupZnUamYso.1767020924919.json": {
    "type": "application/json",
    "etag": "\"57f-rzBocv1B70Caaj4iGMgKWJE5i8c\"",
    "mtime": "2025-12-29T15:10:27.285Z",
    "size": 1407,
    "path": "../public/api/_content/query/yb5W03_c3VlMpAlYGyQuQMiayZY4KIg3ZupZnUamYso.1767020924919.json"
  },
  "/api/_content/query/yxagnrmWiwEAkpSqVsxG2slk7otJaw18QjoHDdlGxYU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"199-qp2xlyQDAQ9izvYWshFzGcR7JuE\"",
    "mtime": "2025-12-29T15:10:41.984Z",
    "size": 409,
    "path": "../public/api/_content/query/yxagnrmWiwEAkpSqVsxG2slk7otJaw18QjoHDdlGxYU.1767020924919.json"
  },
  "/api/_content/query/zH44_0hezJSszTgOfeT5COpM2keKuwtJcDwVCLnuIZU.1767020924919.json": {
    "type": "application/json",
    "etag": "\"8fc-9Zpas1wNHXLXqJI3WwWXkxMkV4A\"",
    "mtime": "2025-12-29T15:10:41.777Z",
    "size": 2300,
    "path": "../public/api/_content/query/zH44_0hezJSszTgOfeT5COpM2keKuwtJcDwVCLnuIZU.1767020924919.json"
  },
  "/api/_content/query/zPmPsVyTWPmOA8IZ9Hge-FgHn9ZAIAuEMbFLEKI1hSY.1767020924919.json": {
    "type": "application/json",
    "etag": "\"f25-D/j7/9HKeGajCUaRyGNXtXI/Nkg\"",
    "mtime": "2025-12-29T15:10:52.254Z",
    "size": 3877,
    "path": "../public/api/_content/query/zPmPsVyTWPmOA8IZ9Hge-FgHn9ZAIAuEMbFLEKI1hSY.1767020924919.json"
  },
  "/api/_content/query/zSTKNEHu0svPXI0ec9pw0S2g5zfOIbio-kv2Kphp08k.1767020924919.json": {
    "type": "application/json",
    "etag": "\"b-aFZ/7ev2lVwlEsAuIobymYVHec8\"",
    "mtime": "2025-12-29T15:10:45.224Z",
    "size": 11,
    "path": "../public/api/_content/query/zSTKNEHu0svPXI0ec9pw0S2g5zfOIbio-kv2Kphp08k.1767020924919.json"
  },
  "/api/_content/query/zbGKqX_hroRIH1huoCzJhxguSLgchlyy92oIhRJFOJ8.1767020924919.json": {
    "type": "application/json",
    "etag": "\"373-2C3a5hDzTbuUuqnDDnTaApqoHhs\"",
    "mtime": "2025-12-29T15:10:49.812Z",
    "size": 883,
    "path": "../public/api/_content/query/zbGKqX_hroRIH1huoCzJhxguSLgchlyy92oIhRJFOJ8.1767020924919.json"
  },
  "/uni-network/advanced/handling-errors/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-cC081vpmqxZYtQXvIc0PkfmbXjM\"",
    "mtime": "2025-12-29T15:10:37.447Z",
    "size": 486,
    "path": "../public/uni-network/advanced/handling-errors/_payload.json"
  },
  "/uni-network/advanced/handling-errors/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2529f-YdZnQI3Qh9t3Holbc5N/RE6o3B4\"",
    "mtime": "2025-12-29T15:10:13.651Z",
    "size": 152223,
    "path": "../public/uni-network/advanced/handling-errors/index.html"
  },
  "/uni-network/advanced/interceptors/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-cC081vpmqxZYtQXvIc0PkfmbXjM\"",
    "mtime": "2025-12-29T15:10:36.839Z",
    "size": 486,
    "path": "../public/uni-network/advanced/interceptors/_payload.json"
  },
  "/uni-network/advanced/interceptors/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2c957-nfj1z9Gg/sKcypkyEmU6i4Lnn54\"",
    "mtime": "2025-12-29T15:10:13.237Z",
    "size": 182615,
    "path": "../public/uni-network/advanced/interceptors/index.html"
  },
  "/uni-network/advanced/typescript-support/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-vELhfC1f+E8dCHJj9XutW2EwZpk\"",
    "mtime": "2025-12-29T15:10:37.918Z",
    "size": 486,
    "path": "../public/uni-network/advanced/typescript-support/_payload.json"
  },
  "/uni-network/advanced/typescript-support/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2aaa9-iRFgdojlfUInoQ9pFMSOxZuBtHU\"",
    "mtime": "2025-12-29T15:10:13.919Z",
    "size": 174761,
    "path": "../public/uni-network/advanced/typescript-support/index.html"
  },
  "/uni-network/api/config-defaults/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-0pqFbdfq0fj2uDg1AfzgNH3683E\"",
    "mtime": "2025-12-29T15:10:38.384Z",
    "size": 486,
    "path": "../public/uni-network/api/config-defaults/_payload.json"
  },
  "/uni-network/api/config-defaults/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1f098-//OpeVBfstaqBw9cjpEc20bgePI\"",
    "mtime": "2025-12-29T15:10:14.050Z",
    "size": 127128,
    "path": "../public/uni-network/api/config-defaults/index.html"
  },
  "/uni-network/api/instance/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-0pqFbdfq0fj2uDg1AfzgNH3683E\"",
    "mtime": "2025-12-29T15:10:37.927Z",
    "size": 486,
    "path": "../public/uni-network/api/instance/_payload.json"
  },
  "/uni-network/api/instance/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1e40b-jOOKLjpgUgreFBEHaiNNSJliDJ4\"",
    "mtime": "2025-12-29T15:10:14.023Z",
    "size": 123915,
    "path": "../public/uni-network/api/instance/index.html"
  },
  "/uni-network/api/introduction/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-H122PvAFrqdXIX1N+ifRN7zRwTI\"",
    "mtime": "2025-12-29T15:10:37.947Z",
    "size": 486,
    "path": "../public/uni-network/api/introduction/_payload.json"
  },
  "/uni-network/api/introduction/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1e99c-oPhFh/mdW3NAvbpdqEVso5wFql0\"",
    "mtime": "2025-12-29T15:10:14.039Z",
    "size": 125340,
    "path": "../public/uni-network/api/introduction/index.html"
  },
  "/uni-network/api/request-config/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-Se2sMxJiInk+qa7qvg/qoCp7R04\"",
    "mtime": "2025-12-29T15:10:38.771Z",
    "size": 486,
    "path": "../public/uni-network/api/request-config/_payload.json"
  },
  "/uni-network/api/request-config/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"34395-fpwNmcBqxXnzEdALW6X1aXSlCa0\"",
    "mtime": "2025-12-29T15:10:14.075Z",
    "size": 213909,
    "path": "../public/uni-network/api/request-config/index.html"
  },
  "/uni-network/api/response-schema/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-SbzRK7s/LeWMfwQWkU0aHbccBZI\"",
    "mtime": "2025-12-29T15:10:39.845Z",
    "size": 486,
    "path": "../public/uni-network/api/response-schema/_payload.json"
  },
  "/uni-network/api/response-schema/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"22ee3-AII+LbqioemKTanUAogIOyB3ius\"",
    "mtime": "2025-12-29T15:10:14.185Z",
    "size": 143075,
    "path": "../public/uni-network/api/response-schema/index.html"
  },
  "/uni-network/guide/example/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-ByaTlSZxFczjH5gPa1+uIMlbXPk\"",
    "mtime": "2025-12-29T15:10:40.072Z",
    "size": 486,
    "path": "../public/uni-network/guide/example/_payload.json"
  },
  "/uni-network/guide/example/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"289c1-2ecMN5f0ta2dmlj4XRywHvxj4b0\"",
    "mtime": "2025-12-29T15:10:14.641Z",
    "size": 166337,
    "path": "../public/uni-network/guide/example/index.html"
  },
  "/uni-network/guide/installation/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"107d-matiE0LMOL8UETD99txG2pearwA\"",
    "mtime": "2025-12-29T15:10:41.537Z",
    "size": 4221,
    "path": "../public/uni-network/guide/installation/_payload.json"
  },
  "/uni-network/guide/installation/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1e0b2-cyfd4mJMsa5diiRCi5MghmfmC4w\"",
    "mtime": "2025-12-29T15:10:15.192Z",
    "size": 123058,
    "path": "../public/uni-network/guide/installation/index.html"
  },
  "/uni-network/guide/introduction/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-CgEnh55zBfJHPgDxQOc6TLoY4bY\"",
    "mtime": "2025-12-29T15:10:40.442Z",
    "size": 486,
    "path": "../public/uni-network/guide/introduction/_payload.json"
  },
  "/uni-network/guide/introduction/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"198bc-gGw1APCPauNIOjEctss60VyjVSg\"",
    "mtime": "2025-12-29T15:10:15.102Z",
    "size": 104636,
    "path": "../public/uni-network/guide/introduction/index.html"
  },
  "/uni-network/other/build/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-ZKsvCPKzhSvV6cCQCuwaDoUgT6c\"",
    "mtime": "2025-12-29T15:10:41.560Z",
    "size": 486,
    "path": "../public/uni-network/other/build/_payload.json"
  },
  "/uni-network/other/build/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"193d8-DVHWSqDjb6CMCYpug/OC8xosIZA\"",
    "mtime": "2025-12-29T15:10:15.484Z",
    "size": 103384,
    "path": "../public/uni-network/other/build/index.html"
  },
  "/uni-network/other/comparison/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-ZKsvCPKzhSvV6cCQCuwaDoUgT6c\"",
    "mtime": "2025-12-29T15:10:41.223Z",
    "size": 486,
    "path": "../public/uni-network/other/comparison/_payload.json"
  },
  "/uni-network/other/comparison/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2615e-I8f5r5/mgy7o/kHarG2MgsulQpE\"",
    "mtime": "2025-12-29T15:10:15.191Z",
    "size": 155998,
    "path": "../public/uni-network/other/comparison/index.html"
  },
  "/uni-network/other/thank/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-PUDOyK7PZH/IikOZVG+UUUyFBOE\"",
    "mtime": "2025-12-29T15:10:41.733Z",
    "size": 486,
    "path": "../public/uni-network/other/thank/_payload.json"
  },
  "/uni-network/other/thank/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"19457-4tmmgHTF1F2hGJMgcMXo7qyAw+U\"",
    "mtime": "2025-12-29T15:10:15.562Z",
    "size": 103511,
    "path": "../public/uni-network/other/thank/index.html"
  },
  "/uni-typed/guide/getting-started/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-hdujHdLlkuqZATaWLG64gKlrBNI\"",
    "mtime": "2025-12-29T15:10:42.259Z",
    "size": 486,
    "path": "../public/uni-typed/guide/getting-started/_payload.json"
  },
  "/uni-typed/guide/getting-started/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"193d0-V3lgtWVZhHbc1fKvN11FvnY2/7A\"",
    "mtime": "2025-12-29T15:10:16.201Z",
    "size": 103376,
    "path": "../public/uni-typed/guide/getting-started/index.html"
  },
  "/uni-typed/guide/uni-app-components/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-hdujHdLlkuqZATaWLG64gKlrBNI\"",
    "mtime": "2025-12-29T15:10:42.628Z",
    "size": 486,
    "path": "../public/uni-typed/guide/uni-app-components/_payload.json"
  },
  "/uni-typed/guide/uni-app-components/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"15bc6-9fy1ZT4z3zJlPCxoZZ9p6RBqgqM\"",
    "mtime": "2025-12-29T15:10:16.201Z",
    "size": 89030,
    "path": "../public/uni-typed/guide/uni-app-components/index.html"
  },
  "/uni-typed/guide/uni-app-types/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1240-lmkZEqS2IrhysUJIE7NuBfmh4mg\"",
    "mtime": "2025-12-29T15:10:43.744Z",
    "size": 4672,
    "path": "../public/uni-typed/guide/uni-app-types/_payload.json"
  },
  "/uni-typed/guide/uni-app-types/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"321b3-X+vBgjO9HDXjbni3W/PnvH48WYw\"",
    "mtime": "2025-12-29T15:10:16.208Z",
    "size": 205235,
    "path": "../public/uni-typed/guide/uni-app-types/index.html"
  },
  "/uni-typed/guide/uni-cloud-components/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-0/P19N3hjiA4FM1XJvaCVsZhhPQ\"",
    "mtime": "2025-12-29T15:10:43.410Z",
    "size": 486,
    "path": "../public/uni-typed/guide/uni-cloud-components/_payload.json"
  },
  "/uni-typed/guide/uni-cloud-components/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"15b45-oeWPIRJvuvR9hdPoMu5C6UIUIas\"",
    "mtime": "2025-12-29T15:10:16.201Z",
    "size": 88901,
    "path": "../public/uni-typed/guide/uni-cloud-components/index.html"
  },
  "/uni-typed/guide/uni-cloud-types/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1249-1A9kwr+XVky9hOKLmYPWPMX4GA4\"",
    "mtime": "2025-12-29T15:10:43.722Z",
    "size": 4681,
    "path": "../public/uni-typed/guide/uni-cloud-types/_payload.json"
  },
  "/uni-typed/guide/uni-cloud-types/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2f166-EKH8/YRLG8Nv75tOE7p5zKav/R8\"",
    "mtime": "2025-12-29T15:10:16.201Z",
    "size": 192870,
    "path": "../public/uni-typed/guide/uni-cloud-types/index.html"
  },
  "/uni-typed/guide/uni-components/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-mzg6lbEklwmcPFilg/2OTWN4t6w\"",
    "mtime": "2025-12-29T15:10:43.475Z",
    "size": 486,
    "path": "../public/uni-typed/guide/uni-components/_payload.json"
  },
  "/uni-typed/guide/uni-components/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"15ab2-0QCRF/DAGaGjWbIdHor+uVACJSs\"",
    "mtime": "2025-12-29T15:10:16.201Z",
    "size": 88754,
    "path": "../public/uni-typed/guide/uni-components/index.html"
  },
  "/uni-typed/guide/uni-types/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"122c-pRRPfu8uolu9utIVwn1NBpItwPc\"",
    "mtime": "2025-12-29T15:10:44.139Z",
    "size": 4652,
    "path": "../public/uni-typed/guide/uni-types/_payload.json"
  },
  "/uni-typed/guide/uni-types/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"329bf-g6R4JXC5WMtIaXyAJNWvngHb5ok\"",
    "mtime": "2025-12-29T15:10:16.839Z",
    "size": 207295,
    "path": "../public/uni-typed/guide/uni-types/index.html"
  },
  "/uni-typed/guide/uni-ui-components/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-CKWCMgSdoetyVugHEd+k13m4Dgs\"",
    "mtime": "2025-12-29T15:10:44.565Z",
    "size": 486,
    "path": "../public/uni-typed/guide/uni-ui-components/_payload.json"
  },
  "/uni-typed/guide/uni-ui-components/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"15b13-ZQuKwxZTgUxJ6x2vuKynZX5ZGFw\"",
    "mtime": "2025-12-29T15:10:17.163Z",
    "size": 88851,
    "path": "../public/uni-typed/guide/uni-ui-components/index.html"
  },
  "/uni-typed/guide/uni-ui-types/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1439-QZNWgAzZB+X1n703BhZYlTWvSpY\"",
    "mtime": "2025-12-29T15:10:45.833Z",
    "size": 5177,
    "path": "../public/uni-typed/guide/uni-ui-types/_payload.json"
  },
  "/uni-typed/guide/uni-ui-types/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3041d-554MYXS00zdRM/IDbpemcIJoZY4\"",
    "mtime": "2025-12-29T15:10:17.320Z",
    "size": 197661,
    "path": "../public/uni-typed/guide/uni-ui-types/index.html"
  },
  "/uni-typed/guide/why/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-DmWkOp1FT7dnMsK/DI7Xjt8JpZE\"",
    "mtime": "2025-12-29T15:10:44.200Z",
    "size": 486,
    "path": "../public/uni-typed/guide/why/_payload.json"
  },
  "/uni-typed/guide/why/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"15b61-tpzocfwOs7fzOgQxCbLpHR4+iaA\"",
    "mtime": "2025-12-29T15:10:17.148Z",
    "size": 88929,
    "path": "../public/uni-typed/guide/why/index.html"
  },
  "/uni-typed/other/faq/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-yc4AEHd/+M1zaTDhMAquwSxxBhE\"",
    "mtime": "2025-12-29T15:10:45.808Z",
    "size": 486,
    "path": "../public/uni-typed/other/faq/_payload.json"
  },
  "/uni-typed/other/faq/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1d0dd-42d72mAPMJHXB5sXtaL95qL9D4Y\"",
    "mtime": "2025-12-29T15:10:17.315Z",
    "size": 119005,
    "path": "../public/uni-typed/other/faq/index.html"
  },
  "/uni-typed/other/migrate-v0-to-v1/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-cZZ/k8dNkJaQ/sQvgej5fEVS9Fo\"",
    "mtime": "2025-12-29T15:10:46.223Z",
    "size": 486,
    "path": "../public/uni-typed/other/migrate-v0-to-v1/_payload.json"
  },
  "/uni-typed/other/migrate-v0-to-v1/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"23c8c-DxwFtH/djgZ2/YcOgU4ydnS4IXw\"",
    "mtime": "2025-12-29T15:10:17.434Z",
    "size": 146572,
    "path": "../public/uni-typed/other/migrate-v0-to-v1/index.html"
  },
  "/uni-use/api/tryonbackpress/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-rwRKELvUIlAsf8CkhC6zX6pXHXc\"",
    "mtime": "2025-12-29T15:10:47.394Z",
    "size": 486,
    "path": "../public/uni-use/api/tryonbackpress/_payload.json"
  },
  "/uni-use/api/tryonbackpress/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1a15d-68PiX7a9aAJ/m4TQ8g9q4aFZm1A\"",
    "mtime": "2025-12-29T15:10:18.224Z",
    "size": 106845,
    "path": "../public/uni-use/api/tryonbackpress/index.html"
  },
  "/uni-use/api/tryonhide/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-rwRKELvUIlAsf8CkhC6zX6pXHXc\"",
    "mtime": "2025-12-29T15:10:46.913Z",
    "size": 486,
    "path": "../public/uni-use/api/tryonhide/_payload.json"
  },
  "/uni-use/api/tryonhide/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18728-4hdx2AwaLxxzfIPteOCvy1h/cXg\"",
    "mtime": "2025-12-29T15:10:18.218Z",
    "size": 100136,
    "path": "../public/uni-use/api/tryonhide/index.html"
  },
  "/uni-use/api/tryoninit/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-SgMkeMZ7Nan2ucPzBmm3dmlxiqk\"",
    "mtime": "2025-12-29T15:10:47.329Z",
    "size": 486,
    "path": "../public/uni-use/api/tryoninit/_payload.json"
  },
  "/uni-use/api/tryoninit/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18651-CudqaZ1bfr40xrtwpS23SPrQk5s\"",
    "mtime": "2025-12-29T15:10:18.224Z",
    "size": 99921,
    "path": "../public/uni-use/api/tryoninit/index.html"
  },
  "/uni-use/api/tryonload/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-SgMkeMZ7Nan2ucPzBmm3dmlxiqk\"",
    "mtime": "2025-12-29T15:10:47.583Z",
    "size": 486,
    "path": "../public/uni-use/api/tryonload/_payload.json"
  },
  "/uni-use/api/tryonload/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18658-ToLC1knprcMNuOkLxdNpw+nh7h0\"",
    "mtime": "2025-12-29T15:10:18.248Z",
    "size": 99928,
    "path": "../public/uni-use/api/tryonload/index.html"
  },
  "/uni-use/api/tryonready/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-SgMkeMZ7Nan2ucPzBmm3dmlxiqk\"",
    "mtime": "2025-12-29T15:10:47.630Z",
    "size": 486,
    "path": "../public/uni-use/api/tryonready/_payload.json"
  },
  "/uni-use/api/tryonready/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18707-Z0GyRKAkGiRa7VhuyVo8x1s4BWo\"",
    "mtime": "2025-12-29T15:10:18.295Z",
    "size": 100103,
    "path": "../public/uni-use/api/tryonready/index.html"
  },
  "/uni-use/api/tryonscopedispose/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-MeSOn3zNZ+TC6e8OdUbCWj+0/2Y\"",
    "mtime": "2025-12-29T15:10:47.682Z",
    "size": 486,
    "path": "../public/uni-use/api/tryonscopedispose/_payload.json"
  },
  "/uni-use/api/tryonscopedispose/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1896f-Zm5HntI2qMYvkTpFHfLXrQK5imA\"",
    "mtime": "2025-12-29T15:10:18.340Z",
    "size": 100719,
    "path": "../public/uni-use/api/tryonscopedispose/index.html"
  },
  "/uni-use/api/tryonshow/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-SnxGfJLD+Y5ntgiZLsZorOnCFRo\"",
    "mtime": "2025-12-29T15:10:47.881Z",
    "size": 486,
    "path": "../public/uni-use/api/tryonshow/_payload.json"
  },
  "/uni-use/api/tryonshow/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"186f7-ai7cugN/gIP2aMaxa5qxQ37i5Fc\"",
    "mtime": "2025-12-29T15:10:18.346Z",
    "size": 100087,
    "path": "../public/uni-use/api/tryonshow/index.html"
  },
  "/uni-use/api/tryonunload/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-ya0yyqxdcv0w4N1XSOBXTROKDaA\"",
    "mtime": "2025-12-29T15:10:48.102Z",
    "size": 486,
    "path": "../public/uni-use/api/tryonunload/_payload.json"
  },
  "/uni-use/api/tryonunload/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"186c8-/oblPMqR9jFf4mZQnxfjVUYUhM0\"",
    "mtime": "2025-12-29T15:10:19.033Z",
    "size": 100040,
    "path": "../public/uni-use/api/tryonunload/index.html"
  },
  "/uni-use/api/useactionsheet/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-hi7hmBMzNmwOBgzwHv8abCac8r4\"",
    "mtime": "2025-12-29T15:10:49.121Z",
    "size": 486,
    "path": "../public/uni-use/api/useactionsheet/_payload.json"
  },
  "/uni-use/api/useactionsheet/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"19830-Xlv/TIiSGrd37XTPboUfYV9CRM0\"",
    "mtime": "2025-12-29T15:10:19.347Z",
    "size": 104496,
    "path": "../public/uni-use/api/useactionsheet/index.html"
  },
  "/uni-use/api/useclipboarddata/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-eegfdLdupI8MkKqs9m9Sq1UU69s\"",
    "mtime": "2025-12-29T15:10:48.131Z",
    "size": 486,
    "path": "../public/uni-use/api/useclipboarddata/_payload.json"
  },
  "/uni-use/api/useclipboarddata/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1c4b6-iKOEcz5QBPMARs/1RN5ywkMrxUQ\"",
    "mtime": "2025-12-29T15:10:19.238Z",
    "size": 115894,
    "path": "../public/uni-use/api/useclipboarddata/index.html"
  },
  "/uni-use/api/usedownloadfile/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-aWHXVzg2HAe3tLmzr4qJJslF0mY\"",
    "mtime": "2025-12-29T15:10:49.199Z",
    "size": 486,
    "path": "../public/uni-use/api/usedownloadfile/_payload.json"
  },
  "/uni-use/api/usedownloadfile/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"16a0b-uyn792hujbGSagQQsXPLaoF0Nkw\"",
    "mtime": "2025-12-29T15:10:19.370Z",
    "size": 92683,
    "path": "../public/uni-use/api/usedownloadfile/index.html"
  },
  "/uni-use/api/useglobaldata/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-mXB/1YkFSxYMrc930dq4OmkIq/w\"",
    "mtime": "2025-12-29T15:10:49.812Z",
    "size": 486,
    "path": "../public/uni-use/api/useglobaldata/_payload.json"
  },
  "/uni-use/api/useglobaldata/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"196ca-SVp6I2ovkj14VDgSHGhsA46topU\"",
    "mtime": "2025-12-29T15:10:19.488Z",
    "size": 104138,
    "path": "../public/uni-use/api/useglobaldata/index.html"
  },
  "/uni-use/api/useinterceptor/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-mXB/1YkFSxYMrc930dq4OmkIq/w\"",
    "mtime": "2025-12-29T15:10:49.607Z",
    "size": 486,
    "path": "../public/uni-use/api/useinterceptor/_payload.json"
  },
  "/uni-use/api/useinterceptor/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1c163-d8wj667cKLkPYFB2yeOImqxWVIY\"",
    "mtime": "2025-12-29T15:10:19.463Z",
    "size": 115043,
    "path": "../public/uni-use/api/useinterceptor/index.html"
  },
  "/uni-use/api/useloading/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-a1+eGrBxDW8gVWJLElKFQy+Tl2A\"",
    "mtime": "2025-12-29T15:10:50.201Z",
    "size": 486,
    "path": "../public/uni-use/api/useloading/_payload.json"
  },
  "/uni-use/api/useloading/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1bf3d-SPML9kWWWjVhLC2KZzjlHqBM6UA\"",
    "mtime": "2025-12-29T15:10:19.608Z",
    "size": 114493,
    "path": "../public/uni-use/api/useloading/index.html"
  },
  "/uni-use/api/usemodal/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-FW72S25yZ8EZfEoFmG3ydVzlmRM\"",
    "mtime": "2025-12-29T15:10:50.232Z",
    "size": 486,
    "path": "../public/uni-use/api/usemodal/_payload.json"
  },
  "/uni-use/api/usemodal/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"196db-voYDgoWjyoOOngHYCc2/TzDvM24\"",
    "mtime": "2025-12-29T15:10:19.845Z",
    "size": 104155,
    "path": "../public/uni-use/api/usemodal/index.html"
  },
  "/uni-use/api/usenetwork/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-cRB6w87tZA5f81ZpgN896zxD8Rc\"",
    "mtime": "2025-12-29T15:10:50.283Z",
    "size": 486,
    "path": "../public/uni-use/api/usenetwork/_payload.json"
  },
  "/uni-use/api/usenetwork/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18f5a-EvXKVw7n0Aou26pi56UsVA3XTfs\"",
    "mtime": "2025-12-29T15:10:20.149Z",
    "size": 102234,
    "path": "../public/uni-use/api/usenetwork/index.html"
  },
  "/uni-use/api/useonline/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-ifMKRzHRH0acRmVQ0JRJDld/7aY\"",
    "mtime": "2025-12-29T15:10:51.127Z",
    "size": 486,
    "path": "../public/uni-use/api/useonline/_payload.json"
  },
  "/uni-use/api/useonline/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"181f6-wGgZaqFf/s2/oNbtsU3PQheiEbc\"",
    "mtime": "2025-12-29T15:10:20.186Z",
    "size": 98806,
    "path": "../public/uni-use/api/useonline/index.html"
  },
  "/uni-use/api/usepage/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-znA1U9A4yxk6E0oF3Mu2Dh5zJfQ\"",
    "mtime": "2025-12-29T15:10:51.368Z",
    "size": 486,
    "path": "../public/uni-use/api/usepage/_payload.json"
  },
  "/uni-use/api/usepage/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1806b-eRw7K/YgbReS57tVDfgy5THe2Dw\"",
    "mtime": "2025-12-29T15:10:20.401Z",
    "size": 98411,
    "path": "../public/uni-use/api/usepage/index.html"
  },
  "/uni-use/api/usepages/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-znA1U9A4yxk6E0oF3Mu2Dh5zJfQ\"",
    "mtime": "2025-12-29T15:10:51.806Z",
    "size": 486,
    "path": "../public/uni-use/api/usepages/_payload.json"
  },
  "/uni-use/api/usepages/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18092-6iU094z7vb1sMmB2cxt+16OPkJM\"",
    "mtime": "2025-12-29T15:10:20.406Z",
    "size": 98450,
    "path": "../public/uni-use/api/usepages/index.html"
  },
  "/uni-use/api/usepagescroll/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-abSOzSe7mrWNKOuVbEfrQqlwc1M\"",
    "mtime": "2025-12-29T15:10:51.820Z",
    "size": 486,
    "path": "../public/uni-use/api/usepagescroll/_payload.json"
  },
  "/uni-use/api/usepagescroll/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18684-hNqP2O7ko20cJiCgNbtcSv9GJ/A\"",
    "mtime": "2025-12-29T15:10:20.412Z",
    "size": 99972,
    "path": "../public/uni-use/api/usepagescroll/index.html"
  },
  "/uni-use/api/usepreferreddark/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-fqp7tomAF01vExONKjlYeOqbDFI\"",
    "mtime": "2025-12-29T15:10:51.400Z",
    "size": 486,
    "path": "../public/uni-use/api/usepreferreddark/_payload.json"
  },
  "/uni-use/api/usepreferreddark/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"181c2-nQXtXQ6w5uhbSTz4QnjgYFdkbHU\"",
    "mtime": "2025-12-29T15:10:20.401Z",
    "size": 98754,
    "path": "../public/uni-use/api/usepreferreddark/index.html"
  },
  "/uni-use/api/usepreferredlanguage/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-SgBkeMAcRmWK6H90knOcOYnDz8A\"",
    "mtime": "2025-12-29T15:10:52.254Z",
    "size": 486,
    "path": "../public/uni-use/api/usepreferredlanguage/_payload.json"
  },
  "/uni-use/api/usepreferredlanguage/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"181e1-InrQQs6BbkZ8ghZwoR9sMcUSH/g\"",
    "mtime": "2025-12-29T15:10:20.519Z",
    "size": 98785,
    "path": "../public/uni-use/api/usepreferredlanguage/index.html"
  },
  "/uni-use/api/useprevpage/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-99z7W/nV/Uk/CQJf9c4d3+SrYwg\"",
    "mtime": "2025-12-29T15:10:52.050Z",
    "size": 486,
    "path": "../public/uni-use/api/useprevpage/_payload.json"
  },
  "/uni-use/api/useprevpage/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18110-wv3+IUe4Jf/MPXPjp0rVOlAwkRQ\"",
    "mtime": "2025-12-29T15:10:20.518Z",
    "size": 98576,
    "path": "../public/uni-use/api/useprevpage/index.html"
  },
  "/uni-use/api/useprevroute/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-DnYOdHNa8IaNA7hruXmNr7HgS0Y\"",
    "mtime": "2025-12-29T15:10:53.092Z",
    "size": 486,
    "path": "../public/uni-use/api/useprevroute/_payload.json"
  },
  "/uni-use/api/useprevroute/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1816f-CeqF6FM19eMdfMw+gAk0uDiguYQ\"",
    "mtime": "2025-12-29T15:10:21.446Z",
    "size": 98671,
    "path": "../public/uni-use/api/useprevroute/index.html"
  },
  "/uni-use/api/useprovider/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-gwPmNIWl4UZrTs9LUaAEQ3PdgkY\"",
    "mtime": "2025-12-29T15:10:53.527Z",
    "size": 486,
    "path": "../public/uni-use/api/useprovider/_payload.json"
  },
  "/uni-use/api/useprovider/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"19730-brZngFVyKl014FRGTEgzFbXckOI\"",
    "mtime": "2025-12-29T15:10:21.670Z",
    "size": 104240,
    "path": "../public/uni-use/api/useprovider/index.html"
  },
  "/uni-use/api/usequery/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-8/vwOBXoZvA7MY4abskKzGvb1vo\"",
    "mtime": "2025-12-29T15:10:53.308Z",
    "size": 486,
    "path": "../public/uni-use/api/usequery/_payload.json"
  },
  "/uni-use/api/usequery/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"3e884-5OF/Ous5RC4lsNvCLYIByKR+AtQ\"",
    "mtime": "2025-12-29T15:10:21.662Z",
    "size": 256132,
    "path": "../public/uni-use/api/usequery/index.html"
  },
  "/uni-use/api/userequest/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-Kub5DXVrC7O5UuEvEnLOKjmrKwM\"",
    "mtime": "2025-12-29T15:10:53.972Z",
    "size": 486,
    "path": "../public/uni-use/api/userequest/_payload.json"
  },
  "/uni-use/api/userequest/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1689b-5aiKm81D7mLGlibWdT5kB/x8S1k\"",
    "mtime": "2025-12-29T15:10:21.775Z",
    "size": 92315,
    "path": "../public/uni-use/api/userequest/index.html"
  },
  "/uni-use/api/useroute/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-Kub5DXVrC7O5UuEvEnLOKjmrKwM\"",
    "mtime": "2025-12-29T15:10:53.740Z",
    "size": 486,
    "path": "../public/uni-use/api/useroute/_payload.json"
  },
  "/uni-use/api/useroute/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18147-rMmNvtKHiGUDxbcgTbiuEWCXM8E\"",
    "mtime": "2025-12-29T15:10:21.773Z",
    "size": 98631,
    "path": "../public/uni-use/api/useroute/index.html"
  },
  "/uni-use/api/userouter/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-0GLTc3+VNXzBjbznGxHXhhaxp7c\"",
    "mtime": "2025-12-29T15:10:53.981Z",
    "size": 486,
    "path": "../public/uni-use/api/userouter/_payload.json"
  },
  "/uni-use/api/userouter/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1c315-zjzZ5K1M5nO9ru5z8XHfKQHClXk\"",
    "mtime": "2025-12-29T15:10:22.328Z",
    "size": 115477,
    "path": "../public/uni-use/api/userouter/index.html"
  },
  "/uni-use/api/usescancode/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-a2AbXrtDK8A3HIJWrcBUvH5dgbI\"",
    "mtime": "2025-12-29T15:10:54.793Z",
    "size": 486,
    "path": "../public/uni-use/api/usescancode/_payload.json"
  },
  "/uni-use/api/usescancode/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"196e1-mdtvrCdwL/Yt7ULeDGi0fv7G0Xk\"",
    "mtime": "2025-12-29T15:10:22.339Z",
    "size": 104161,
    "path": "../public/uni-use/api/usescancode/index.html"
  },
  "/uni-use/api/usescreenbrightness/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-xThqdhsdkIHW0/8pHnWSaR6+uzI\"",
    "mtime": "2025-12-29T15:10:54.823Z",
    "size": 486,
    "path": "../public/uni-use/api/usescreenbrightness/_payload.json"
  },
  "/uni-use/api/usescreenbrightness/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1af37-YiNYazosgqJzzhX6UDmEpyOpk4s\"",
    "mtime": "2025-12-29T15:10:22.345Z",
    "size": 110391,
    "path": "../public/uni-use/api/usescreenbrightness/index.html"
  },
  "/uni-use/api/useselectorquery/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-EnXTyEwbP3NfM0iyqzXtjcnL7q4\"",
    "mtime": "2025-12-29T15:10:55.715Z",
    "size": 486,
    "path": "../public/uni-use/api/useselectorquery/_payload.json"
  },
  "/uni-use/api/useselectorquery/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1aa7e-1j+4A73Q6OLIXybLWxBLh9bjrH0\"",
    "mtime": "2025-12-29T15:10:22.645Z",
    "size": 109182,
    "path": "../public/uni-use/api/useselectorquery/index.html"
  },
  "/uni-use/api/usesocket/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-CigyI6KRZE+JnzJtp/U61nDMzxM\"",
    "mtime": "2025-12-29T15:10:55.276Z",
    "size": 486,
    "path": "../public/uni-use/api/usesocket/_payload.json"
  },
  "/uni-use/api/usesocket/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"169d4-QW6V8TjNj988V3A4jjOsTsspK1s\"",
    "mtime": "2025-12-29T15:10:22.533Z",
    "size": 92628,
    "path": "../public/uni-use/api/usesocket/index.html"
  },
  "/uni-use/api/usestorage/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-VNjkOu9Wa6P+DcCRRUe3inVwj20\"",
    "mtime": "2025-12-29T15:10:55.276Z",
    "size": 486,
    "path": "../public/uni-use/api/usestorage/_payload.json"
  },
  "/uni-use/api/usestorage/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1a1dd-bjUIM/Cz19FnmtO90ZjwR1f7uQc\"",
    "mtime": "2025-12-29T15:10:22.535Z",
    "size": 106973,
    "path": "../public/uni-use/api/usestorage/index.html"
  },
  "/uni-use/api/usestorageasync/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-/jyHcJVjSVJSmnIpCIy06TWdltM\"",
    "mtime": "2025-12-29T15:10:55.672Z",
    "size": 486,
    "path": "../public/uni-use/api/usestorageasync/_payload.json"
  },
  "/uni-use/api/usestorageasync/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1a270-f2JPF/Ke1zHRj0tixw9Dv0N4L+o\"",
    "mtime": "2025-12-29T15:10:22.639Z",
    "size": 107120,
    "path": "../public/uni-use/api/usestorageasync/index.html"
  },
  "/uni-use/api/usestoragesync/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-/jyHcJVjSVJSmnIpCIy06TWdltM\"",
    "mtime": "2025-12-29T15:10:55.906Z",
    "size": 486,
    "path": "../public/uni-use/api/usestoragesync/_payload.json"
  },
  "/uni-use/api/usestoragesync/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"19f3c-PBN1lEzCk2Te4Onl2t3THJ62zoc\"",
    "mtime": "2025-12-29T15:10:22.645Z",
    "size": 106300,
    "path": "../public/uni-use/api/usestoragesync/index.html"
  },
  "/uni-use/api/usetoast/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-NJ9OifiSaPIHVMJDwIEWeF35COs\"",
    "mtime": "2025-12-29T15:10:56.134Z",
    "size": 486,
    "path": "../public/uni-use/api/usetoast/_payload.json"
  },
  "/uni-use/api/usetoast/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"19c31-Rr3sEQLpeQGjpRp1qPk94Osz0+s\"",
    "mtime": "2025-12-29T15:10:22.822Z",
    "size": 105521,
    "path": "../public/uni-use/api/usetoast/index.html"
  },
  "/uni-use/api/useuploadfile/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-VLRidQ2SjxVk9CNh4lifO+dEDx0\"",
    "mtime": "2025-12-29T15:10:56.983Z",
    "size": 486,
    "path": "../public/uni-use/api/useuploadfile/_payload.json"
  },
  "/uni-use/api/useuploadfile/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"168de-eVuINOpN47lUtQKsqLoGX6+rLYM\"",
    "mtime": "2025-12-29T15:10:22.908Z",
    "size": 92382,
    "path": "../public/uni-use/api/useuploadfile/index.html"
  },
  "/uni-use/api/usevisible/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-VnNCci8QvN+dcCkjlKf6aDxfrqQ\"",
    "mtime": "2025-12-29T15:10:57.333Z",
    "size": 486,
    "path": "../public/uni-use/api/usevisible/_payload.json"
  },
  "/uni-use/api/usevisible/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"17e22-DBsdGO9fNv6ustcJZdTGICFja74\"",
    "mtime": "2025-12-29T15:10:22.932Z",
    "size": 97826,
    "path": "../public/uni-use/api/usevisible/index.html"
  },
  "/uni-use/guide/installation/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"122e-j0teo7TGbsgfWjIRE/Gh2fis6RQ\"",
    "mtime": "2025-12-29T15:10:57.944Z",
    "size": 4654,
    "path": "../public/uni-use/guide/installation/_payload.json"
  },
  "/uni-use/guide/installation/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"22a4e-+Ik25jZkZHERSD7DW0mScyKnVE4\"",
    "mtime": "2025-12-29T15:10:24.113Z",
    "size": 141902,
    "path": "../public/uni-use/guide/installation/index.html"
  },
  "/uni-use/guide/notice/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-t8s/wqz0AwJIe9io0KV0fYRJMvQ\"",
    "mtime": "2025-12-29T15:10:57.787Z",
    "size": 486,
    "path": "../public/uni-use/guide/notice/_payload.json"
  },
  "/uni-use/guide/notice/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2090d-6w7Fp+Jjnh9VO/JPhEB+kHQdaH4\"",
    "mtime": "2025-12-29T15:10:23.938Z",
    "size": 133389,
    "path": "../public/uni-use/guide/notice/index.html"
  },
  "/vitesse-uni-app/getting-started/data-fetching/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-KJFvdOwxyPLUvKn00JmTC7o7vUQ\"",
    "mtime": "2025-12-29T15:11:01.467Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/getting-started/data-fetching/_payload.json"
  },
  "/vitesse-uni-app/getting-started/data-fetching/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1cb6a-24suysLZQobKKXhHAeU7/teut7I\"",
    "mtime": "2025-12-29T15:10:26.015Z",
    "size": 117610,
    "path": "../public/vitesse-uni-app/getting-started/data-fetching/index.html"
  },
  "/vitesse-uni-app/getting-started/deployment/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-dyKvwUT6Qi9qbrb7O0dygYG30NQ\"",
    "mtime": "2025-12-29T15:11:01.517Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/getting-started/deployment/_payload.json"
  },
  "/vitesse-uni-app/getting-started/deployment/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"2cba9-+x6B3qoLAtZ4ClyQ3rVpKToyN1U\"",
    "mtime": "2025-12-29T15:10:26.144Z",
    "size": 183209,
    "path": "../public/vitesse-uni-app/getting-started/deployment/index.html"
  },
  "/vitesse-uni-app/getting-started/installation/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"291c-UTDX4KeiXh4Q6oUmteRKF0f58pM\"",
    "mtime": "2025-12-29T15:11:03.037Z",
    "size": 10524,
    "path": "../public/vitesse-uni-app/getting-started/installation/_payload.json"
  },
  "/vitesse-uni-app/getting-started/installation/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"28acd-SEkJ5Iuk4AeAGWde3YfuHQAv83U\"",
    "mtime": "2025-12-29T15:10:26.500Z",
    "size": 166605,
    "path": "../public/vitesse-uni-app/getting-started/installation/index.html"
  },
  "/vitesse-uni-app/getting-started/introduction/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-o6k5oRzJb2YomM/9suxUX/vIG2I\"",
    "mtime": "2025-12-29T15:11:02.557Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/getting-started/introduction/_payload.json"
  },
  "/vitesse-uni-app/getting-started/introduction/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"17b48-xc0BUP0xIypQmWIGHvcoGjpEa8c\"",
    "mtime": "2025-12-29T15:10:26.417Z",
    "size": 97096,
    "path": "../public/vitesse-uni-app/getting-started/introduction/index.html"
  },
  "/vitesse-uni-app/getting-started/state-management/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-oP2MzRGj0JJEX8O8uqUlyZkRKo4\"",
    "mtime": "2025-12-29T15:11:02.539Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/getting-started/state-management/_payload.json"
  },
  "/vitesse-uni-app/getting-started/state-management/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"30404-HNQ4xBHniBxpVYnKoeRlKnvQFT8\"",
    "mtime": "2025-12-29T15:10:26.395Z",
    "size": 197636,
    "path": "../public/vitesse-uni-app/getting-started/state-management/index.html"
  },
  "/vitesse-uni-app/getting-started/styling/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-P8ClGZiqIhT59U9iH41gDw9mGtw\"",
    "mtime": "2025-12-29T15:11:02.618Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/getting-started/styling/_payload.json"
  },
  "/vitesse-uni-app/getting-started/styling/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1b964-02ocorA0Qg51WdGD6H8D8tZ91PU\"",
    "mtime": "2025-12-29T15:10:26.456Z",
    "size": 112996,
    "path": "../public/vitesse-uni-app/getting-started/styling/index.html"
  },
  "/vitesse-uni-app/getting-started/views/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-P8ClGZiqIhT59U9iH41gDw9mGtw\"",
    "mtime": "2025-12-29T15:11:02.669Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/getting-started/views/_payload.json"
  },
  "/vitesse-uni-app/getting-started/views/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"27ab7-NbFclSi737zgVp+64fo4biWROjw\"",
    "mtime": "2025-12-29T15:10:26.470Z",
    "size": 162487,
    "path": "../public/vitesse-uni-app/getting-started/views/index.html"
  },
  "/vitesse-uni-app/guide/auto-imports/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-0cVCDWIZ5SCgK3ujLukQ8SCc+8k\"",
    "mtime": "2025-12-29T15:11:03.300Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/guide/auto-imports/_payload.json"
  },
  "/vitesse-uni-app/guide/auto-imports/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"1a58a-XR8xgHj5/8Mmsk6UTGxhaLA3egM\"",
    "mtime": "2025-12-29T15:10:27.073Z",
    "size": 107914,
    "path": "../public/vitesse-uni-app/guide/auto-imports/index.html"
  },
  "/vitesse-uni-app/guide/typescript/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-0cVCDWIZ5SCgK3ujLukQ8SCc+8k\"",
    "mtime": "2025-12-29T15:11:03.509Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/guide/typescript/_payload.json"
  },
  "/vitesse-uni-app/guide/typescript/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"18a21-bSvRwCTs+8HkdjGsexz586kbjt0\"",
    "mtime": "2025-12-29T15:10:27.083Z",
    "size": 100897,
    "path": "../public/vitesse-uni-app/guide/typescript/index.html"
  },
  "/vitesse-uni-app/guide/uniapp-development/_payload.json": {
    "type": "application/json;charset=utf-8",
    "etag": "\"1e6-+XuHDPuB2jCfhAURoWyW0C0t0Wg\"",
    "mtime": "2025-12-29T15:11:04.528Z",
    "size": 486,
    "path": "../public/vitesse-uni-app/guide/uniapp-development/_payload.json"
  },
  "/vitesse-uni-app/guide/uniapp-development/index.html": {
    "type": "text/html;charset=utf-8",
    "etag": "\"16489-1LSmWzWVwaEhOkjomh7cSZOqknI\"",
    "mtime": "2025-12-29T15:10:27.119Z",
    "size": 91273,
    "path": "../public/vitesse-uni-app/guide/uniapp-development/index.html"
  },
  "/__og-image__/static/blog/definepage/og.png": {
    "type": "image/png",
    "etag": "\"9132-ZVl8Dnpf90tlZ1LHq26X+1S7eAc\"",
    "mtime": "2025-12-29T15:10:32.738Z",
    "size": 37170,
    "path": "../public/__og-image__/static/blog/definepage/og.png"
  },
  "/__og-image__/static/blog/unh/og.png": {
    "type": "image/png",
    "etag": "\"186e6-50pdq91VQf8AMEtbsGB1KML59Ic\"",
    "mtime": "2025-12-29T15:10:31.840Z",
    "size": 100070,
    "path": "../public/__og-image__/static/blog/unh/og.png"
  },
  "/__og-image__/static/create-uni/core/og.png": {
    "type": "image/png",
    "etag": "\"99ea-pz5D+qHKpvZT/pXfMIlv5EVDmVU\"",
    "mtime": "2025-12-29T15:10:33.962Z",
    "size": 39402,
    "path": "../public/__og-image__/static/create-uni/core/og.png"
  },
  "/__og-image__/static/create-uni/gui/og.png": {
    "type": "image/png",
    "etag": "\"962d-ZsCDL27UxdNUBq56yaGm6Zg7PlI\"",
    "mtime": "2025-12-29T15:10:32.278Z",
    "size": 38445,
    "path": "../public/__og-image__/static/create-uni/gui/og.png"
  },
  "/__og-image__/static/create-uni/info/og.png": {
    "type": "image/png",
    "etag": "\"8854-4BGHYM67eIfobnScfjuWLMvo5Ow\"",
    "mtime": "2025-12-29T15:10:32.648Z",
    "size": 34900,
    "path": "../public/__og-image__/static/create-uni/info/og.png"
  },
  "/__og-image__/static/create-uni/mcp/og.png": {
    "type": "image/png",
    "etag": "\"ccd8-8JoRgG+WvbX4TH18mUra+xRtzLQ\"",
    "mtime": "2025-12-29T15:10:31.703Z",
    "size": 52440,
    "path": "../public/__og-image__/static/create-uni/mcp/og.png"
  },
  "/__og-image__/static/hbuilderx-vanilla/api/og.png": {
    "type": "image/png",
    "etag": "\"9242-GK7Ht0lkl+LXizzn0Pg/zj9TCTA\"",
    "mtime": "2025-12-29T15:10:33.985Z",
    "size": 37442,
    "path": "../public/__og-image__/static/hbuilderx-vanilla/api/og.png"
  },
  "/__og-image__/static/hbuilderx-vanilla/build/og.png": {
    "type": "image/png",
    "etag": "\"9eaa-EPZmEKblDSzeDbTCAgorU4WglzQ\"",
    "mtime": "2025-12-29T15:10:33.984Z",
    "size": 40618,
    "path": "../public/__og-image__/static/hbuilderx-vanilla/build/og.png"
  },
  "/__og-image__/static/hbuilderx-vanilla/introduction/og.png": {
    "type": "image/png",
    "etag": "\"a4ab-csJno9y+gLDJZlkqeItZ55JQ1xI\"",
    "mtime": "2025-12-29T15:10:34.205Z",
    "size": 42155,
    "path": "../public/__og-image__/static/hbuilderx-vanilla/introduction/og.png"
  },
  "/__og-image__/static/unh/alias/og.png": {
    "type": "image/png",
    "etag": "\"92af-oPl8SqaQTY2KR/GdqqBn5jAoNYM\"",
    "mtime": "2025-12-29T15:10:36.629Z",
    "size": 37551,
    "path": "../public/__og-image__/static/unh/alias/og.png"
  },
  "/__og-image__/static/unh/auto-generate/og.png": {
    "type": "image/png",
    "etag": "\"a614-g2OtAJwo2crbD0e3wLX2C/mTzOQ\"",
    "mtime": "2025-12-29T15:10:36.030Z",
    "size": 42516,
    "path": "../public/__og-image__/static/unh/auto-generate/og.png"
  },
  "/__og-image__/static/unh/devtools/og.png": {
    "type": "image/png",
    "etag": "\"9d9f-99iKTxXaTGhkF0YBHA2zp+iSK/I\"",
    "mtime": "2025-12-29T15:10:36.629Z",
    "size": 40351,
    "path": "../public/__og-image__/static/unh/devtools/og.png"
  },
  "/__og-image__/static/unh/env/og.png": {
    "type": "image/png",
    "etag": "\"c601-Oy3zGEu5b19Eyfx3o9rTAT8QdMQ\"",
    "mtime": "2025-12-29T15:10:35.964Z",
    "size": 50689,
    "path": "../public/__og-image__/static/unh/env/og.png"
  },
  "/__og-image__/static/unh/hooks/og.png": {
    "type": "image/png",
    "etag": "\"b57a-C4B0IW2JEPq7fHVtayBRGZh5zeM\"",
    "mtime": "2025-12-29T15:10:35.993Z",
    "size": 46458,
    "path": "../public/__og-image__/static/unh/hooks/og.png"
  },
  "/__og-image__/static/unh/installation/og.png": {
    "type": "image/png",
    "etag": "\"956b-2zFlq1zV9Z882dntDOHIio2Qz7k\"",
    "mtime": "2025-12-29T15:10:37.447Z",
    "size": 38251,
    "path": "../public/__og-image__/static/unh/installation/og.png"
  },
  "/__og-image__/static/uni-network/advanced/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:37.927Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-network/advanced/og.png"
  },
  "/__og-image__/static/uni-network/api/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:39.371Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-network/api/og.png"
  },
  "/__og-image__/static/uni-network/guide/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:40.429Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-network/guide/og.png"
  },
  "/__og-image__/static/uni-network/other/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:41.266Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-network/other/og.png"
  },
  "/__og-image__/static/uni-typed/guide/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:43.644Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-typed/guide/og.png"
  },
  "/__og-image__/static/uni-typed/other/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:45.833Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-typed/other/og.png"
  },
  "/__og-image__/static/uni-use/api/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:47.607Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-use/api/og.png"
  },
  "/__og-image__/static/uni-use/guide/og.png": {
    "type": "image/png",
    "etag": "\"9e48-gCncnv2SiynQ+wq9NRzAROJXyxY\"",
    "mtime": "2025-12-29T15:10:58.002Z",
    "size": 40520,
    "path": "../public/__og-image__/static/uni-use/guide/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-pages/definepage/og.png": {
    "type": "image/png",
    "etag": "\"9132-ZVl8Dnpf90tlZ1LHq26X+1S7eAc\"",
    "mtime": "2025-12-29T15:11:01.867Z",
    "size": 37170,
    "path": "../public/__og-image__/static/vite-plugin-uni-pages/definepage/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-pages/extension/og.png": {
    "type": "image/png",
    "etag": "\"8353-14YxOBZz0wMgYBZt0kHUSDnybOc\"",
    "mtime": "2025-12-29T15:11:02.634Z",
    "size": 33619,
    "path": "../public/__og-image__/static/vite-plugin-uni-pages/extension/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-pages/guide/og.png": {
    "type": "image/png",
    "etag": "\"8c59-YIoUbutadZGbcyUZh93C3x1F9Vk\"",
    "mtime": "2025-12-29T15:11:02.634Z",
    "size": 35929,
    "path": "../public/__og-image__/static/vite-plugin-uni-pages/guide/og.png"
  },
  "/__og-image__/static/vite-plugin-uni-pages/option/og.png": {
    "type": "image/png",
    "etag": "\"614a-usrmwu1rmIF12Hl/xOCLd8cCMX8\"",
    "mtime": "2025-12-29T15:11:02.613Z",
    "size": 24906,
    "path": "../public/__og-image__/static/vite-plugin-uni-pages/option/og.png"
  },
  "/__og-image__/static/vs-code/uni-app-schemas-vscode/og.png": {
    "type": "image/png",
    "etag": "\"c220-rnuktBy+vlnmPdOak4HgJG3OfTU\"",
    "mtime": "2025-12-29T15:11:06.475Z",
    "size": 49696,
    "path": "../public/__og-image__/static/vs-code/uni-app-schemas-vscode/og.png"
  },
  "/__og-image__/static/vs-code/uni-app-snippets-vscode/og.png": {
    "type": "image/png",
    "etag": "\"b0a9-G7CNYM0VfB6yPoDKqhWtjitSt5k\"",
    "mtime": "2025-12-29T15:11:06.874Z",
    "size": 45225,
    "path": "../public/__og-image__/static/vs-code/uni-app-snippets-vscode/og.png"
  },
  "/__og-image__/static/vs-code/uni-cloud-snippets-vscode/og.png": {
    "type": "image/png",
    "etag": "\"b6d5-RU/7uEf/sGEPE5yTtCemSsnFJUk\"",
    "mtime": "2025-12-29T15:11:06.475Z",
    "size": 46805,
    "path": "../public/__og-image__/static/vs-code/uni-cloud-snippets-vscode/og.png"
  },
  "/__og-image__/static/vs-code/uni-create-view/og.png": {
    "type": "image/png",
    "etag": "\"d47b-4z8HRquZgutGWmJyxI53VfM9cTc\"",
    "mtime": "2025-12-29T15:11:07.217Z",
    "size": 54395,
    "path": "../public/__og-image__/static/vs-code/uni-create-view/og.png"
  },
  "/__og-image__/static/vs-code/uni-helper-vscode/og.png": {
    "type": "image/png",
    "etag": "\"ac23-AgfdyNHlKOKfdqJ9ueWp3nBO16E\"",
    "mtime": "2025-12-29T15:11:06.879Z",
    "size": 44067,
    "path": "../public/__og-image__/static/vs-code/uni-helper-vscode/og.png"
  },
  "/__og-image__/static/vs-code/uni-highlight-vscode/og.png": {
    "type": "image/png",
    "etag": "\"afbf-Prk+hivv709dSBxUej2meKPSU0o\"",
    "mtime": "2025-12-29T15:11:07.382Z",
    "size": 44991,
    "path": "../public/__og-image__/static/vs-code/uni-highlight-vscode/og.png"
  },
  "/__og-image__/static/vs-code/uni-ui-snippets-vscode/og.png": {
    "type": "image/png",
    "etag": "\"a3f7-0009cBqMfZr6cIPq62ZCD5Yr5dU\"",
    "mtime": "2025-12-29T15:11:07.381Z",
    "size": 41975,
    "path": "../public/__og-image__/static/vs-code/uni-ui-snippets-vscode/og.png"
  },
  "/_ipx/_/create-uni/dark/cli.png": {
    "type": "image/png",
    "etag": "\"77e20-+ejfLLUgD96ZSwu5X6cSXA/XInA\"",
    "mtime": "2025-12-29T15:10:32.272Z",
    "size": 491040,
    "path": "../public/_ipx/_/create-uni/dark/cli.png"
  },
  "/_ipx/s_32x32/https:/github.com/Epiphany.png": {
    "type": "image/png",
    "etag": "\"3fe-Fa59WJuhjHfDTwSQnTNQ2qAagDg\"",
    "mtime": "2025-12-29T15:10:29.967Z",
    "size": 1022,
    "path": "../public/_ipx/s_32x32/https:/github.com/Epiphany.png"
  },
  "/_ipx/s_32x32/https:/github.com/FliPPeDround.png": {
    "type": "image/png",
    "etag": "\"2b2-R5HDPdheIWNrZPkG7owzEifkNNM\"",
    "mtime": "2025-12-29T15:10:28.529Z",
    "size": 690,
    "path": "../public/_ipx/s_32x32/https:/github.com/FliPPeDround.png"
  },
  "/_ipx/s_32x32/https:/github.com/KeJunMao.png": {
    "type": "image/png",
    "etag": "\"7e1-3ssC+K03GjqpKbobnhoo057fXkk\"",
    "mtime": "2025-12-29T15:10:28.572Z",
    "size": 2017,
    "path": "../public/_ipx/s_32x32/https:/github.com/KeJunMao.png"
  },
  "/_ipx/s_32x32/https:/github.com/ModyQyW.png": {
    "type": "image/png",
    "etag": "\"632-sO+xf1RRrfmA4lpORaM9U9+Ycrw\"",
    "mtime": "2025-12-29T15:10:28.572Z",
    "size": 1586,
    "path": "../public/_ipx/s_32x32/https:/github.com/ModyQyW.png"
  },
  "/_ipx/s_32x32/https:/github.com/Moonofweisheng.png": {
    "type": "image/png",
    "etag": "\"3a7-cmkWOyjp21j2ETRMI4zadAFNSxQ\"",
    "mtime": "2025-12-29T15:10:29.999Z",
    "size": 935,
    "path": "../public/_ipx/s_32x32/https:/github.com/Moonofweisheng.png"
  },
  "/_ipx/s_32x32/https:/github.com/Otto-J.png": {
    "type": "image/png",
    "etag": "\"303-YVEMa5ZrxVR7ooTaBsvV8ixWIVo\"",
    "mtime": "2025-12-29T15:10:30.097Z",
    "size": 771,
    "path": "../public/_ipx/s_32x32/https:/github.com/Otto-J.png"
  },
  "/_ipx/s_32x32/https:/github.com/chenbimo.png": {
    "type": "image/png",
    "etag": "\"35e-NYFnKd0VRU62crxx4cAoivhk20c\"",
    "mtime": "2025-12-29T15:10:30.097Z",
    "size": 862,
    "path": "../public/_ipx/s_32x32/https:/github.com/chenbimo.png"
  },
  "/_ipx/s_32x32/https:/github.com/skiyee.png": {
    "type": "image/png",
    "etag": "\"375-JsLSnUFPNbyo0KIgQwOrJaQfnAY\"",
    "mtime": "2025-12-29T15:10:30.193Z",
    "size": 885,
    "path": "../public/_ipx/s_32x32/https:/github.com/skiyee.png"
  },
  "/_ipx/s_32x32/https:/github.com/sunpm.png": {
    "type": "image/png",
    "etag": "\"afe-bD1x89rS/d/4ZUKuKsy12SiulQk\"",
    "mtime": "2025-12-29T15:10:29.999Z",
    "size": 2814,
    "path": "../public/_ipx/s_32x32/https:/github.com/sunpm.png"
  },
  "/_ipx/s_32x32/https:/github.com/xiaohe0601.png": {
    "type": "image/png",
    "etag": "\"364-T1/OhtkGb67DzISs/w9Utr+IwlM\"",
    "mtime": "2025-12-29T15:10:30.943Z",
    "size": 868,
    "path": "../public/_ipx/s_32x32/https:/github.com/xiaohe0601.png"
  },
  "/_ipx/s_64x64/https:/github.com/Epiphany.png": {
    "type": "image/png",
    "etag": "\"45e-vH3qObgB55YcIHj/4W+JLGlnC9M\"",
    "mtime": "2025-12-29T15:10:29.586Z",
    "size": 1118,
    "path": "../public/_ipx/s_64x64/https:/github.com/Epiphany.png"
  },
  "/_ipx/s_64x64/https:/github.com/FliPPeDround.png": {
    "type": "image/png",
    "etag": "\"453-WGs4gVMflQOsmI8lZEUKGwdHPOU\"",
    "mtime": "2025-12-29T15:10:28.529Z",
    "size": 1107,
    "path": "../public/_ipx/s_64x64/https:/github.com/FliPPeDround.png"
  },
  "/_ipx/s_64x64/https:/github.com/KeJunMao.png": {
    "type": "image/png",
    "etag": "\"184f-kj7NN1F0qcZvQuxHUsfO/9Jq8aQ\"",
    "mtime": "2025-12-29T15:10:28.710Z",
    "size": 6223,
    "path": "../public/_ipx/s_64x64/https:/github.com/KeJunMao.png"
  },
  "/_ipx/s_64x64/https:/github.com/ModyQyW.png": {
    "type": "image/png",
    "etag": "\"db8-CucqVd65rjOmt85imsH6wD5e+yc\"",
    "mtime": "2025-12-29T15:10:28.585Z",
    "size": 3512,
    "path": "../public/_ipx/s_64x64/https:/github.com/ModyQyW.png"
  },
  "/_ipx/s_64x64/https:/github.com/Moonofweisheng.png": {
    "type": "image/png",
    "etag": "\"6cf-PYnAS8pZoaVHDcgu5FhYdZu/73A\"",
    "mtime": "2025-12-29T15:10:29.999Z",
    "size": 1743,
    "path": "../public/_ipx/s_64x64/https:/github.com/Moonofweisheng.png"
  },
  "/_ipx/s_64x64/https:/github.com/Otto-J.png": {
    "type": "image/png",
    "etag": "\"4da-EJPggcnrBgAW79AXqwlvp7NrfSk\"",
    "mtime": "2025-12-29T15:10:30.207Z",
    "size": 1242,
    "path": "../public/_ipx/s_64x64/https:/github.com/Otto-J.png"
  },
  "/_ipx/s_64x64/https:/github.com/chenbimo.png": {
    "type": "image/png",
    "etag": "\"616-wveTKGl986L23fS4PByao3HoV8g\"",
    "mtime": "2025-12-29T15:10:30.275Z",
    "size": 1558,
    "path": "../public/_ipx/s_64x64/https:/github.com/chenbimo.png"
  },
  "/_ipx/s_64x64/https:/github.com/skiyee.png": {
    "type": "image/png",
    "etag": "\"69d-8boi6NwFBciOFwarexirrKbedpM\"",
    "mtime": "2025-12-29T15:10:30.115Z",
    "size": 1693,
    "path": "../public/_ipx/s_64x64/https:/github.com/skiyee.png"
  },
  "/_ipx/s_64x64/https:/github.com/sunpm.png": {
    "type": "image/png",
    "etag": "\"27dd-rzJjHbtC1vdR/2nu0RW1n/sQ9Oo\"",
    "mtime": "2025-12-29T15:10:30.964Z",
    "size": 10205,
    "path": "../public/_ipx/s_64x64/https:/github.com/sunpm.png"
  },
  "/_ipx/s_64x64/https:/github.com/xiaohe0601.png": {
    "type": "image/png",
    "etag": "\"56a-idMzDG3G8Y3tJkPclFi/aSfWtHg\"",
    "mtime": "2025-12-29T15:10:30.501Z",
    "size": 1386,
    "path": "../public/_ipx/s_64x64/https:/github.com/xiaohe0601.png"
  },
  "/__og-image__/static/uni-network/advanced/cancellation/og.png": {
    "type": "image/png",
    "etag": "\"8ab2-l9s9mem2GSZJbaIP2uZWNqr8znc\"",
    "mtime": "2025-12-29T15:10:37.964Z",
    "size": 35506,
    "path": "../public/__og-image__/static/uni-network/advanced/cancellation/og.png"
  },
  "/__og-image__/static/uni-network/advanced/composition-api/og.png": {
    "type": "image/png",
    "etag": "\"95f4-urYfEA0/qhbevaZ6dvdY9LlMQO4\"",
    "mtime": "2025-12-29T15:10:38.577Z",
    "size": 38388,
    "path": "../public/__og-image__/static/uni-network/advanced/composition-api/og.png"
  },
  "/__og-image__/static/uni-network/advanced/enhancements/og.png": {
    "type": "image/png",
    "etag": "\"879e-UM5ixNHWQqVluXunvaKfeAPJpR8\"",
    "mtime": "2025-12-29T15:10:37.963Z",
    "size": 34718,
    "path": "../public/__og-image__/static/uni-network/advanced/enhancements/og.png"
  },
  "/__og-image__/static/uni-network/advanced/handling-errors/og.png": {
    "type": "image/png",
    "etag": "\"899a-PaXF2rc7T77xfvCShxAqOhFUkGg\"",
    "mtime": "2025-12-29T15:10:39.426Z",
    "size": 35226,
    "path": "../public/__og-image__/static/uni-network/advanced/handling-errors/og.png"
  },
  "/__og-image__/static/uni-network/advanced/interceptors/og.png": {
    "type": "image/png",
    "etag": "\"9cdb-iD+Ms/xZCWre+BsB2fNBh3EnQX0\"",
    "mtime": "2025-12-29T15:10:38.577Z",
    "size": 40155,
    "path": "../public/__og-image__/static/uni-network/advanced/interceptors/og.png"
  },
  "/__og-image__/static/uni-network/advanced/typescript-support/og.png": {
    "type": "image/png",
    "etag": "\"9e46-UrmKdbKIvz4AZrC/WT+d2OuLYQ8\"",
    "mtime": "2025-12-29T15:10:39.833Z",
    "size": 40518,
    "path": "../public/__og-image__/static/uni-network/advanced/typescript-support/og.png"
  },
  "/__og-image__/static/uni-network/api/config-defaults/og.png": {
    "type": "image/png",
    "etag": "\"9e2e-XlthgV6nbYlFSPaPUW0hEIEdVnA\"",
    "mtime": "2025-12-29T15:10:41.223Z",
    "size": 40494,
    "path": "../public/__og-image__/static/uni-network/api/config-defaults/og.png"
  },
  "/__og-image__/static/uni-network/api/instance/og.png": {
    "type": "image/png",
    "etag": "\"84f7-P2JtvZ6bOSYaFLdiij1cxvfGHHA\"",
    "mtime": "2025-12-29T15:10:40.049Z",
    "size": 34039,
    "path": "../public/__og-image__/static/uni-network/api/instance/og.png"
  },
  "/__og-image__/static/uni-network/api/introduction/og.png": {
    "type": "image/png",
    "etag": "\"8b3d-WCPdNo/3JbjFuilQkyes1SXDzlc\"",
    "mtime": "2025-12-29T15:10:40.014Z",
    "size": 35645,
    "path": "../public/__og-image__/static/uni-network/api/introduction/og.png"
  },
  "/__og-image__/static/uni-network/api/request-config/og.png": {
    "type": "image/png",
    "etag": "\"8d79-3vZeSL/SJc7xeCtVGhEKrOqtI8s\"",
    "mtime": "2025-12-29T15:10:41.223Z",
    "size": 36217,
    "path": "../public/__og-image__/static/uni-network/api/request-config/og.png"
  },
  "/__og-image__/static/uni-network/api/response-schema/og.png": {
    "type": "image/png",
    "etag": "\"8e89-gfIIpUDSRXBtEigXEexEACq70xw\"",
    "mtime": "2025-12-29T15:10:41.757Z",
    "size": 36489,
    "path": "../public/__og-image__/static/uni-network/api/response-schema/og.png"
  },
  "/__og-image__/static/uni-network/guide/example/og.png": {
    "type": "image/png",
    "etag": "\"80c4-huc8xJHd8MCUuspkvdcaagtaLUo\"",
    "mtime": "2025-12-29T15:10:41.984Z",
    "size": 32964,
    "path": "../public/__og-image__/static/uni-network/guide/example/og.png"
  },
  "/__og-image__/static/uni-network/guide/installation/og.png": {
    "type": "image/png",
    "etag": "\"7cb2-8MTr9VVAaAzdgu2ZU+D35tk+Xxk\"",
    "mtime": "2025-12-29T15:10:43.475Z",
    "size": 31922,
    "path": "../public/__og-image__/static/uni-network/guide/installation/og.png"
  },
  "/__og-image__/static/uni-network/guide/introduction/og.png": {
    "type": "image/png",
    "etag": "\"9d59-uWevY87f3ityZDoZt0/ZhRi+U3I\"",
    "mtime": "2025-12-29T15:10:42.213Z",
    "size": 40281,
    "path": "../public/__og-image__/static/uni-network/guide/introduction/og.png"
  },
  "/__og-image__/static/uni-network/other/build/og.png": {
    "type": "image/png",
    "etag": "\"99af-kdAx38RavAeDZUKsZ0G+KKLitkk\"",
    "mtime": "2025-12-29T15:10:43.477Z",
    "size": 39343,
    "path": "../public/__og-image__/static/uni-network/other/build/og.png"
  },
  "/__og-image__/static/uni-network/other/comparison/og.png": {
    "type": "image/png",
    "etag": "\"7825-u16GSqyawdhljtfdaoARsSuoWVE\"",
    "mtime": "2025-12-29T15:10:42.641Z",
    "size": 30757,
    "path": "../public/__og-image__/static/uni-network/other/comparison/og.png"
  },
  "/__og-image__/static/uni-network/other/thank/og.png": {
    "type": "image/png",
    "etag": "\"77c6-c11diwCUUuVq+slzGs+JWgz5Occ\"",
    "mtime": "2025-12-29T15:10:43.660Z",
    "size": 30662,
    "path": "../public/__og-image__/static/uni-network/other/thank/og.png"
  },
  "/__og-image__/static/uni-typed/guide/getting-started/og.png": {
    "type": "image/png",
    "etag": "\"9440-n5u8/rDEDLDlRzDBtwFgfszOCa8\"",
    "mtime": "2025-12-29T15:10:44.162Z",
    "size": 37952,
    "path": "../public/__og-image__/static/uni-typed/guide/getting-started/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-app-components/og.png": {
    "type": "image/png",
    "etag": "\"827c-ZNcsDw27NaXEug2v2PbJuBaJs2w\"",
    "mtime": "2025-12-29T15:10:44.162Z",
    "size": 33404,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-app-components/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-app-types/og.png": {
    "type": "image/png",
    "etag": "\"a219-fw41lYoYomho4se9NwaVM99EvRE\"",
    "mtime": "2025-12-29T15:10:45.835Z",
    "size": 41497,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-app-types/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-cloud-components/og.png": {
    "type": "image/png",
    "etag": "\"84d4-FZY/yeH20K8tXwftNvLYjY8LXFk\"",
    "mtime": "2025-12-29T15:10:45.224Z",
    "size": 34004,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-cloud-components/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-cloud-types/og.png": {
    "type": "image/png",
    "etag": "\"a7de-ykbnwJfxDQ67xz4XOv4R3TOf/ig\"",
    "mtime": "2025-12-29T15:10:45.817Z",
    "size": 42974,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-cloud-types/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-components/og.png": {
    "type": "image/png",
    "etag": "\"761c-zXEAkqOon64ipaET1cPdMX1fBWw\"",
    "mtime": "2025-12-29T15:10:45.225Z",
    "size": 30236,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-components/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-types/og.png": {
    "type": "image/png",
    "etag": "\"a52e-TE/cXEiW0tJJ5PfnQqATJbkcPBQ\"",
    "mtime": "2025-12-29T15:10:46.028Z",
    "size": 42286,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-types/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-ui-components/og.png": {
    "type": "image/png",
    "etag": "\"7a07-QU25RycjxWjnC9XPkJENkGwhD1M\"",
    "mtime": "2025-12-29T15:10:46.870Z",
    "size": 31239,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-ui-components/og.png"
  },
  "/__og-image__/static/uni-typed/guide/uni-ui-types/og.png": {
    "type": "image/png",
    "etag": "\"972f-5UIkemjnKQlHEhlLRkpS8A0dWEg\"",
    "mtime": "2025-12-29T15:10:47.583Z",
    "size": 38703,
    "path": "../public/__og-image__/static/uni-typed/guide/uni-ui-types/og.png"
  },
  "/__og-image__/static/uni-typed/guide/why/og.png": {
    "type": "image/png",
    "etag": "\"9def-SoEb3XPhxMPCTttSnluzWsayLz4\"",
    "mtime": "2025-12-29T15:10:46.252Z",
    "size": 40431,
    "path": "../public/__og-image__/static/uni-typed/guide/why/og.png"
  },
  "/__og-image__/static/uni-typed/other/faq/og.png": {
    "type": "image/png",
    "etag": "\"69cf-IBux6EWOBLfeelj82wuTdoBXjDU\"",
    "mtime": "2025-12-29T15:10:47.377Z",
    "size": 27087,
    "path": "../public/__og-image__/static/uni-typed/other/faq/og.png"
  },
  "/__og-image__/static/uni-typed/other/migrate-v0-to-v1/og.png": {
    "type": "image/png",
    "etag": "\"8aaa-OnlWAMa1sYBt0sOE/CPEVw4AVnM\"",
    "mtime": "2025-12-29T15:10:47.667Z",
    "size": 35498,
    "path": "../public/__og-image__/static/uni-typed/other/migrate-v0-to-v1/og.png"
  },
  "/__og-image__/static/uni-use/api/tryonbackpress/og.png": {
    "type": "image/png",
    "etag": "\"f56d-528TEIiRnn2S0BFJAeoUv6t2a6M\"",
    "mtime": "2025-12-29T15:10:49.195Z",
    "size": 62829,
    "path": "../public/__og-image__/static/uni-use/api/tryonbackpress/og.png"
  },
  "/__og-image__/static/uni-use/api/tryonhide/og.png": {
    "type": "image/png",
    "etag": "\"98fa-gcBOig4/Btco44ttl3bl7qHGxig\"",
    "mtime": "2025-12-29T15:10:48.308Z",
    "size": 39162,
    "path": "../public/__og-image__/static/uni-use/api/tryonhide/og.png"
  },
  "/__og-image__/static/uni-use/api/tryoninit/og.png": {
    "type": "image/png",
    "etag": "\"90f2-ZkeE2IUYz1nSBY3rDLcDbbEKAOY\"",
    "mtime": "2025-12-29T15:10:48.904Z",
    "size": 37106,
    "path": "../public/__og-image__/static/uni-use/api/tryoninit/og.png"
  },
  "/__og-image__/static/uni-use/api/tryonload/og.png": {
    "type": "image/png",
    "etag": "\"9b12-0tD/bQS0DWC3MYt5/wfy8siPNR4\"",
    "mtime": "2025-12-29T15:10:49.368Z",
    "size": 39698,
    "path": "../public/__og-image__/static/uni-use/api/tryonload/og.png"
  },
  "/__og-image__/static/uni-use/api/tryonready/og.png": {
    "type": "image/png",
    "etag": "\"a40a-xcOGnEPyI3btz3CW00A3zJKNGbU\"",
    "mtime": "2025-12-29T15:10:49.409Z",
    "size": 41994,
    "path": "../public/__og-image__/static/uni-use/api/tryonready/og.png"
  },
  "/__og-image__/static/uni-use/api/tryonscopedispose/og.png": {
    "type": "image/png",
    "etag": "\"dc0e-dnHul1cmbHExR2eK3g9KsiXVfnM\"",
    "mtime": "2025-12-29T15:10:49.796Z",
    "size": 56334,
    "path": "../public/__og-image__/static/uni-use/api/tryonscopedispose/og.png"
  },
  "/__og-image__/static/uni-use/api/tryonshow/og.png": {
    "type": "image/png",
    "etag": "\"9f5e-bRDpxoiZOW2U5u7c/+dEtoSK7es\"",
    "mtime": "2025-12-29T15:10:49.824Z",
    "size": 40798,
    "path": "../public/__og-image__/static/uni-use/api/tryonshow/og.png"
  },
  "/__og-image__/static/uni-use/api/tryonunload/og.png": {
    "type": "image/png",
    "etag": "\"a3ef-2Rijjw2x6rDRV2r9Kt37Z2ZyZlE\"",
    "mtime": "2025-12-29T15:10:50.201Z",
    "size": 41967,
    "path": "../public/__og-image__/static/uni-use/api/tryonunload/og.png"
  },
  "/__og-image__/static/uni-use/api/useactionsheet/og.png": {
    "type": "image/png",
    "etag": "\"aab8-AML7CqUDH0XQe6xdmzK0+OhDmhk\"",
    "mtime": "2025-12-29T15:10:50.891Z",
    "size": 43704,
    "path": "../public/__og-image__/static/uni-use/api/useactionsheet/og.png"
  },
  "/__og-image__/static/uni-use/api/useclipboarddata/og.png": {
    "type": "image/png",
    "etag": "\"cd47-O4SsZiTnlzX3wA1SHbaqANQN638\"",
    "mtime": "2025-12-29T15:10:50.283Z",
    "size": 52551,
    "path": "../public/__og-image__/static/uni-use/api/useclipboarddata/og.png"
  },
  "/__og-image__/static/uni-use/api/usedownloadfile/og.png": {
    "type": "image/png",
    "etag": "\"ed8d-tbLN4jId8op+8ImiFa3/xiE/stM\"",
    "mtime": "2025-12-29T15:10:51.336Z",
    "size": 60813,
    "path": "../public/__og-image__/static/uni-use/api/usedownloadfile/og.png"
  },
  "/__og-image__/static/uni-use/api/useglobaldata/og.png": {
    "type": "image/png",
    "etag": "\"d266-m0YyToCPW7WGKhIReCZepYem1xc\"",
    "mtime": "2025-12-29T15:10:51.613Z",
    "size": 53862,
    "path": "../public/__og-image__/static/uni-use/api/useglobaldata/og.png"
  },
  "/__og-image__/static/uni-use/api/useinterceptor/og.png": {
    "type": "image/png",
    "etag": "\"cc7c-TnulFbPqQX2g43QoEUINwHnwduw\"",
    "mtime": "2025-12-29T15:10:51.400Z",
    "size": 52348,
    "path": "../public/__og-image__/static/uni-use/api/useinterceptor/og.png"
  },
  "/__og-image__/static/uni-use/api/useloading/og.png": {
    "type": "image/png",
    "etag": "\"ddbd-cOfFc9+y8f/eI25MpihCR57WLJE\"",
    "mtime": "2025-12-29T15:10:51.838Z",
    "size": 56765,
    "path": "../public/__og-image__/static/uni-use/api/useloading/og.png"
  },
  "/__og-image__/static/uni-use/api/usemodal/og.png": {
    "type": "image/png",
    "etag": "\"957b-+e6/wthsxD9szTdWkfJMNkRowCg\"",
    "mtime": "2025-12-29T15:10:52.038Z",
    "size": 38267,
    "path": "../public/__og-image__/static/uni-use/api/usemodal/og.png"
  },
  "/__og-image__/static/uni-use/api/usenetwork/og.png": {
    "type": "image/png",
    "etag": "\"8738-PfIvz00x+8q1nlxBg3vqPqcMRLo\"",
    "mtime": "2025-12-29T15:10:52.886Z",
    "size": 34616,
    "path": "../public/__og-image__/static/uni-use/api/usenetwork/og.png"
  },
  "/__og-image__/static/uni-use/api/useonline/og.png": {
    "type": "image/png",
    "etag": "\"8f32-z3tdSbATU2NggSbwac6xq4IpjB0\"",
    "mtime": "2025-12-29T15:10:53.095Z",
    "size": 36658,
    "path": "../public/__og-image__/static/uni-use/api/useonline/og.png"
  },
  "/__og-image__/static/uni-use/api/usepage/og.png": {
    "type": "image/png",
    "etag": "\"7ecb-V8sE+2Wxt5IDJQbibpxqcJvrg+o\"",
    "mtime": "2025-12-29T15:10:53.309Z",
    "size": 32459,
    "path": "../public/__og-image__/static/uni-use/api/usepage/og.png"
  },
  "/__og-image__/static/uni-use/api/usepages/og.png": {
    "type": "image/png",
    "etag": "\"886f-W0QCHvbecIyUzodCzABHkcd68C8\"",
    "mtime": "2025-12-29T15:10:53.563Z",
    "size": 34927,
    "path": "../public/__og-image__/static/uni-use/api/usepages/og.png"
  },
  "/__og-image__/static/uni-use/api/usepagescroll/og.png": {
    "type": "image/png",
    "etag": "\"9615-PyEIU3tkA3eZ8j6dVMSxI4gJ780\"",
    "mtime": "2025-12-29T15:10:53.740Z",
    "size": 38421,
    "path": "../public/__og-image__/static/uni-use/api/usepagescroll/og.png"
  },
  "/__og-image__/static/uni-use/api/usepreferreddark/og.png": {
    "type": "image/png",
    "etag": "\"9d9b-bfnD1c1JtUEAEmRyouWWRNTBtKE\"",
    "mtime": "2025-12-29T15:10:53.500Z",
    "size": 40347,
    "path": "../public/__og-image__/static/uni-use/api/usepreferreddark/og.png"
  },
  "/__og-image__/static/uni-use/api/usepreferredlanguage/og.png": {
    "type": "image/png",
    "etag": "\"a642-RURQ0Vk2vXi0If90pLx9LHECzoU\"",
    "mtime": "2025-12-29T15:10:54.165Z",
    "size": 42562,
    "path": "../public/__og-image__/static/uni-use/api/usepreferredlanguage/og.png"
  },
  "/__og-image__/static/uni-use/api/useprevpage/og.png": {
    "type": "image/png",
    "etag": "\"88a5-zG2P/nXCYJSZAMA9aDAf5m+OE8s\"",
    "mtime": "2025-12-29T15:10:53.981Z",
    "size": 34981,
    "path": "../public/__og-image__/static/uni-use/api/useprevpage/og.png"
  },
  "/__og-image__/static/uni-use/api/useprevroute/og.png": {
    "type": "image/png",
    "etag": "\"8dc3-78hrc443QOkY7RaB84bSVMeGkmY\"",
    "mtime": "2025-12-29T15:10:54.823Z",
    "size": 36291,
    "path": "../public/__og-image__/static/uni-use/api/useprevroute/og.png"
  },
  "/__og-image__/static/uni-use/api/useprovider/og.png": {
    "type": "image/png",
    "etag": "\"ac1d-+62k+qo/2ZyG2C9rlYPYLG6nURo\"",
    "mtime": "2025-12-29T15:10:55.307Z",
    "size": 44061,
    "path": "../public/__og-image__/static/uni-use/api/useprovider/og.png"
  },
  "/__og-image__/static/uni-use/api/usequery/og.png": {
    "type": "image/png",
    "etag": "\"a86a-wpJgE1gUqHfNlkw/dG4Z2xLv3kA\"",
    "mtime": "2025-12-29T15:10:54.858Z",
    "size": 43114,
    "path": "../public/__og-image__/static/uni-use/api/usequery/og.png"
  },
  "/__og-image__/static/uni-use/api/userequest/og.png": {
    "type": "image/png",
    "etag": "\"d77d-CeEak0Vx/agd3NquuvBh36tQogM\"",
    "mtime": "2025-12-29T15:10:55.917Z",
    "size": 55165,
    "path": "../public/__og-image__/static/uni-use/api/userequest/og.png"
  },
  "/__og-image__/static/uni-use/api/useroute/og.png": {
    "type": "image/png",
    "etag": "\"82a4-c292h9nuby2fDtbmzVxRW8H2Vcw\"",
    "mtime": "2025-12-29T15:10:55.306Z",
    "size": 33444,
    "path": "../public/__og-image__/static/uni-use/api/useroute/og.png"
  },
  "/__og-image__/static/uni-use/api/userouter/og.png": {
    "type": "image/png",
    "etag": "\"8600-M0XmxlpMLOVVaBIlYgY22uGaxAs\"",
    "mtime": "2025-12-29T15:10:55.917Z",
    "size": 34304,
    "path": "../public/__og-image__/static/uni-use/api/userouter/og.png"
  },
  "/__og-image__/static/uni-use/api/usescancode/og.png": {
    "type": "image/png",
    "etag": "\"a05b-EGTCjRc/mYNQrJqOK5WjBQH1ano\"",
    "mtime": "2025-12-29T15:10:56.941Z",
    "size": 41051,
    "path": "../public/__og-image__/static/uni-use/api/usescancode/og.png"
  },
  "/__og-image__/static/uni-use/api/usescreenbrightness/og.png": {
    "type": "image/png",
    "etag": "\"cd49-7AjvvHXORM58GfVo1VHvB94Ij6g\"",
    "mtime": "2025-12-29T15:10:56.984Z",
    "size": 52553,
    "path": "../public/__og-image__/static/uni-use/api/usescreenbrightness/og.png"
  },
  "/__og-image__/static/uni-use/api/useselectorquery/og.png": {
    "type": "image/png",
    "etag": "\"a5d4-ozkvZRC9sAfQ8FbATFN86Vpjl8M\"",
    "mtime": "2025-12-29T15:10:57.764Z",
    "size": 42452,
    "path": "../public/__og-image__/static/uni-use/api/useselectorquery/og.png"
  },
  "/__og-image__/static/uni-use/api/usesocket/og.png": {
    "type": "image/png",
    "etag": "\"db2c-6rSuJf9nMHwPvwSZwRpetlzoXgk\"",
    "mtime": "2025-12-29T15:10:57.333Z",
    "size": 56108,
    "path": "../public/__og-image__/static/uni-use/api/usesocket/og.png"
  },
  "/__og-image__/static/uni-use/api/usestorage/og.png": {
    "type": "image/png",
    "etag": "\"9d55-OgQ2oGZr1ndlIH4pSpuroLDPNNU\"",
    "mtime": "2025-12-29T15:10:57.354Z",
    "size": 40277,
    "path": "../public/__og-image__/static/uni-use/api/usestorage/og.png"
  },
  "/__og-image__/static/uni-use/api/usestorageasync/og.png": {
    "type": "image/png",
    "etag": "\"fd0d-32JNWeTqYRmN33tXUArEoKYW028\"",
    "mtime": "2025-12-29T15:10:57.755Z",
    "size": 64781,
    "path": "../public/__og-image__/static/uni-use/api/usestorageasync/og.png"
  },
  "/__og-image__/static/uni-use/api/usestoragesync/og.png": {
    "type": "image/png",
    "etag": "\"ac4c-8fY3lVdRFmYa4Mg7vgbiubfGnGc\"",
    "mtime": "2025-12-29T15:10:58.002Z",
    "size": 44108,
    "path": "../public/__og-image__/static/uni-use/api/usestoragesync/og.png"
  },
  "/__og-image__/static/uni-use/api/usetoast/og.png": {
    "type": "image/png",
    "etag": "\"8d20-1vEdhMuIr8hFbzeVqmJuvOq9nLU\"",
    "mtime": "2025-12-29T15:10:58.619Z",
    "size": 36128,
    "path": "../public/__og-image__/static/uni-use/api/usetoast/og.png"
  },
  "/__og-image__/static/uni-use/api/useuploadfile/og.png": {
    "type": "image/png",
    "etag": "\"e0b3-hVAjVInb6CroIk0j/4x1Defxg2g\"",
    "mtime": "2025-12-29T15:10:58.892Z",
    "size": 57523,
    "path": "../public/__og-image__/static/uni-use/api/useuploadfile/og.png"
  },
  "/__og-image__/static/uni-use/api/usevisible/og.png": {
    "type": "image/png",
    "etag": "\"8ba3-Bp6pMkHRY8KMsZsmoqsjYqNH9l0\"",
    "mtime": "2025-12-29T15:10:58.952Z",
    "size": 35747,
    "path": "../public/__og-image__/static/uni-use/api/usevisible/og.png"
  },
  "/__og-image__/static/uni-use/guide/installation/og.png": {
    "type": "image/png",
    "etag": "\"7e69-e9z7mnksSEAtVW+5fv4+WQI27CI\"",
    "mtime": "2025-12-29T15:10:59.556Z",
    "size": 32361,
    "path": "../public/__og-image__/static/uni-use/guide/installation/og.png"
  },
  "/__og-image__/static/uni-use/guide/notice/og.png": {
    "type": "image/png",
    "etag": "\"651e-rhSych6i/DlmqsXFwTQ3yEW1XRk\"",
    "mtime": "2025-12-29T15:10:59.556Z",
    "size": 25886,
    "path": "../public/__og-image__/static/uni-use/guide/notice/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/getting-started/data-fetching/og.png": {
    "type": "image/png",
    "etag": "\"d327-61xSSCTGzSG+gMRgRZ9AFu9sfl0\"",
    "mtime": "2025-12-29T15:11:03.709Z",
    "size": 54055,
    "path": "../public/__og-image__/static/vitesse-uni-app/getting-started/data-fetching/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/getting-started/deployment/og.png": {
    "type": "image/png",
    "etag": "\"8427-BeZvXHUGTsQJ5EtahE1uPbRFwnI\"",
    "mtime": "2025-12-29T15:11:03.686Z",
    "size": 33831,
    "path": "../public/__og-image__/static/vitesse-uni-app/getting-started/deployment/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/getting-started/installation/og.png": {
    "type": "image/png",
    "etag": "\"a71e-Ly/Ix4HbSbYoFVZGjJIR4sO8LY8\"",
    "mtime": "2025-12-29T15:11:04.997Z",
    "size": 42782,
    "path": "../public/__og-image__/static/vitesse-uni-app/getting-started/installation/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/getting-started/introduction/og.png": {
    "type": "image/png",
    "etag": "\"10b69-gy1sbyQBiMJA90y2t8aJxOn+F3E\"",
    "mtime": "2025-12-29T15:11:03.876Z",
    "size": 68457,
    "path": "../public/__og-image__/static/vitesse-uni-app/getting-started/introduction/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/getting-started/state-management/og.png": {
    "type": "image/png",
    "etag": "\"a9c8-y4SjwlAev2ZKfDOIcEdA7bdEW7M\"",
    "mtime": "2025-12-29T15:11:03.686Z",
    "size": 43464,
    "path": "../public/__og-image__/static/vitesse-uni-app/getting-started/state-management/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/getting-started/styling/og.png": {
    "type": "image/png",
    "etag": "\"b6f1-/A4mrng7RrlC1szj8dWV151Zwx8\"",
    "mtime": "2025-12-29T15:11:04.528Z",
    "size": 46833,
    "path": "../public/__og-image__/static/vitesse-uni-app/getting-started/styling/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/getting-started/views/og.png": {
    "type": "image/png",
    "etag": "\"907a-9FbLB9L5Hh+8qLcdIJr10nops94\"",
    "mtime": "2025-12-29T15:11:04.916Z",
    "size": 36986,
    "path": "../public/__og-image__/static/vitesse-uni-app/getting-started/views/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/guide/auto-imports/og.png": {
    "type": "image/png",
    "etag": "\"b963-6K4V6Nb3jR4XHHGQg2/BN6orYwM\"",
    "mtime": "2025-12-29T15:11:05.222Z",
    "size": 47459,
    "path": "../public/__og-image__/static/vitesse-uni-app/guide/auto-imports/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/guide/typescript/og.png": {
    "type": "image/png",
    "etag": "\"bfc2-BgaHS2I9VsYKIGElj+kMl96V/MM\"",
    "mtime": "2025-12-29T15:11:05.295Z",
    "size": 49090,
    "path": "../public/__og-image__/static/vitesse-uni-app/guide/typescript/og.png"
  },
  "/__og-image__/static/vitesse-uni-app/guide/uniapp-development/og.png": {
    "type": "image/png",
    "etag": "\"f8c4-kgmgys39CeBAAGTvPeUXu8S7P4k\"",
    "mtime": "2025-12-29T15:11:06.476Z",
    "size": 63684,
    "path": "../public/__og-image__/static/vitesse-uni-app/guide/uniapp-development/og.png"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
const _EXTNAME_RE = /.(\.[^./]+|\.)$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve$1 = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const extname = function(p) {
  if (p === "..") return "";
  const match = _EXTNAME_RE.exec(normalizeWindowsPath(p));
  return match && match[1] || "";
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};
const basename = function(p, extension) {
  const segments = normalizeWindowsPath(p).split("/");
  let lastSegment = "";
  for (let i = segments.length - 1; i >= 0; i--) {
    const val = segments[i];
    if (val) {
      lastSegment = val;
      break;
    }
  }
  return extension && lastSegment.endsWith(extension) ? lastSegment.slice(0, -extension.length) : lastSegment;
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve$1(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_fonts/":{"maxAge":31536000},"/_scripts/":{"maxAge":31536000},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _3vdAZv = eventHandler$1((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader$1(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  if (encodings.length > 1) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$2({ statusCode: 404 });
    }
    return;
  }
  const ifNotMatch = getRequestHeader$1(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader$1(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const _f7hhGP = eventHandler(async (e) => {
  if (e.context._initedSiteConfig)
    return;
  const runtimeConfig = useRuntimeConfig(e);
  const config = runtimeConfig["nuxt-site-config"];
  const nitroApp = useNitroApp();
  const siteConfig = e.context.siteConfig || createSiteConfigStack({
    debug: config.debug
  });
  const nitroOrigin = getNitroOrigin(e);
  e.context.siteConfigNitroOrigin = nitroOrigin;
  {
    siteConfig.push({
      _context: "nitro:init",
      _priority: -4,
      url: nitroOrigin
    });
  }
  siteConfig.push({
    _context: "runtimeEnv",
    _priority: 0,
    ...runtimeConfig.site || {},
    ...runtimeConfig.public.site || {},
    ...envSiteConfig(globalThis._importMeta_.env)
    // just in-case, shouldn't be needed
  });
  const buildStack = config.stack || [];
  buildStack.forEach((c) => siteConfig.push(c));
  if (e.context._nitro.routeRules.site) {
    siteConfig.push({
      _context: "route-rules",
      ...e.context._nitro.routeRules.site
    });
  }
  if (config.multiTenancy) {
    const host = parseURL(nitroOrigin).host;
    const tenant = config.multiTenancy?.find((t) => t.hosts.includes(host));
    if (tenant) {
      siteConfig.push({
        _context: `multi-tenancy:${host}`,
        _priority: 0,
        ...tenant.config
      });
    }
  }
  const ctx = { siteConfig, event: e };
  await nitroApp.hooks.callHook("site-config:init", ctx);
  e.context.siteConfig = ctx.siteConfig;
  e.context._initedSiteConfig = true;
});

const logger = createConsola({
  defaults: {
    tag: "@nuxt/sitemap"
  }
});
const merger = createDefu((obj, key, value) => {
  if (Array.isArray(obj[key]) && Array.isArray(value))
    obj[key] = Array.from(/* @__PURE__ */ new Set([...obj[key], ...value]));
  return obj[key];
});
function mergeOnKey(arr, key) {
  const seen = /* @__PURE__ */ new Map();
  let resultLength = 0;
  const result = Array.from({ length: arr.length });
  for (const item of arr) {
    const k = item[key];
    if (seen.has(k)) {
      const existingIndex = seen.get(k);
      result[existingIndex] = merger(item, result[existingIndex]);
    } else {
      seen.set(k, resultLength);
      result[resultLength++] = item;
    }
  }
  return result.slice(0, resultLength);
}
function splitForLocales(path, locales) {
  const prefix = withLeadingSlash(path).split("/")[1];
  if (locales.includes(prefix))
    return [prefix, path.replace(`/${prefix}`, "")];
  return [null, path];
}
const StringifiedRegExpPattern = /\/(.*?)\/([gimsuy]*)$/;
function normalizeRuntimeFilters(input) {
  return (input || []).map((rule) => {
    if (rule instanceof RegExp || typeof rule === "string")
      return rule;
    const match = rule.regex.match(StringifiedRegExpPattern);
    if (match)
      return new RegExp(match[1], match[2]);
    return false;
  }).filter(Boolean);
}
function createPathFilter(options = {}) {
  const urlFilter = createFilter(options);
  return (loc) => {
    let path = loc;
    try {
      path = parseURL(loc).pathname;
    } catch {
      return false;
    }
    return urlFilter(path);
  };
}
function createFilter(options = {}) {
  const include = options.include || [];
  const exclude = options.exclude || [];
  if (include.length === 0 && exclude.length === 0)
    return () => true;
  return function(path) {
    for (const v of [{ rules: exclude, result: false }, { rules: include, result: true }]) {
      const regexRules = v.rules.filter((r) => r instanceof RegExp);
      if (regexRules.some((r) => r.test(path)))
        return v.result;
      const stringRules = v.rules.filter((r) => typeof r === "string");
      if (stringRules.length > 0) {
        const routes = {};
        for (const r of stringRules) {
          if (r === path)
            return v.result;
          routes[r] = true;
        }
        const routeRulesMatcher = toRouteMatcher(createRouter$1({ routes, strictTrailingSlash: false }));
        if (routeRulesMatcher.matchAll(path).length > 0)
          return Boolean(v.result);
      }
    }
    return include.length === 0;
  };
}

function xmlEscape(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function useSitemapRuntimeConfig(e) {
  const clone = JSON.parse(JSON.stringify(useRuntimeConfig(e).sitemap));
  for (const k in clone.sitemaps) {
    const sitemap = clone.sitemaps[k];
    sitemap.include = normalizeRuntimeFilters(sitemap.include);
    sitemap.exclude = normalizeRuntimeFilters(sitemap.exclude);
    clone.sitemaps[k] = sitemap;
  }
  return Object.freeze(clone);
}

const _AlJ4WX = defineEventHandler$1(async (e) => {
  const fixPath = createSitePathResolver(e, { absolute: false, withBase: true });
  const { sitemapName: fallbackSitemapName, cacheMaxAgeSeconds, version, xslColumns, xslTips } = useSitemapRuntimeConfig();
  setHeader(e, "Content-Type", "application/xslt+xml");
  if (cacheMaxAgeSeconds)
    setHeader(e, "Cache-Control", `public, max-age=${cacheMaxAgeSeconds}, must-revalidate`);
  else
    setHeader(e, "Cache-Control", `no-cache, no-store`);
  const { name: siteName, url: siteUrl } = useSiteConfig(e);
  const referrer = getHeader(e, "Referer") || "/";
  const referrerPath = parseURL(referrer).pathname;
  const isNotIndexButHasIndex = referrerPath !== "/sitemap.xml" && referrerPath !== "/sitemap_index.xml" && referrerPath.endsWith(".xml");
  const sitemapName = parseURL(referrer).pathname.split("/").pop()?.split("-sitemap")[0] || fallbackSitemapName;
  const title = `${siteName}${sitemapName !== "sitemap.xml" ? ` - ${sitemapName === "sitemap_index.xml" ? "index" : sitemapName}` : ""}`.replace(/&/g, "&amp;");
  const canonicalQuery = getQuery$1(referrer).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const conditionalTips = [
    'You are looking at a <a href="https://developer.mozilla.org/en-US/docs/Web/XSLT/Transforming_XML_with_XSLT/An_Overview" style="color: #398465" target="_blank">XML stylesheet</a>. Read the <a href="https://nuxtseo.com/sitemap/guides/customising-ui" style="color: #398465" target="_blank">docs</a> to learn how to customize it. View the page source to see the raw XML.',
    `URLs missing? Check Nuxt Devtools Sitemap tab (or the <a href="${xmlEscape(withQuery("/__sitemap__/debug.json", { sitemap: sitemapName }))}" style="color: #398465" target="_blank">debug endpoint</a>).`
  ];
  const fetchErrors = [];
  const xslQuery = getQuery(e);
  if (xslQuery.error_messages) {
    const errorMessages = xslQuery.error_messages;
    const errorUrls = xslQuery.error_urls;
    if (errorMessages) {
      const messages = Array.isArray(errorMessages) ? errorMessages : [errorMessages];
      const urls = Array.isArray(errorUrls) ? errorUrls : errorUrls ? [errorUrls] : [];
      messages.forEach((msg, i) => {
        const errorParts = [xmlEscape(msg)];
        if (urls[i]) {
          errorParts.push(xmlEscape(urls[i]));
        }
        fetchErrors.push(`<strong style="color: #dc2626;">Error ${i + 1}:</strong> ${errorParts.join(" - ")}`);
      });
    }
  }
  if (!isShowingCanonical) {
    const canonicalPreviewUrl = withQuery(referrer, { canonical: "" });
    conditionalTips.push(`Your canonical site URL is <strong>${xmlEscape(siteUrl)}</strong>.`);
    conditionalTips.push(`You can preview your canonical sitemap by visiting <a href="${xmlEscape(canonicalPreviewUrl)}" style="color: #398465; white-space: nowrap;">${xmlEscape(fixPath(canonicalPreviewUrl))}?canonical</a>`);
  } else {
    conditionalTips.push(`You are viewing the canonical sitemap. You can switch to using the request origin: <a href="${xmlEscape(fixPath(referrer))}" style="color: #398465; white-space: nowrap ">${xmlEscape(fixPath(referrer))}</a>`);
  }
  const hasRuntimeErrors = fetchErrors.length > 0;
  const showSidebar = hasRuntimeErrors;
  const runtimeErrors = hasRuntimeErrors ? fetchErrors.map((t) => `<li><p>${t}</p></li>`).join("\n") : "";
  let columns = [...xslColumns];
  if (!columns.length) {
    columns = [
      { label: "URL", width: "50%" },
      { label: "Images", width: "25%", select: "count(image:image)" },
      { label: "Last Updated", width: "25%", select: "concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))" }
    ];
  }
  return `<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="2.0"
                xmlns:html="http://www.w3.org/TR/REC-html40"
                xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
                xmlns:sitemap="http://www.sitemaps.org/schemas/sitemap/0.9"
                xmlns:xhtml="http://www.w3.org/1999/xhtml"
                xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" version="1.0" encoding="UTF-8" indent="yes"/>
  <xsl:template match="/">
    <html xmlns="http://www.w3.org/1999/xhtml">
      <head>
        <title>XML Sitemap</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <style type="text/css">
          body {
            font-family: Inter, Helvetica, Arial, sans-serif;
            font-size: 14px;
            color: #333;
          }

          table {
            border: none;
            border-collapse: collapse;
          }

          .bg-yellow-200 {
            background-color: #fef9c3;
          }

          .p-5 {
            padding: 1.25rem;
          }

          .rounded {
            border-radius: 4px;
            }

          .shadow {
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
          }

          #sitemap tr:nth-child(odd) td {
            background-color: #f8f8f8 !important;
          }

          #sitemap tbody tr:hover td {
            background-color: #fff;
          }

          #sitemap tbody tr:hover td, #sitemap tbody tr:hover td a {
            color: #000;
          }

          .expl a {
            color: #398465;
            font-weight: 600;
          }

          .expl a:visited {
            color: #398465;
          }

          a {
            color: #000;
            text-decoration: none;
          }

          a:visited {
            color: #777;
          }

          a:hover {
            text-decoration: underline;
          }

          td {
            font-size: 12px;
          }

          .text-2xl {
            font-size: 2rem;
            font-weight: 600;
            line-height: 1.25;
          }

          th {
            text-align: left;
            padding-right: 30px;
            font-size: 12px;
          }

          thead th {
            border-bottom: 1px solid #000;
          }
          .fixed { position: fixed; }
          .right-2 { right: 2rem; }
          .top-2 { top: 2rem; }
          .w-30 { width: 30rem; }
          p { margin: 0; }
          li { padding-bottom: 0.5rem; line-height: 1.5; }
          h1 { margin: 0; }
          .mb-5 { margin-bottom: 1.25rem; }
          .mb-3 { margin-bottom: 0.75rem; }
        </style>
      </head>
      <body>
        <div style="grid-template-columns: 1fr 1fr; display: grid; margin: 3rem;">
            <div>
             <div id="content">
          <h1 class="text-2xl mb-3">XML Sitemap</h1>
          <h2>${xmlEscape(title)}</h2>
          ${isNotIndexButHasIndex ? `<p style="font-size: 12px; margin-bottom: 1rem;"><a href="${xmlEscape(fixPath("/sitemap_index.xml"))}">${xmlEscape(fixPath("/sitemap_index.xml"))}</a></p>` : ""}
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &gt; 0">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap Index file contains
              <xsl:value-of select="count(sitemap:sitemapindex/sitemap:sitemap)"/> sitemaps.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  <th width="75%">Sitemap</th>
                  <th width="25%">Last Modified</th>
                </tr>
              </thead>
              <tbody>
                <xsl:for-each select="sitemap:sitemapindex/sitemap:sitemap">
                  <xsl:variable name="sitemapURL">
                    <xsl:value-of select="sitemap:loc"/>
                  </xsl:variable>
                  <tr>
                    <td>
                      <a href="{$sitemapURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    <td>
                      <xsl:value-of
                        select="concat(substring(sitemap:lastmod,0,11),concat(' ', substring(sitemap:lastmod,12,5)),concat(' ', substring(sitemap:lastmod,20,6)))"/>
                    </td>
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
          <xsl:if test="count(sitemap:sitemapindex/sitemap:sitemap) &lt; 1">
            <p class="expl" style="margin-bottom: 1rem;">
              This XML Sitemap contains
              <xsl:value-of select="count(sitemap:urlset/sitemap:url)"/> URLs.
            </p>
            <table id="sitemap" cellpadding="3">
              <thead>
                <tr>
                  ${columns.map((c) => `<th width="${c.width}">${c.label}</th>`).join("\n")}
                </tr>
              </thead>
              <tbody>
                <xsl:variable name="lower" select="'abcdefghijklmnopqrstuvwxyz'"/>
                <xsl:variable name="upper" select="'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"/>
                <xsl:for-each select="sitemap:urlset/sitemap:url">
                  <tr>
                    <td>
                      <xsl:variable name="itemURL">
                        <xsl:value-of select="sitemap:loc"/>
                      </xsl:variable>
                      <a href="{$itemURL}">
                        <xsl:value-of select="sitemap:loc"/>
                      </a>
                    </td>
                    ${columns.filter((c) => c.label !== "URL").map((c) => `<td>
<xsl:value-of select="${c.select}"/>
</td>`).join("\n")}
                  </tr>
                </xsl:for-each>
              </tbody>
            </table>
          </xsl:if>
        </div>
        </div>
                    ${showSidebar ? `<div class="w-30 top-2 shadow rounded p-5 right-2" style="margin: 0 auto;">
                      ${""}
                      ${hasRuntimeErrors ? `<div${""}><p><strong style="color: #dc2626;">Runtime Errors</strong></p><ul style="margin: 1rem 0; padding: 0;">${runtimeErrors}</ul></div>` : ""}
                      ${""}
                    </div>` : ""}
        </div>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
`;
});

function withoutQuery(path) {
  return path.split("?")[0];
}
function createNitroRouteRuleMatcher() {
  const { nitro, app } = useRuntimeConfig();
  const _routeRulesMatcher = toRouteMatcher(
    createRouter$1({
      routes: Object.fromEntries(
        Object.entries(nitro?.routeRules || {}).map(([path, rules]) => [path === "/" ? path : withoutTrailingSlash(path), rules])
      )
    })
  );
  return (pathOrUrl) => {
    const path = pathOrUrl[0] === "/" ? pathOrUrl : parseURL(pathOrUrl, app.baseURL).pathname;
    const pathWithoutQuery = withoutQuery(path);
    return defu({}, ..._routeRulesMatcher.matchAll(
      // radix3 does not support trailing slashes
      withoutBase(pathWithoutQuery === "/" ? pathWithoutQuery : withoutTrailingSlash(pathWithoutQuery), app.baseURL)
    ).reverse());
  };
}

function resolve(s, resolvers) {
  if (typeof s === "undefined" || !resolvers)
    return s;
  s = typeof s === "string" ? s : s.toString();
  if (hasProtocol(s, { acceptRelative: true, strict: false }))
    return resolvers.fixSlashes(s);
  return resolvers.canonicalUrlResolver(s);
}
function removeTrailingSlash(s) {
  return s.replace(/\/(\?|#|$)/, "$1");
}
function preNormalizeEntry(_e, resolvers) {
  const e = typeof _e === "string" ? { loc: _e } : { ..._e };
  if (e.url && !e.loc) {
    e.loc = e.url;
    delete e.url;
  }
  if (typeof e.loc !== "string") {
    e.loc = "";
  }
  e.loc = removeTrailingSlash(e.loc);
  e._abs = hasProtocol(e.loc, { acceptRelative: false, strict: false });
  try {
    e._path = e._abs ? parseURL(e.loc) : parsePath(e.loc);
  } catch (e2) {
    e2._path = null;
  }
  if (e._path) {
    const query = parseQuery(e._path.search);
    const qs = stringifyQuery(query);
    e._relativeLoc = `${encodePath(e._path?.pathname)}${qs.length ? `?${qs}` : ""}`;
    if (e._path.host) {
      e.loc = stringifyParsedURL(e._path);
    } else {
      e.loc = e._relativeLoc;
    }
  } else if (!isEncoded(e.loc)) {
    e.loc = encodeURI(e.loc);
  }
  if (e.loc === "")
    e.loc = `/`;
  e.loc = resolve(e.loc, resolvers);
  e._key = `${e._sitemap || ""}${withoutTrailingSlash(e.loc)}`;
  return e;
}
function isEncoded(url) {
  try {
    return url !== decodeURIComponent(url);
  } catch {
    return false;
  }
}
function normaliseEntry(_e, defaults, resolvers) {
  const e = defu(_e, defaults);
  if (e.lastmod) {
    const date = normaliseDate(e.lastmod);
    if (date)
      e.lastmod = date;
    else
      delete e.lastmod;
  }
  if (!e.lastmod)
    delete e.lastmod;
  e.loc = resolve(e.loc, resolvers);
  if (e.alternatives) {
    const alternatives = e.alternatives.map((a) => ({ ...a }));
    for (let i = 0; i < alternatives.length; i++) {
      const alt = alternatives[i];
      if (typeof alt.href === "string") {
        alt.href = resolve(alt.href, resolvers);
      } else if (typeof alt.href === "object" && alt.href) {
        alt.href = resolve(alt.href.href, resolvers);
      }
    }
    e.alternatives = mergeOnKey(alternatives, "hreflang");
  }
  if (e.images) {
    const images = e.images.map((i) => ({ ...i }));
    for (let i = 0; i < images.length; i++) {
      images[i].loc = resolve(images[i].loc, resolvers);
    }
    e.images = mergeOnKey(images, "loc");
  }
  if (e.videos) {
    const videos = e.videos.map((v) => ({ ...v }));
    for (let i = 0; i < videos.length; i++) {
      if (videos[i].content_loc) {
        videos[i].content_loc = resolve(videos[i].content_loc, resolvers);
      }
    }
    e.videos = mergeOnKey(videos, "content_loc");
  }
  return e;
}
const IS_VALID_W3C_DATE = [
  /(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))/,
  /^\d{4}-[01]\d-[0-3]\d$/,
  /^\d{4}-[01]\d$/,
  /^\d{4}$/
];
function isValidW3CDate(d) {
  return IS_VALID_W3C_DATE.some((r) => r.test(d));
}
function normaliseDate(d) {
  if (typeof d === "string") {
    if (d.includes("T")) {
      const t = d.split("T")[1];
      if (!t.includes("+") && !t.includes("-") && !t.includes("Z")) {
        d += "Z";
      }
    }
    if (!isValidW3CDate(d))
      return false;
    d = new Date(d);
    d.setMilliseconds(0);
    if (Number.isNaN(d.getTime()))
      return false;
  }
  const z = (n) => `0${n}`.slice(-2);
  const date = `${d.getUTCFullYear()}-${z(d.getUTCMonth() + 1)}-${z(d.getUTCDate())}`;
  if (d.getUTCHours() > 0 || d.getUTCMinutes() > 0 || d.getUTCSeconds() > 0) {
    return `${date}T${z(d.getUTCHours())}:${z(d.getUTCMinutes())}:${z(d.getUTCSeconds())}Z`;
  }
  return date;
}

function isValidString(value) {
  return typeof value === "string" && value.trim().length > 0;
}
function parseNumber(value) {
  if (typeof value === "number") return value;
  if (typeof value === "string" && value.trim()) {
    const num = Number.parseFloat(value.trim());
    return Number.isNaN(num) ? void 0 : num;
  }
  return void 0;
}
function parseInteger(value) {
  if (typeof value === "number") return Math.floor(value);
  if (typeof value === "string" && value.trim()) {
    const num = Number.parseInt(value.trim(), 10);
    return Number.isNaN(num) ? void 0 : num;
  }
  return void 0;
}
function extractUrlFromParsedElement(urlElement, warnings) {
  if (!isValidString(urlElement.loc)) {
    warnings.push({
      type: "validation",
      message: "URL entry missing required loc element",
      context: { url: String(urlElement.loc || "undefined") }
    });
    return null;
  }
  const urlObj = { loc: urlElement.loc };
  if (isValidString(urlElement.lastmod)) {
    urlObj.lastmod = urlElement.lastmod;
  }
  if (isValidString(urlElement.changefreq)) {
    const validFreqs = ["always", "hourly", "daily", "weekly", "monthly", "yearly", "never"];
    if (validFreqs.includes(urlElement.changefreq)) {
      urlObj.changefreq = urlElement.changefreq;
    } else {
      warnings.push({
        type: "validation",
        message: "Invalid changefreq value",
        context: { url: urlElement.loc, field: "changefreq", value: urlElement.changefreq }
      });
    }
  }
  const priority = parseNumber(urlElement.priority);
  if (priority !== void 0 && !Number.isNaN(priority)) {
    if (priority < 0 || priority > 1) {
      warnings.push({
        type: "validation",
        message: "Priority value should be between 0.0 and 1.0, clamping to valid range",
        context: { url: urlElement.loc, field: "priority", value: priority }
      });
    }
    urlObj.priority = Math.max(0, Math.min(1, priority));
  } else if (urlElement.priority !== void 0) {
    warnings.push({
      type: "validation",
      message: "Invalid priority value",
      context: { url: urlElement.loc, field: "priority", value: urlElement.priority }
    });
  }
  if (urlElement.image) {
    const images = Array.isArray(urlElement.image) ? urlElement.image : [urlElement.image];
    const validImages = images.map((img) => {
      if (isValidString(img.loc)) {
        return { loc: img.loc };
      } else {
        warnings.push({
          type: "validation",
          message: "Image missing required loc element",
          context: { url: urlElement.loc, field: "image.loc" }
        });
        return null;
      }
    }).filter((img) => img !== null);
    if (validImages.length > 0) {
      urlObj.images = validImages;
    }
  }
  if (urlElement.video) {
    const videos = Array.isArray(urlElement.video) ? urlElement.video : [urlElement.video];
    const validVideos = videos.map((video) => {
      const missingFields = [];
      if (!isValidString(video.title)) missingFields.push("title");
      if (!isValidString(video.thumbnail_loc)) missingFields.push("thumbnail_loc");
      if (!isValidString(video.description)) missingFields.push("description");
      if (!isValidString(video.content_loc)) missingFields.push("content_loc");
      if (missingFields.length > 0) {
        warnings.push({
          type: "validation",
          message: `Video missing required fields: ${missingFields.join(", ")}`,
          context: { url: urlElement.loc, field: "video" }
        });
        return null;
      }
      const videoObj = {
        title: video.title,
        thumbnail_loc: video.thumbnail_loc,
        description: video.description,
        content_loc: video.content_loc
      };
      if (isValidString(video.player_loc)) {
        videoObj.player_loc = video.player_loc;
      }
      const duration = parseInteger(video.duration);
      if (duration !== void 0) {
        videoObj.duration = duration;
      } else if (video.duration !== void 0) {
        warnings.push({
          type: "validation",
          message: "Invalid video duration value",
          context: { url: urlElement.loc, field: "video.duration", value: video.duration }
        });
      }
      if (isValidString(video.expiration_date)) {
        videoObj.expiration_date = video.expiration_date;
      }
      const rating = parseNumber(video.rating);
      if (rating !== void 0) {
        if (rating < 0 || rating > 5) {
          warnings.push({
            type: "validation",
            message: "Video rating should be between 0.0 and 5.0",
            context: { url: urlElement.loc, field: "video.rating", value: rating }
          });
        }
        videoObj.rating = rating;
      } else if (video.rating !== void 0) {
        warnings.push({
          type: "validation",
          message: "Invalid video rating value",
          context: { url: urlElement.loc, field: "video.rating", value: video.rating }
        });
      }
      const viewCount = parseInteger(video.view_count);
      if (viewCount !== void 0) {
        videoObj.view_count = viewCount;
      } else if (video.view_count !== void 0) {
        warnings.push({
          type: "validation",
          message: "Invalid video view_count value",
          context: { url: urlElement.loc, field: "video.view_count", value: video.view_count }
        });
      }
      if (isValidString(video.publication_date)) {
        videoObj.publication_date = video.publication_date;
      }
      if (isValidString(video.family_friendly)) {
        const validValues = ["yes", "no"];
        if (validValues.includes(video.family_friendly)) {
          videoObj.family_friendly = video.family_friendly;
        } else {
          warnings.push({
            type: "validation",
            message: 'Invalid video family_friendly value, should be "yes" or "no"',
            context: { url: urlElement.loc, field: "video.family_friendly", value: video.family_friendly }
          });
        }
      }
      if (isValidString(video.requires_subscription)) {
        const validValues = ["yes", "no"];
        if (validValues.includes(video.requires_subscription)) {
          videoObj.requires_subscription = video.requires_subscription;
        } else {
          warnings.push({
            type: "validation",
            message: 'Invalid video requires_subscription value, should be "yes" or "no"',
            context: { url: urlElement.loc, field: "video.requires_subscription", value: video.requires_subscription }
          });
        }
      }
      if (isValidString(video.live)) {
        const validValues = ["yes", "no"];
        if (validValues.includes(video.live)) {
          videoObj.live = video.live;
        } else {
          warnings.push({
            type: "validation",
            message: 'Invalid video live value, should be "yes" or "no"',
            context: { url: urlElement.loc, field: "video.live", value: video.live }
          });
        }
      }
      if (video.restriction && typeof video.restriction === "object") {
        const restriction = video.restriction;
        if (isValidString(restriction.relationship) && isValidString(restriction["#text"])) {
          const validRelationships = ["allow", "deny"];
          if (validRelationships.includes(restriction.relationship)) {
            videoObj.restriction = {
              relationship: restriction.relationship,
              restriction: restriction["#text"]
            };
          } else {
            warnings.push({
              type: "validation",
              message: 'Invalid video restriction relationship, should be "allow" or "deny"',
              context: { url: urlElement.loc, field: "video.restriction.relationship", value: restriction.relationship }
            });
          }
        }
      }
      if (video.platform && typeof video.platform === "object") {
        const platform = video.platform;
        if (isValidString(platform.relationship) && isValidString(platform["#text"])) {
          const validRelationships = ["allow", "deny"];
          if (validRelationships.includes(platform.relationship)) {
            videoObj.platform = {
              relationship: platform.relationship,
              platform: platform["#text"]
            };
          } else {
            warnings.push({
              type: "validation",
              message: 'Invalid video platform relationship, should be "allow" or "deny"',
              context: { url: urlElement.loc, field: "video.platform.relationship", value: platform.relationship }
            });
          }
        }
      }
      if (video.price) {
        const prices = Array.isArray(video.price) ? video.price : [video.price];
        const validPrices = prices.map((price) => {
          const priceValue = price["#text"];
          if (priceValue == null || typeof priceValue !== "string" && typeof priceValue !== "number") {
            warnings.push({
              type: "validation",
              message: "Video price missing value",
              context: { url: urlElement.loc, field: "video.price" }
            });
            return null;
          }
          const validTypes = ["rent", "purchase", "package", "subscription"];
          if (price.type && !validTypes.includes(price.type)) {
            warnings.push({
              type: "validation",
              message: `Invalid video price type "${price.type}", should be one of: ${validTypes.join(", ")}`,
              context: { url: urlElement.loc, field: "video.price.type", value: price.type }
            });
          }
          return {
            price: String(priceValue),
            currency: price.currency,
            type: price.type
          };
        }).filter((p) => p !== null);
        if (validPrices.length > 0) {
          videoObj.price = validPrices;
        }
      }
      if (video.uploader && typeof video.uploader === "object") {
        const uploader = video.uploader;
        if (isValidString(uploader.info) && isValidString(uploader["#text"])) {
          videoObj.uploader = {
            uploader: uploader["#text"],
            info: uploader.info
          };
        } else {
          warnings.push({
            type: "validation",
            message: "Video uploader missing required info or name",
            context: { url: urlElement.loc, field: "video.uploader" }
          });
        }
      }
      if (video.tag) {
        const tags = Array.isArray(video.tag) ? video.tag : [video.tag];
        const validTags = tags.filter(isValidString);
        if (validTags.length > 0) {
          videoObj.tag = validTags;
        }
      }
      return videoObj;
    }).filter((video) => video !== null);
    if (validVideos.length > 0) {
      urlObj.videos = validVideos;
    }
  }
  if (urlElement.link) {
    const links = Array.isArray(urlElement.link) ? urlElement.link : [urlElement.link];
    const alternatives = links.map((link) => {
      if (link.rel === "alternate" && isValidString(link.hreflang) && isValidString(link.href)) {
        return {
          hreflang: link.hreflang,
          href: link.href
        };
      } else {
        warnings.push({
          type: "validation",
          message: 'Alternative link missing required rel="alternate", hreflang, or href',
          context: { url: urlElement.loc, field: "link" }
        });
        return null;
      }
    }).filter((alt) => alt !== null);
    if (alternatives.length > 0) {
      urlObj.alternatives = alternatives;
    }
  }
  if (urlElement.news && typeof urlElement.news === "object") {
    const news = urlElement.news;
    if (isValidString(news.title) && isValidString(news.publication_date) && news.publication && isValidString(news.publication.name) && isValidString(news.publication.language)) {
      urlObj.news = {
        title: news.title,
        publication_date: news.publication_date,
        publication: {
          name: news.publication.name,
          language: news.publication.language
        }
      };
    } else {
      warnings.push({
        type: "validation",
        message: "News entry missing required fields (title, publication_date, publication.name, publication.language)",
        context: { url: urlElement.loc, field: "news" }
      });
    }
  }
  const filteredUrlObj = Object.fromEntries(
    Object.entries(urlObj).filter(
      ([_, value]) => value != null && (!Array.isArray(value) || value.length > 0)
    )
  );
  return filteredUrlObj;
}
async function parseSitemapXml(xml) {
  const warnings = [];
  if (!xml) {
    throw new Error("Empty XML input provided");
  }
  const { XMLParser } = await import('fast-xml-parser');
  const parser = new XMLParser({
    isArray: (tagName) => ["url", "image", "video", "link", "tag", "price"].includes(tagName),
    removeNSPrefix: true,
    parseAttributeValue: false,
    ignoreAttributes: false,
    attributeNamePrefix: "",
    trimValues: true
  });
  try {
    const parsed = parser.parse(xml);
    if (!parsed?.urlset) {
      throw new Error("XML does not contain a valid urlset element");
    }
    if (!parsed.urlset.url) {
      throw new Error("Sitemap contains no URL entries");
    }
    const urls = Array.isArray(parsed.urlset.url) ? parsed.urlset.url : [parsed.urlset.url];
    const validUrls = urls.map((url) => extractUrlFromParsedElement(url, warnings)).filter((url) => url !== null);
    if (validUrls.length === 0 && urls.length > 0) {
      warnings.push({
        type: "validation",
        message: "No valid URLs found in sitemap after validation"
      });
    }
    return { urls: validUrls, warnings };
  } catch (error) {
    if (error instanceof Error && (error.message === "Empty XML input provided" || error.message === "XML does not contain a valid urlset element" || error.message === "Sitemap contains no URL entries")) {
      throw error;
    }
    throw new Error(`Failed to parse XML: ${error instanceof Error ? error.message : String(error)}`);
  }
}

async function tryFetchWithFallback(url, options, event) {
  const isExternalUrl = !url.startsWith("/");
  if (isExternalUrl) {
    const strategies = [
      // Strategy 1: Use globalThis.$fetch (original approach)
      () => globalThis.$fetch(url, options),
      // Strategy 2: If event is available, try using event context even for external URLs
      event ? () => event.$fetch(url, options) : null,
      // Strategy 3: Use native fetch as last resort
      () => $fetch(url, options)
    ].filter(Boolean);
    let lastError = null;
    for (const strategy of strategies) {
      try {
        return await strategy();
      } catch (error) {
        lastError = error;
        continue;
      }
    }
    throw lastError;
  }
  const fetchContainer = url.startsWith("/") && event ? event : globalThis;
  return await fetchContainer.$fetch(url, options);
}
async function fetchDataSource(input, event) {
  const context = typeof input.context === "string" ? { name: input.context } : input.context || { name: "fetch" };
  const url = typeof input.fetch === "string" ? input.fetch : input.fetch[0];
  const options = typeof input.fetch === "string" ? {} : input.fetch[1];
  const start = Date.now();
  const isExternalUrl = !url.startsWith("/");
  const timeout = isExternalUrl ? 1e4 : options.timeout || 5e3;
  const timeoutController = new AbortController();
  const abortRequestTimeout = setTimeout(() => timeoutController.abort(), timeout);
  try {
    let isMaybeErrorResponse = false;
    const isXmlRequest = parseURL(url).pathname.endsWith(".xml");
    const mergedHeaders = defu(
      options?.headers,
      {
        Accept: isXmlRequest ? "text/xml" : "application/json"
      },
      event ? { host: getRequestHost$1(event, { xForwardedHost: true }) } : {}
    );
    const fetchOptions = {
      ...options,
      responseType: isXmlRequest ? "text" : "json",
      signal: timeoutController.signal,
      headers: mergedHeaders,
      // Use ofetch's built-in retry for external sources
      ...isExternalUrl && {
        retry: 2,
        retryDelay: 200
      },
      // @ts-expect-error untyped
      onResponse({ response }) {
        if (typeof response._data === "string" && response._data.startsWith("<!DOCTYPE html>"))
          isMaybeErrorResponse = true;
      }
    };
    const res = await tryFetchWithFallback(url, fetchOptions, event);
    const timeTakenMs = Date.now() - start;
    if (isMaybeErrorResponse) {
      return {
        ...input,
        context,
        urls: [],
        timeTakenMs,
        error: "Received HTML response instead of JSON"
      };
    }
    let urls = [];
    if (typeof res === "object") {
      urls = res.urls || res;
    } else if (typeof res === "string" && parseURL(url).pathname.endsWith(".xml")) {
      const result = await parseSitemapXml(res);
      urls = result.urls;
    }
    return {
      ...input,
      context,
      timeTakenMs,
      urls
    };
  } catch (_err) {
    const error = _err;
    if (isExternalUrl) {
      const errorInfo = {
        url,
        timeout,
        error: error.message,
        statusCode: error.response?.status,
        statusText: error.response?.statusText,
        method: options?.method || "GET"
      };
      logger.error("Failed to fetch external source.", errorInfo);
    } else {
      logger.error("Failed to fetch source.", { url, error: error.message });
    }
    return {
      ...input,
      context,
      urls: [],
      error: error.message,
      _isFailure: true
      // Mark as failure to prevent caching
    };
  } finally {
    if (abortRequestTimeout) {
      clearTimeout(abortRequestTimeout);
    }
  }
}
function globalSitemapSources() {
  return import('../virtual/global-sources.mjs').then((m) => m.sources);
}
function childSitemapSources(definition) {
  return definition?._hasSourceChunk ? import('../virtual/child-sources.mjs').then((m) => m.sources[definition.sitemapName] || []) : Promise.resolve([]);
}
async function resolveSitemapSources(sources, event) {
  return (await Promise.all(
    sources.map((source) => {
      if (typeof source === "object" && "urls" in source) {
        return {
          timeTakenMs: 0,
          ...source,
          urls: source.urls
        };
      }
      if (source.fetch)
        return fetchDataSource(source, event);
      return {
        ...source,
        error: "Invalid source"
      };
    })
  )).flat();
}

function sortInPlace(urls) {
  urls.sort((a, b) => {
    const aLoc = typeof a === "string" ? a : a.loc;
    const bLoc = typeof b === "string" ? b : b.loc;
    const aSegments = aLoc.split("/").length;
    const bSegments = bLoc.split("/").length;
    if (aSegments !== bSegments) {
      return aSegments - bSegments;
    }
    return aLoc.localeCompare(bLoc, void 0, { numeric: true });
  });
  return urls;
}

function parseChunkInfo(sitemapName, sitemaps, defaultChunkSize) {
  defaultChunkSize = defaultChunkSize || 1e3;
  if (typeof sitemaps.chunks !== "undefined" && !Number.isNaN(Number(sitemapName))) {
    return {
      isChunked: true,
      baseSitemapName: "sitemap",
      chunkIndex: Number(sitemapName),
      chunkSize: defaultChunkSize
    };
  }
  if (sitemapName.includes("-")) {
    const parts = sitemapName.split("-");
    const lastPart = parts.pop();
    if (!Number.isNaN(Number(lastPart))) {
      const baseSitemapName = parts.join("-");
      const baseSitemap = sitemaps[baseSitemapName];
      if (baseSitemap && (baseSitemap.chunks || baseSitemap._isChunking)) {
        const chunkSize = typeof baseSitemap.chunks === "number" ? baseSitemap.chunks : baseSitemap.chunkSize || defaultChunkSize;
        return {
          isChunked: true,
          baseSitemapName,
          chunkIndex: Number(lastPart),
          chunkSize
        };
      }
    }
  }
  return {
    isChunked: false,
    baseSitemapName: sitemapName,
    chunkIndex: void 0,
    chunkSize: defaultChunkSize
  };
}
function getSitemapConfig(sitemapName, sitemaps, defaultChunkSize = 1e3) {
  const chunkInfo = parseChunkInfo(sitemapName, sitemaps, defaultChunkSize);
  if (chunkInfo.isChunked) {
    if (chunkInfo.baseSitemapName === "sitemap" && typeof sitemaps.chunks !== "undefined") {
      return {
        ...sitemaps.chunks,
        sitemapName,
        _isChunking: true,
        _chunkSize: chunkInfo.chunkSize
      };
    }
    const baseSitemap = sitemaps[chunkInfo.baseSitemapName];
    if (baseSitemap) {
      return {
        ...baseSitemap,
        sitemapName,
        // Use the full name with chunk index
        _isChunking: true,
        _chunkSize: chunkInfo.chunkSize
      };
    }
  }
  return sitemaps[sitemapName];
}
function sliceUrlsForChunk(urls, sitemapName, sitemaps, defaultChunkSize = 1e3) {
  const chunkInfo = parseChunkInfo(sitemapName, sitemaps, defaultChunkSize);
  if (chunkInfo.isChunked && chunkInfo.chunkIndex !== void 0) {
    const startIndex = chunkInfo.chunkIndex * chunkInfo.chunkSize;
    const endIndex = (chunkInfo.chunkIndex + 1) * chunkInfo.chunkSize;
    return urls.slice(startIndex, endIndex);
  }
  return urls;
}

function escapeValueForXml(value) {
  if (value === true || value === false)
    return value ? "yes" : "no";
  return xmlEscape(String(value));
}
const URLSET_OPENING_TAG = '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:video="http://www.google.com/schemas/sitemap-video/1.1" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
function buildUrlXml(url) {
  const capacity = 50;
  const parts = Array.from({ length: capacity });
  let partIndex = 0;
  parts[partIndex++] = "    <url>";
  if (url.loc) {
    parts[partIndex++] = `        <loc>${escapeValueForXml(url.loc)}</loc>`;
  }
  if (url.lastmod) {
    parts[partIndex++] = `        <lastmod>${url.lastmod}</lastmod>`;
  }
  if (url.changefreq) {
    parts[partIndex++] = `        <changefreq>${url.changefreq}</changefreq>`;
  }
  if (url.priority !== void 0) {
    const priorityValue = Number.parseFloat(String(url.priority));
    const formattedPriority = priorityValue % 1 === 0 ? String(priorityValue) : priorityValue.toFixed(1);
    parts[partIndex++] = `        <priority>${formattedPriority}</priority>`;
  }
  const keys = Object.keys(url).filter((k) => !k.startsWith("_") && !["loc", "lastmod", "changefreq", "priority"].includes(k));
  for (const key of keys) {
    const value = url[key];
    if (value === void 0 || value === null) continue;
    switch (key) {
      case "alternatives":
        if (Array.isArray(value) && value.length > 0) {
          for (const alt of value) {
            const attrs = Object.entries(alt).map(([k, v]) => `${k}="${escapeValueForXml(v)}"`).join(" ");
            parts[partIndex++] = `        <xhtml:link rel="alternate" ${attrs} />`;
          }
        }
        break;
      case "images":
        if (Array.isArray(value) && value.length > 0) {
          for (const img of value) {
            parts[partIndex++] = "        <image:image>";
            parts[partIndex++] = `            <image:loc>${escapeValueForXml(img.loc)}</image:loc>`;
            if (img.title) parts[partIndex++] = `            <image:title>${escapeValueForXml(img.title)}</image:title>`;
            if (img.caption) parts[partIndex++] = `            <image:caption>${escapeValueForXml(img.caption)}</image:caption>`;
            if (img.geo_location) parts[partIndex++] = `            <image:geo_location>${escapeValueForXml(img.geo_location)}</image:geo_location>`;
            if (img.license) parts[partIndex++] = `            <image:license>${escapeValueForXml(img.license)}</image:license>`;
            parts[partIndex++] = "        </image:image>";
          }
        }
        break;
      case "videos":
        if (Array.isArray(value) && value.length > 0) {
          for (const video of value) {
            parts[partIndex++] = "        <video:video>";
            parts[partIndex++] = `            <video:title>${escapeValueForXml(video.title)}</video:title>`;
            if (video.thumbnail_loc) {
              parts[partIndex++] = `            <video:thumbnail_loc>${escapeValueForXml(video.thumbnail_loc)}</video:thumbnail_loc>`;
            }
            parts[partIndex++] = `            <video:description>${escapeValueForXml(video.description)}</video:description>`;
            if (video.content_loc) {
              parts[partIndex++] = `            <video:content_loc>${escapeValueForXml(video.content_loc)}</video:content_loc>`;
            }
            if (video.player_loc) {
              const attrs = video.player_loc.allow_embed ? ' allow_embed="yes"' : "";
              const autoplay = video.player_loc.autoplay ? ' autoplay="yes"' : "";
              parts[partIndex++] = `            <video:player_loc${attrs}${autoplay}>${escapeValueForXml(video.player_loc)}</video:player_loc>`;
            }
            if (video.duration !== void 0) {
              parts[partIndex++] = `            <video:duration>${video.duration}</video:duration>`;
            }
            if (video.expiration_date) {
              parts[partIndex++] = `            <video:expiration_date>${video.expiration_date}</video:expiration_date>`;
            }
            if (video.rating !== void 0) {
              parts[partIndex++] = `            <video:rating>${video.rating}</video:rating>`;
            }
            if (video.view_count !== void 0) {
              parts[partIndex++] = `            <video:view_count>${video.view_count}</video:view_count>`;
            }
            if (video.publication_date) {
              parts[partIndex++] = `            <video:publication_date>${video.publication_date}</video:publication_date>`;
            }
            if (video.family_friendly !== void 0) {
              parts[partIndex++] = `            <video:family_friendly>${video.family_friendly === "yes" || video.family_friendly === true ? "yes" : "no"}</video:family_friendly>`;
            }
            if (video.restriction) {
              const relationship = video.restriction.relationship || "allow";
              parts[partIndex++] = `            <video:restriction relationship="${relationship}">${escapeValueForXml(video.restriction.restriction)}</video:restriction>`;
            }
            if (video.platform) {
              const relationship = video.platform.relationship || "allow";
              parts[partIndex++] = `            <video:platform relationship="${relationship}">${escapeValueForXml(video.platform.platform)}</video:platform>`;
            }
            if (video.requires_subscription !== void 0) {
              parts[partIndex++] = `            <video:requires_subscription>${video.requires_subscription === "yes" || video.requires_subscription === true ? "yes" : "no"}</video:requires_subscription>`;
            }
            if (video.price) {
              const prices = Array.isArray(video.price) ? video.price : [video.price];
              for (const price of prices) {
                const attrs = [];
                if (price.currency) attrs.push(`currency="${price.currency}"`);
                if (price.type) attrs.push(`type="${price.type}"`);
                const attrsStr = attrs.length > 0 ? " " + attrs.join(" ") : "";
                parts[partIndex++] = `            <video:price${attrsStr}>${escapeValueForXml(price.price)}</video:price>`;
              }
            }
            if (video.uploader) {
              const info = video.uploader.info ? ` info="${escapeValueForXml(video.uploader.info)}"` : "";
              parts[partIndex++] = `            <video:uploader${info}>${escapeValueForXml(video.uploader.uploader)}</video:uploader>`;
            }
            if (video.live !== void 0) {
              parts[partIndex++] = `            <video:live>${video.live === "yes" || video.live === true ? "yes" : "no"}</video:live>`;
            }
            if (video.tag) {
              const tags = Array.isArray(video.tag) ? video.tag : [video.tag];
              for (const tag of tags) {
                parts[partIndex++] = `            <video:tag>${escapeValueForXml(tag)}</video:tag>`;
              }
            }
            if (video.category) {
              parts[partIndex++] = `            <video:category>${escapeValueForXml(video.category)}</video:category>`;
            }
            if (video.gallery_loc) {
              const title = video.gallery_loc.title ? ` title="${escapeValueForXml(video.gallery_loc.title)}"` : "";
              parts[partIndex++] = `            <video:gallery_loc${title}>${escapeValueForXml(video.gallery_loc)}</video:gallery_loc>`;
            }
            parts[partIndex++] = "        </video:video>";
          }
        }
        break;
      case "news":
        if (value) {
          parts[partIndex++] = "        <news:news>";
          parts[partIndex++] = "            <news:publication>";
          parts[partIndex++] = `                <news:name>${escapeValueForXml(value.publication.name)}</news:name>`;
          parts[partIndex++] = `                <news:language>${escapeValueForXml(value.publication.language)}</news:language>`;
          parts[partIndex++] = "            </news:publication>";
          if (value.title) {
            parts[partIndex++] = `            <news:title>${escapeValueForXml(value.title)}</news:title>`;
          }
          if (value.publication_date) {
            parts[partIndex++] = `            <news:publication_date>${value.publication_date}</news:publication_date>`;
          }
          if (value.access) {
            parts[partIndex++] = `            <news:access>${value.access}</news:access>`;
          }
          if (value.genres) {
            parts[partIndex++] = `            <news:genres>${escapeValueForXml(value.genres)}</news:genres>`;
          }
          if (value.keywords) {
            parts[partIndex++] = `            <news:keywords>${escapeValueForXml(value.keywords)}</news:keywords>`;
          }
          if (value.stock_tickers) {
            parts[partIndex++] = `            <news:stock_tickers>${escapeValueForXml(value.stock_tickers)}</news:stock_tickers>`;
          }
          parts[partIndex++] = "        </news:news>";
        }
        break;
    }
  }
  parts[partIndex++] = "    </url>";
  return parts.slice(0, partIndex).join("\n");
}
function urlsToXml(urls, resolvers, { version, xsl, credits, minify }, errorInfo) {
  const estimatedSize = urls.length + 5;
  const xmlParts = Array.from({ length: estimatedSize });
  let partIndex = 0;
  let xslHref = xsl ? resolvers.relativeBaseUrlResolver(xsl) : false;
  if (xslHref && errorInfo && errorInfo.messages.length > 0) {
    xslHref = withQuery(xslHref, {
      errors: "true",
      error_messages: errorInfo.messages,
      error_urls: errorInfo.urls
    });
  }
  if (xslHref) {
    xmlParts[partIndex++] = `<?xml version="1.0" encoding="UTF-8"?><?xml-stylesheet type="text/xsl" href="${escapeValueForXml(xslHref)}"?>`;
  } else {
    xmlParts[partIndex++] = '<?xml version="1.0" encoding="UTF-8"?>';
  }
  xmlParts[partIndex++] = URLSET_OPENING_TAG;
  for (const url of urls) {
    xmlParts[partIndex++] = buildUrlXml(url);
  }
  xmlParts[partIndex++] = "</urlset>";
  if (credits) {
    xmlParts[partIndex++] = `<!-- XML Sitemap generated by @nuxtjs/sitemap v${version} at ${(/* @__PURE__ */ new Date()).toISOString()} -->`;
  }
  const xmlContent = xmlParts.slice(0, partIndex);
  if (minify) {
    return xmlContent.join("").replace(/(?<!<[^>]*)\s(?![^<]*>)/g, "");
  }
  return xmlContent.join("\n");
}

function resolveSitemapEntries(sitemap, urls, runtimeConfig, resolvers) {
  const {
    autoI18n,
    isI18nMapped
  } = runtimeConfig;
  const filterPath = createPathFilter({
    include: sitemap.include,
    exclude: sitemap.exclude
  });
  const _urls = urls.map((_e) => {
    const e = preNormalizeEntry(_e, resolvers);
    if (!e.loc || !filterPath(e.loc))
      return false;
    return e;
  }).filter(Boolean);
  let validI18nUrlsForTransform = [];
  const withoutPrefixPaths = {};
  if (autoI18n && autoI18n.strategy !== "no_prefix") {
    const localeCodes = autoI18n.locales.map((l) => l.code);
    validI18nUrlsForTransform = _urls.map((_e, i) => {
      if (_e._abs)
        return false;
      const split = splitForLocales(_e._relativeLoc, localeCodes);
      let localeCode = split[0];
      const pathWithoutPrefix = split[1];
      if (!localeCode)
        localeCode = autoI18n.defaultLocale;
      const e = _e;
      e._pathWithoutPrefix = pathWithoutPrefix;
      const locale = autoI18n.locales.find((l) => l.code === localeCode);
      if (!locale)
        return false;
      e._locale = locale;
      e._index = i;
      e._key = `${e._sitemap || ""}${e._path?.pathname || "/"}${e._path.search}`;
      withoutPrefixPaths[pathWithoutPrefix] = withoutPrefixPaths[pathWithoutPrefix] || [];
      if (!withoutPrefixPaths[pathWithoutPrefix].some((e2) => e2._locale.code === locale.code))
        withoutPrefixPaths[pathWithoutPrefix].push(e);
      return e;
    }).filter(Boolean);
    for (const e of validI18nUrlsForTransform) {
      if (!e._i18nTransform && !e.alternatives?.length) {
        const alternatives = withoutPrefixPaths[e._pathWithoutPrefix].map((u) => {
          const entries = [];
          if (u._locale.code === autoI18n.defaultLocale) {
            entries.push({
              href: u.loc,
              hreflang: "x-default"
            });
          }
          entries.push({
            href: u.loc,
            hreflang: u._locale._hreflang || autoI18n.defaultLocale
          });
          return entries;
        }).flat().filter(Boolean);
        if (alternatives.length)
          e.alternatives = alternatives;
      } else if (e._i18nTransform) {
        delete e._i18nTransform;
        if (autoI18n.strategy === "no_prefix") ;
        if (autoI18n.differentDomains) {
          e.alternatives = [
            {
              // apply default locale domain
              ...autoI18n.locales.find((l) => [l.code, l.language].includes(autoI18n.defaultLocale)),
              code: "x-default"
            },
            ...autoI18n.locales.filter((l) => !!l.domain)
          ].map((locale) => {
            return {
              hreflang: locale._hreflang,
              href: joinURL(withHttps(locale.domain), e._pathWithoutPrefix)
            };
          });
        } else {
          for (const l of autoI18n.locales) {
            let loc = e._pathWithoutPrefix;
            if (autoI18n.pages) {
              const pageKey = e._pathWithoutPrefix.replace(/^\//, "").replace(/\/index$/, "") || "index";
              const pageMappings = autoI18n.pages[pageKey];
              if (pageMappings && pageMappings[l.code] !== void 0) {
                const customPath = pageMappings[l.code];
                if (customPath === false)
                  continue;
                if (typeof customPath === "string")
                  loc = customPath.startsWith("/") ? customPath : `/${customPath}`;
              } else if (!autoI18n.differentDomains && !(["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy) && l.code === autoI18n.defaultLocale)) {
                loc = joinURL(`/${l.code}`, e._pathWithoutPrefix);
              }
            } else {
              if (!autoI18n.differentDomains && !(["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy) && l.code === autoI18n.defaultLocale))
                loc = joinURL(`/${l.code}`, e._pathWithoutPrefix);
            }
            const _sitemap = isI18nMapped ? l._sitemap : void 0;
            const newEntry = preNormalizeEntry({
              _sitemap,
              ...e,
              _index: void 0,
              _key: `${_sitemap || ""}${loc || "/"}${e._path.search}`,
              _locale: l,
              loc,
              alternatives: [{ code: "x-default", _hreflang: "x-default" }, ...autoI18n.locales].map((locale) => {
                const code = locale.code === "x-default" ? autoI18n.defaultLocale : locale.code;
                const isDefault = locale.code === "x-default" || locale.code === autoI18n.defaultLocale;
                let href = e._pathWithoutPrefix;
                if (autoI18n.pages) {
                  const pageKey = e._pathWithoutPrefix.replace(/^\//, "").replace(/\/index$/, "") || "index";
                  const pageMappings = autoI18n.pages[pageKey];
                  if (pageMappings && pageMappings[code] !== void 0) {
                    const customPath = pageMappings[code];
                    if (customPath === false)
                      return false;
                    if (typeof customPath === "string")
                      href = customPath.startsWith("/") ? customPath : `/${customPath}`;
                  } else if (autoI18n.strategy === "prefix") {
                    href = joinURL("/", code, e._pathWithoutPrefix);
                  } else if (["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy)) {
                    if (!isDefault) {
                      href = joinURL("/", code, e._pathWithoutPrefix);
                    }
                  }
                } else {
                  if (autoI18n.strategy === "prefix") {
                    href = joinURL("/", code, e._pathWithoutPrefix);
                  } else if (["prefix_and_default", "prefix_except_default"].includes(autoI18n.strategy)) {
                    if (!isDefault) {
                      href = joinURL("/", code, e._pathWithoutPrefix);
                    }
                  }
                }
                if (!filterPath(href))
                  return false;
                return {
                  hreflang: locale._hreflang,
                  href
                };
              }).filter(Boolean)
            }, resolvers);
            if (e._locale.code === newEntry._locale.code) {
              _urls[e._index] = newEntry;
              e._index = void 0;
            } else {
              _urls.push(newEntry);
            }
          }
        }
      }
      if (isI18nMapped) {
        e._sitemap = e._sitemap || e._locale._sitemap;
        e._key = `${e._sitemap || ""}${e.loc || "/"}${e._path.search}`;
      }
      if (e._index)
        _urls[e._index] = e;
    }
  }
  return _urls;
}
async function buildSitemapUrls(sitemap, resolvers, runtimeConfig, nitro) {
  const {
    sitemaps,
    // enhancing
    autoI18n,
    isI18nMapped,
    isMultiSitemap,
    // sorting
    sortEntries,
    // chunking
    defaultSitemapsChunkSize
  } = runtimeConfig;
  const chunkInfo = parseChunkInfo(sitemap.sitemapName, sitemaps, defaultSitemapsChunkSize);
  function maybeSort(urls2) {
    return sortEntries ? sortInPlace(urls2) : urls2;
  }
  function maybeSlice(urls2) {
    return sliceUrlsForChunk(urls2, sitemap.sitemapName, sitemaps, defaultSitemapsChunkSize);
  }
  if (autoI18n?.differentDomains) {
    const domain = autoI18n.locales.find((e) => [e.language, e.code].includes(sitemap.sitemapName))?.domain;
    if (domain) {
      const _tester = resolvers.canonicalUrlResolver;
      resolvers.canonicalUrlResolver = (path) => resolveSitePath(path, {
        absolute: true,
        withBase: false,
        siteUrl: withHttps(domain),
        trailingSlash: _tester("/test/").endsWith("/"),
        base: "/"
      });
    }
  }
  let effectiveSitemap = sitemap;
  const baseSitemapName = chunkInfo.baseSitemapName;
  if (chunkInfo.isChunked && baseSitemapName !== sitemap.sitemapName && sitemaps[baseSitemapName]) {
    effectiveSitemap = sitemaps[baseSitemapName];
  }
  let sourcesInput = effectiveSitemap.includeAppSources ? await globalSitemapSources() : [];
  sourcesInput.push(...await childSitemapSources(effectiveSitemap));
  if (nitro && resolvers.event) {
    const ctx = {
      event: resolvers.event,
      sitemapName: baseSitemapName,
      sources: sourcesInput
    };
    await nitro.hooks.callHook("sitemap:sources", ctx);
    sourcesInput = ctx.sources;
  }
  const sources = await resolveSitemapSources(sourcesInput, resolvers.event);
  const failedSources = sources.filter((source) => source.error && source._isFailure).map((source) => ({
    url: typeof source.fetch === "string" ? source.fetch : source.fetch?.[0] || "unknown",
    error: source.error || "Unknown error"
  }));
  const resolvedCtx = {
    urls: sources.flatMap((s) => s.urls),
    sitemapName: sitemap.sitemapName,
    event: resolvers.event
  };
  await nitro?.hooks.callHook("sitemap:input", resolvedCtx);
  const enhancedUrls = resolveSitemapEntries(sitemap, resolvedCtx.urls, { autoI18n, isI18nMapped }, resolvers);
  const filteredUrls = enhancedUrls.filter((e) => {
    if (isMultiSitemap && e._sitemap && sitemap.sitemapName)
      return e._sitemap === sitemap.sitemapName;
    return true;
  });
  const sortedUrls = maybeSort(filteredUrls);
  const urls = maybeSlice(sortedUrls);
  return { urls, failedSources };
}

function useNitroUrlResolvers(e) {
  const canonicalQuery = getQuery(e).canonical;
  const isShowingCanonical = typeof canonicalQuery !== "undefined" && canonicalQuery !== "false";
  const siteConfig = useSiteConfig(e);
  return {
    event: e,
    fixSlashes: (path) => fixSlashes(siteConfig.trailingSlash, path),
    // we need these as they depend on the nitro event
    canonicalUrlResolver: createSitePathResolver(e, {
      canonical: isShowingCanonical || true,
      absolute: true,
      withBase: true
    }),
    relativeBaseUrlResolver: createSitePathResolver(e, { absolute: false, withBase: true })
  };
}
async function buildSitemapXml(event, definition, resolvers, runtimeConfig) {
  const { sitemapName } = definition;
  const nitro = useNitroApp();
  const { urls: sitemapUrls, failedSources } = await buildSitemapUrls(definition, resolvers, runtimeConfig, nitro);
  const routeRuleMatcher = createNitroRouteRuleMatcher();
  const { autoI18n } = runtimeConfig;
  let validCount = 0;
  for (let i = 0; i < sitemapUrls.length; i++) {
    const u = sitemapUrls[i];
    const path = u._path?.pathname || u.loc;
    let routeRules = routeRuleMatcher(path);
    if (autoI18n?.locales && autoI18n?.strategy !== "no_prefix") {
      const match = splitForLocales(path, autoI18n.locales.map((l) => l.code));
      const pathWithoutPrefix = match[1];
      if (pathWithoutPrefix && pathWithoutPrefix !== path)
        routeRules = defu(routeRules, routeRuleMatcher(pathWithoutPrefix));
    }
    if (routeRules.sitemap === false)
      continue;
    if (typeof routeRules.robots !== "undefined" && !routeRules.robots)
      continue;
    const hasRobotsDisabled = Object.entries(routeRules.headers || {}).some(([name, value]) => name.toLowerCase() === "x-robots-tag" && value.toLowerCase().includes("noindex"));
    if (routeRules.redirect || hasRobotsDisabled)
      continue;
    sitemapUrls[validCount++] = routeRules.sitemap ? defu(u, routeRules.sitemap) : u;
  }
  sitemapUrls.length = validCount;
  const locSize = sitemapUrls.length;
  const resolvedCtx = {
    urls: sitemapUrls,
    sitemapName,
    event
  };
  await nitro.hooks.callHook("sitemap:resolved", resolvedCtx);
  if (resolvedCtx.urls.length !== locSize) {
    resolvedCtx.urls = resolvedCtx.urls.map((e) => preNormalizeEntry(e, resolvers));
  }
  const maybeSort = (urls2) => runtimeConfig.sortEntries ? sortInPlace(urls2) : urls2;
  const normalizedPreDedupe = resolvedCtx.urls.map((e) => normaliseEntry(e, definition.defaults, resolvers));
  const urls = maybeSort(mergeOnKey(normalizedPreDedupe, "_key").map((e) => normaliseEntry(e, definition.defaults, resolvers)));
  if (definition._isChunking && definition.sitemapName.includes("-")) {
    const parts = definition.sitemapName.split("-");
    const lastPart = parts.pop();
    if (!Number.isNaN(Number(lastPart))) {
      const chunkIndex = Number(lastPart);
      const baseSitemapName = parts.join("-");
      if (urls.length === 0 && chunkIndex > 0) {
        throw createError$2({
          statusCode: 404,
          message: `Sitemap chunk ${chunkIndex} for "${baseSitemapName}" does not exist.`
        });
      }
    }
  }
  const errorInfo = failedSources.length > 0 ? {
    messages: failedSources.map((f) => f.error),
    urls: failedSources.map((f) => f.url)
  } : void 0;
  const sitemap = urlsToXml(urls, resolvers, runtimeConfig, errorInfo);
  const ctx = { sitemap, sitemapName, event };
  await nitro.hooks.callHook("sitemap:output", ctx);
  return ctx.sitemap;
}
const buildSitemapXmlCached = defineCachedFunction(
  buildSitemapXml,
  {
    name: "sitemap:xml",
    group: "sitemap",
    maxAge: 60 * 10,
    // Default 10 minutes
    base: "sitemap",
    // Use the sitemap storage
    getKey: (event, definition) => {
      const host = getHeader(event, "host") || getHeader(event, "x-forwarded-host") || "";
      const proto = getHeader(event, "x-forwarded-proto") || "https";
      const sitemapName = definition.sitemapName || "default";
      return `${sitemapName}-${proto}-${host}`;
    },
    swr: true
    // Enable stale-while-revalidate
  }
);
async function createSitemap(event, definition, runtimeConfig) {
  const resolvers = useNitroUrlResolvers(event);
  const shouldCache = typeof runtimeConfig.cacheMaxAgeSeconds === "number" && runtimeConfig.cacheMaxAgeSeconds > 0;
  const xml = shouldCache ? await buildSitemapXmlCached(event, definition, resolvers, runtimeConfig) : await buildSitemapXml(event, definition, resolvers, runtimeConfig);
  setHeader(event, "Content-Type", "text/xml; charset=UTF-8");
  if (runtimeConfig.cacheMaxAgeSeconds) {
    setHeader(event, "Cache-Control", `public, max-age=${runtimeConfig.cacheMaxAgeSeconds}, s-maxage=${runtimeConfig.cacheMaxAgeSeconds}, stale-while-revalidate=3600`);
    const now = /* @__PURE__ */ new Date();
    setHeader(event, "X-Sitemap-Generated", now.toISOString());
    setHeader(event, "X-Sitemap-Cache-Duration", `${runtimeConfig.cacheMaxAgeSeconds}s`);
    const expiryTime = new Date(now.getTime() + runtimeConfig.cacheMaxAgeSeconds * 1e3);
    setHeader(event, "X-Sitemap-Cache-Expires", expiryTime.toISOString());
    const remainingSeconds = Math.floor((expiryTime.getTime() - now.getTime()) / 1e3);
    setHeader(event, "X-Sitemap-Cache-Remaining", `${remainingSeconds}s`);
  } else {
    setHeader(event, "Cache-Control", `no-cache, no-store`);
  }
  event.context._isSitemap = true;
  return xml;
}

const _D5sQ8g = defineEventHandler$1(async (e) => {
  const runtimeConfig = useSitemapRuntimeConfig();
  const { sitemaps } = runtimeConfig;
  if ("index" in sitemaps) {
    return sendRedirect$1(e, withBase("/sitemap_index.xml", useRuntimeConfig().app.baseURL), 301);
  }
  return createSitemap(e, Object.values(sitemaps)[0], runtimeConfig);
});

const _thVScw = eventHandler$1(async (event) => {
  const { code, lang, theme: themeString, options: optionsStr } = getQuery(event);
  const theme = JSON.parse(themeString);
  const options = optionsStr ? JSON.parse(optionsStr) : {};
  const highlighter = await import('../build/mdc-highlighter.mjs').then((m) => m.default);
  return await highlighter(code, lang, theme, options);
});

function defineNitroPlugin(def) {
  return def;
}

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler$1(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send$1(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send$1(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

function baseURL() {
  return useRuntimeConfig().app.baseURL;
}
function buildAssetsDir() {
  return useRuntimeConfig().app.buildAssetsDir;
}
function buildAssetsURL(...path) {
  return joinRelativeURL(publicAssetsURL(), buildAssetsDir(), ...path);
}
function publicAssetsURL(...path) {
  const app = useRuntimeConfig().app;
  const publicBase = app.cdnURL || app.baseURL;
  return path.length ? joinRelativeURL(publicBase, ...path) : publicBase;
}

function isTag(vnode, tag) {
  if (vnode.type === tag) {
    return true;
  }
  if (typeof vnode.type === "object" && vnode.type.tag === tag) {
    return true;
  }
  if (vnode.tag === tag) {
    return true;
  }
  return false;
}
function isText(vnode) {
  return isTag(vnode, "text") || isTag(vnode, Symbol.for("v-txt"));
}
function nodeChildren(node) {
  if (Array.isArray(node.children) || typeof node.children === "string") {
    return node.children;
  }
  if (typeof node.children?.default === "function") {
    return node.children.default();
  }
  return [];
}
function nodeTextContent(node) {
  if (!node) {
    return "";
  }
  if (Array.isArray(node)) {
    return node.map(nodeTextContent).join("");
  }
  if (isText(node)) {
    return node.value || node.children || "";
  }
  const children = nodeChildren(node);
  if (Array.isArray(children)) {
    return children.map(nodeTextContent).filter(Boolean).join("");
  }
  return "";
}

const useProcessorPlugins = async (processor, plugins = {}) => {
  const toUse = Object.entries(plugins).filter((p) => p[1] !== false);
  for (const plugin of toUse) {
    const instance = plugin[1].instance || await import(
      /* @vite-ignore */
      plugin[0]
    ).then((m) => m.default || m);
    processor.use(instance, plugin[1].options);
  }
};

function emphasis(state, node) {
  const result = {
    type: "element",
    tagName: "em",
    properties: node.attributes || {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

function parseThematicBlock(lang) {
  if (!lang?.trim()) {
    return {
      language: void 0,
      highlights: void 0,
      filename: void 0,
      meta: void 0
    };
  }
  const languageMatches = lang.replace(/[{|[](.+)/, "").match(/^[^ \t]+(?=[ \t]|$)/);
  const highlightTokensMatches = lang.match(/\{([^}]*)\}/);
  const filenameMatches = lang.match(/\[(.*)\]/);
  const meta = lang.replace(languageMatches?.[0] ?? "", "").replace(highlightTokensMatches?.[0] ?? "", "").replace(filenameMatches?.[0] ?? "", "").trim();
  let filename = void 0;
  if (filenameMatches?.[1]) {
    filename = filenameMatches[1].replace(/\\([[\]{}().*+?^$|])/g, "$1");
  }
  return {
    language: languageMatches?.[0] || void 0,
    highlights: parseHighlightedLines(highlightTokensMatches?.[1] || void 0),
    // https://github.com/nuxt/content/pull/2169
    filename,
    meta
  };
}
function parseHighlightedLines(lines) {
  const lineArray = String(lines || "").split(",").filter(Boolean).flatMap((line) => {
    const [start, end] = line.trim().split("-").map((a) => Number(a.trim()));
    return Array.from({ length: (end || start) - start + 1 }).map((_, i) => start + i);
  });
  return lineArray.length ? lineArray : void 0;
}
const TAG_NAME_REGEXP = /^<\/?([\w-]+)(\s[^>]*?)?\/?>/;
function getTagName(value) {
  const result = String(value).match(TAG_NAME_REGEXP);
  return result && result[1];
}

const code = (state, node) => {
  const lang = (node.lang || "") + " " + (node.meta || "");
  const { language = "text", highlights, filename, meta } = parseThematicBlock(lang);
  const value = node.value ? detab(node.value + "\n") : "";
  let result = {
    type: "element",
    tagName: "code",
    properties: { __ignoreMap: "" },
    children: [{ type: "text", value }]
  };
  if (meta) {
    result.data = {
      meta
    };
  }
  state.patch(node, result);
  result = state.applyData(node, result);
  const properties = {
    language: language || "text",
    filename,
    highlights,
    meta,
    code: value
  };
  if (language) {
    properties.className = ["language-" + language];
  }
  result = { type: "element", tagName: "pre", properties, children: [result] };
  state.patch(node, result);
  return result;
};

function html(state, node) {
  const tagName = getTagName(node.value);
  if (tagName && /[A-Z]/.test(tagName)) {
    node.value = node.value.replace(tagName, kebabCase(tagName));
  }
  if (state.dangerous || state.options?.allowDangerousHtml) {
    const result = { type: "raw", value: node.value };
    state.patch(node, result);
    return state.applyData(node, result);
  }
  return void 0;
}

function link(state, node) {
  const properties = {
    ...node.attributes || {},
    href: normalizeUri(node.url)
  };
  if (node.title !== null && node.title !== void 0) {
    properties.title = node.title;
  }
  const result = {
    type: "element",
    tagName: "a",
    properties,
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

function list(state, node) {
  const properties = {};
  const results = state.all(node);
  let index = -1;
  if (typeof node.start === "number" && node.start !== 1) {
    properties.start = node.start;
  }
  while (++index < results.length) {
    const child = results[index];
    if (child.type === "element" && child.tagName === "li" && child.properties && Array.isArray(child.properties.className) && child.properties.className.includes("task-list-item")) {
      properties.className = ["contains-task-list"];
      break;
    }
  }
  if ((node.children || []).some((child) => typeof child.checked === "boolean")) {
    properties.className = ["contains-task-list"];
  }
  const result = {
    type: "element",
    tagName: node.ordered ? "ol" : "ul",
    properties,
    children: state.wrap(results, true)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

const htmlTags = [
  "a",
  "abbr",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "bdi",
  "bdo",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "math",
  "menu",
  "menuitem",
  "meta",
  "meter",
  "nav",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "script",
  "section",
  "select",
  "slot",
  "small",
  "source",
  "span",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
];

function paragraph(state, node) {
  if (node.children && node.children[0] && node.children[0].type === "html") {
    const tagName = kebabCase(getTagName(node.children[0].value) || "div");
    if (!htmlTags.includes(tagName)) {
      return state.all(node);
    }
  }
  const result = {
    type: "element",
    tagName: "p",
    properties: {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

function image(state, node) {
  const properties = { ...node.attributes, src: normalizeUri(node.url) };
  if (node.alt !== null && node.alt !== void 0) {
    properties.alt = node.alt;
  }
  if (node.title !== null && node.title !== void 0) {
    properties.title = node.title;
  }
  const result = { type: "element", tagName: "img", properties, children: [] };
  state.patch(node, result);
  return state.applyData(node, result);
}

function strong(state, node) {
  const result = {
    type: "element",
    tagName: "strong",
    properties: node.attributes || {},
    children: state.all(node)
  };
  state.patch(node, result);
  return state.applyData(node, result);
}

function inlineCode(state, node) {
  const language = node.attributes?.language || node.attributes?.lang;
  const text = { type: "text", value: node.value.replace(/\r?\n|\r/g, " ") };
  state.patch(node, text);
  const result = {
    type: "element",
    tagName: "code",
    properties: node.attributes || {},
    children: [text]
  };
  const classes = (result.properties.class || "").split(" ");
  delete result.properties.class;
  if (language) {
    result.properties.language = language;
    delete result.properties.lang;
    classes.push("language-" + language);
  }
  result.properties.className = classes.join(" ");
  state.patch(node, result);
  return state.applyData(node, result);
}

function containerComponent(state, node) {
  const result = {
    type: "element",
    tagName: node.name,
    properties: {
      ...node.attributes,
      ...node.data?.hProperties
    },
    children: state.all(node)
  };
  state.patch(node, result);
  result.attributes = node.attributes;
  result.fmAttributes = node.fmAttributes;
  return result;
}

const handlers$1 = {
  emphasis,
  code,
  link,
  paragraph,
  html,
  list,
  image,
  strong,
  inlineCode,
  containerComponent
};

const defaults = {
  remark: {
    plugins: {
      "remark-mdc": {
        instance: remarkMDC
      },
      "remark-gfm": {
        instance: remarkGFM
      }
    }
  },
  rehype: {
    options: {
      handlers: handlers$1,
      allowDangerousHtml: true
    },
    plugins: {
      "rehype-external-links": {
        instance: rehypeExternalLinks
      },
      "rehype-sort-attribute-values": {
        instance: rehypeSortAttributeValues
      },
      "rehype-sort-attributes": {
        instance: rehypeSortAttributes
      },
      "rehype-raw": {
        instance: rehypeRaw,
        options: {
          passThrough: ["element"]
        }
      }
    }
  },
  highlight: false,
  toc: {
    searchDepth: 2,
    depth: 2
  }
};

function flattenNodeText(node) {
  if (node.type === "comment") {
    return "";
  }
  if (node.type === "text") {
    return node.value || "";
  } else {
    return (node.children || []).reduce((text, child) => {
      return text.concat(flattenNodeText(child));
    }, "");
  }
}
function flattenNode(node, maxDepth = 2, _depth = 0) {
  if (!Array.isArray(node.children) || _depth === maxDepth) {
    return [node];
  }
  return [
    node,
    ...node.children.reduce((acc, child) => acc.concat(flattenNode(child, maxDepth, _depth + 1)), [])
  ];
}

const TOC_TAGS = ["h2", "h3", "h4", "h5", "h6"];
const TOC_TAGS_DEPTH = TOC_TAGS.reduce((tags, tag) => {
  tags[tag] = Number(tag.charAt(tag.length - 1));
  return tags;
}, {});
const getHeaderDepth = (node) => TOC_TAGS_DEPTH[node.tag];
const getTocTags = (depth) => {
  if (depth < 1 || depth > 5) {
    console.log(`\`toc.depth\` is set to ${depth}. It should be a number between 1 and 5. `);
    depth = 1;
  }
  return TOC_TAGS.slice(0, depth);
};
function nestHeaders(headers) {
  if (headers.length <= 1) {
    return headers;
  }
  const toc = [];
  let parent;
  headers.forEach((header) => {
    if (!parent || header.depth <= parent.depth) {
      header.children = [];
      parent = header;
      toc.push(header);
    } else {
      parent.children.push(header);
    }
  });
  toc.forEach((header) => {
    if (header.children?.length) {
      header.children = nestHeaders(header.children);
    } else {
      delete header.children;
    }
  });
  return toc;
}
function generateFlatToc(body, options) {
  const { searchDepth, depth, title = "" } = options;
  const tags = getTocTags(depth);
  const headers = flattenNode(body, searchDepth).filter((node) => tags.includes(node.tag || ""));
  const links = headers.map((node) => ({
    id: node.props?.id,
    depth: getHeaderDepth(node),
    text: flattenNodeText(node)
  }));
  return {
    title,
    searchDepth,
    depth,
    links
  };
}
function generateToc(body, options) {
  const toc = generateFlatToc(body, options);
  toc.links = nestHeaders(toc.links);
  return toc;
}

const unsafeLinkPrefix = [
  "javascript:",
  "data:text/html",
  "vbscript:",
  "data:text/javascript",
  "data:text/vbscript",
  "data:text/css",
  "data:text/plain",
  "data:text/xml"
];
function isAnchorLinkAllowed(value) {
  const decodedUrl = decodeURIComponent(value);
  const urlSanitized = decodedUrl.replace(/&#x([0-9a-f]+);?/gi, "").replace(/&#(\d+);?/g, "").replace(/&[a-z]+;?/gi, "");
  try {
    const url = new URL(urlSanitized, "http://example.com");
    if (url.origin === "http://example.com") {
      return true;
    }
    if (unsafeLinkPrefix.some((prefix) => url.protocol.toLowerCase().startsWith(prefix))) {
      return false;
    }
  } catch {
    return false;
  }
  return true;
}
const validateProp = (attribute, value) => {
  if (attribute.startsWith("on")) {
    return false;
  }
  if (attribute === "href" || attribute === "src") {
    return isAnchorLinkAllowed(value);
  }
  return true;
};
const validateProps = (type, props) => {
  if (!props) {
    return {};
  }
  props = Object.fromEntries(
    Object.entries(props).filter(([name, value]) => {
      const isValid = validateProp(name, value);
      if (!isValid) {
        console.warn(`[@nuxtjs/mdc] removing unsafe attribute: ${name}="${value}"`);
      }
      return isValid;
    })
  );
  if (type === "pre") {
    if (typeof props.highlights === "string") {
      props.highlights = props.highlights.split(" ").map((i) => Number.parseInt(i));
    }
  }
  return props;
};

function compileHast(options = {}) {
  const slugs = new Slugger();
  function compileToJSON(node, parent) {
    if (node.type === "root") {
      return {
        type: "root",
        children: node.children.map((child) => compileToJSON(child, node)).filter(Boolean)
      };
    }
    const position = node.position?.start?.offset && node.position?.end?.offset ? {
      start: node.position.start.offset,
      end: node.position.end.offset
    } : void 0;
    if (node.type === "element") {
      if (node.tagName === "p" && node.children.every((child) => child.type === "text" && /^\s*$/.test(child.value))) {
        return null;
      }
      if (node.tagName === "li") {
        let hasPreviousParagraph = false;
        node.children = node.children?.flatMap((child) => {
          if (child.type === "element" && child.tagName === "p") {
            if (hasPreviousParagraph) {
              child.children.unshift({
                type: "element",
                tagName: "br",
                properties: {},
                children: []
              });
            }
            hasPreviousParagraph = true;
            return child.children;
          }
          return child;
        });
      }
      if (node.tagName?.match(/^h\d$/)) {
        node.properties = node.properties || {};
        node.properties.id = String(node.properties?.id || slugs.slug(toString(node))).replace(/-+/g, "-").replace(/^-|-$/g, "").replace(/^(\d)/, "_$1");
      }
      if (node.tagName === "component-slot") {
        node.tagName = "template";
      }
      const children = (node.tagName === "template" && node.content?.children.length ? node.content.children : node.children).map((child) => compileToJSON(child, node)).filter(Boolean);
      const result = {
        type: "element",
        tag: node.tagName,
        props: validateProps(node.tagName, node.properties),
        children
      };
      if (options.keepPosition) {
        result.position = position;
      }
      return result;
    }
    if (node.type === "text") {
      if (!/^\n+$/.test(node.value || "") || parent?.properties?.emptyLinePlaceholder) {
        return options.keepPosition ? { type: "text", value: node.value, position } : { type: "text", value: node.value };
      }
    }
    if (options.keepComments && node.type === "comment") {
      return options.keepPosition ? { type: "comment", value: node.value, position } : { type: "comment", value: node.value };
    }
    return null;
  }
  this.Compiler = (tree) => {
    const body = compileToJSON(tree);
    let excerpt = void 0;
    const excerptIndex = tree.children.findIndex((node) => node.type === "comment" && node.value?.trim() === "more");
    if (excerptIndex !== -1) {
      excerpt = compileToJSON({
        type: "root",
        children: tree.children.slice(0, excerptIndex)
      });
      if (excerpt.children.find((node) => node.type === "element" && node.tag === "pre")) {
        const lastChild = body.children[body.children.length - 1];
        if (lastChild.type === "element" && lastChild.tag === "style") {
          excerpt.children.push(lastChild);
        }
      }
    }
    body.children = (body.children || []).filter((child) => child.type !== "text");
    return {
      body,
      excerpt
    };
  };
}

let moduleOptions;
let generatedMdcConfigs;
const createParseProcessor = async (inlineOptions = {}) => {
  if (!moduleOptions) {
    moduleOptions = await import(
      '../build/mdc-imports.mjs'
      /* @vite-ignore */
    ).catch(() => ({}));
  }
  if (!generatedMdcConfigs) {
    generatedMdcConfigs = await import(
      '../build/mdc-configs.mjs'
      /* @vite-ignore */
    ).then((r) => r.getMdcConfigs()).catch(() => []);
  }
  const mdcConfigs = [
    ...generatedMdcConfigs || [],
    ...inlineOptions.configs || []
  ];
  if (inlineOptions.highlight != null && inlineOptions.highlight != false && inlineOptions.highlight.highlighter !== void 0 && typeof inlineOptions.highlight.highlighter !== "function") {
    inlineOptions = {
      ...inlineOptions,
      highlight: {
        ...inlineOptions.highlight
      }
    };
    delete inlineOptions.highlight.highlighter;
  }
  const options = defu(inlineOptions, {
    remark: { plugins: moduleOptions?.remarkPlugins },
    rehype: { plugins: moduleOptions?.rehypePlugins },
    highlight: moduleOptions?.highlight
  }, defaults);
  if (options.rehype?.plugins?.highlight) {
    if (inlineOptions.highlight === false) {
      delete options.rehype.plugins.highlight;
    } else {
      options.rehype.plugins.highlight.options = {
        ...options.rehype.plugins.highlight.options || {},
        ...options.highlight || {}
      };
    }
  }
  let processor = unified();
  for (const config of mdcConfigs) {
    processor = await config.unified?.pre?.(processor) || processor;
  }
  processor.use(remarkParse);
  for (const config of mdcConfigs) {
    processor = await config.unified?.remark?.(processor) || processor;
  }
  await useProcessorPlugins(processor, options.remark?.plugins);
  processor.use(remark2rehype, options.rehype?.options);
  for (const config of mdcConfigs) {
    processor = await config.unified?.rehype?.(processor) || processor;
  }
  await useProcessorPlugins(processor, options.rehype?.plugins);
  processor.use(compileHast, options);
  for (const config of mdcConfigs) {
    processor = await config.unified?.post?.(processor) || processor;
  }
  return processor;
};
const createMarkdownParser = async (inlineOptions = {}) => {
  const processor = await createParseProcessor(inlineOptions);
  return async function parse(md, { fileOptions } = {}) {
    const { content, data: frontmatter } = await parseFrontMatter(md);
    const cwd = typeof process !== "undefined" && typeof process.cwd === "function" ? process.cwd() : "/tmp";
    const processedFile = await new Promise((resolve, reject) => {
      processor.process({ cwd, ...fileOptions, value: content, data: frontmatter }, (err, file) => {
        if (err) {
          reject(err);
        } else {
          resolve(file);
        }
      });
    });
    const parsedContent = processedFile?.result;
    const data = Object.assign(
      inlineOptions.contentHeading !== false ? contentHeading(parsedContent.body) : {},
      frontmatter,
      processedFile?.data || {}
    );
    const parsedResult = { data, body: parsedContent.body };
    const userTocOption = data.toc ?? inlineOptions.toc;
    if (userTocOption !== false) {
      const tocOption = defu({}, userTocOption, defaults.toc);
      parsedResult.toc = generateToc(parsedContent.body, tocOption);
    }
    if (parsedContent.excerpt) {
      parsedResult.excerpt = parsedContent.excerpt;
    }
    return parsedResult;
  };
};
const parseMarkdown = async (md, markdownParserOptions = {}, parseOptions = {}) => {
  const parser = await createMarkdownParser(markdownParserOptions);
  return parser(md.replace(/\r\n/g, "\n"), parseOptions);
};
function contentHeading(body) {
  let title = "";
  let description = "";
  const children = body.children.filter((node) => node.type === "element" && node.tag !== "hr");
  if (children.length && children[0].tag === "h1") {
    const node = children.shift();
    title = nodeTextContent(node);
  }
  if (children.length && children[0].tag === "p") {
    const node = children.shift();
    description = nodeTextContent(node);
  }
  return {
    title,
    description
  };
}

function useNitroOrigin(e) {
  return getNitroOrigin(e);
}

async function fetchGitHubRepo(name) {
  const data = await $fetch(`https://ungh.cc/repos/${name}`);
  const validatedData = zod.object({
    repo: zod.object({
      id: zod.number(),
      name: zod.string(),
      repo: zod.string(),
      description: zod.string(),
      createdAt: zod.string(),
      updatedAt: zod.string(),
      pushedAt: zod.string(),
      stars: zod.number(),
      watchers: zod.number(),
      forks: zod.number(),
      defaultBranch: zod.string()
    })
  }).parse(data);
  return validatedData;
}
async function fetchGitHubFile(name, branch, path) {
  const data = await $fetch(`https://ungh.cc/repos/${name}/files/${branch}/${path}`);
  return JSON.parse(data);
}

const cachedGitHubPackageJsons = defineCachedFunction(async (repo) => {
  const { repo: repository } = await fetchGitHubRepo(repo);
  const packageJsonPath = "package.json";
  try {
    return await fetchGitHubFile(repo, repository.defaultBranch, packageJsonPath);
  } catch (_error) {
    return null;
  }
}, {
  maxAge: 1e3 * 60 * 60 * 24,
  // 24 hours
  group: "github",
  name: "githubPackages",
  getKey: (name) => `githubPackages:${name}`
});
const cachedGithubRelease = defineCachedFunction(async (repo) => {
  const { releases } = await $fetch(`https://ungh.cc/repos/${repo}/releases`);
  return releases;
}, {
  maxAge: 1e3 * 60 * 10,
  // 10 minutes
  group: "github",
  name: "githubReleases",
  getKey: (name) => `githubReleases:${name}`
});
async function fetchPackageJsonFromGitHub(repo) {
  return await cachedGitHubPackageJsons(repo);
}
async function fetchReleasesFromGitHub(repo) {
  return await cachedGithubRelease(repo);
}

const cachedNpmPackages = defineCachedFunction(async (name) => {
  const packageJson = await $fetch(`https://registry.npmjs.org/${name}/latest`);
  return packageJson;
}, {
  maxAge: 1e3 * 60 * 60 * 24,
  // 24 hours
  group: "npm",
  name: "npmPackages",
  getKey: (name) => `npmPackages:${name}`
});
async function fetchPackageJson(name) {
  const packageJson = await cachedNpmPackages(name);
  return packageJson;
}

const collections = {
  'ant-design': () => import('../_/icons.mjs').then(m => m.default),
  'arcticons': () => import('../_/icons2.mjs').then(m => m.default),
  'carbon': () => import('../_/icons3.mjs').then(m => m.default),
  'codicon': () => import('../_/icons4.mjs').then(m => m.default),
  'eos-icons': () => import('../_/icons5.mjs').then(m => m.default),
  'hugeicons': () => import('../_/icons6.mjs').then(m => m.default),
  'ic': () => import('../_/icons7.mjs').then(m => m.default),
  'logos': () => import('../_/icons8.mjs').then(m => m.default),
  'lucide': () => import('../_/icons9.mjs').then(m => m.default),
  'material-symbols': () => import('../_/icons10.mjs').then(m => m.default),
  'mdi': () => import('../_/icons11.mjs').then(m => m.default),
  'octicon': () => import('../_/icons12.mjs').then(m => m.default),
  'ph': () => import('../_/icons13.mjs').then(m => m.default),
  'ri': () => import('../_/icons14.mjs').then(m => m.default),
  'simple-icons': () => import('../_/icons15.mjs').then(m => m.default),
  'tabler': () => import('../_/icons16.mjs').then(m => m.default),
  'vscode-icons': () => import('../_/icons17.mjs').then(m => m.default),
};

const DEFAULT_ENDPOINT = "https://api.iconify.design";
const _bpR_ew = defineCachedEventHandler(async (event) => {
  const url = getRequestURL$1(event);
  if (!url)
    return createError$2({ status: 400, message: "Invalid icon request" });
  const options = useAppConfig().icon;
  const collectionName = event.context.params?.collection?.replace(/\.json$/, "");
  const collection = collectionName ? await collections[collectionName]?.() : null;
  const apiEndPoint = options.iconifyApiEndpoint || DEFAULT_ENDPOINT;
  const icons = url.searchParams.get("icons")?.split(",");
  if (collection) {
    if (icons?.length) {
      const data = getIcons(
        collection,
        icons
      );
      consola.debug(`[Icon] serving ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from bundled collection`);
      return data;
    }
  }
  if (options.fallbackToApi === true || options.fallbackToApi === "server-only") {
    const apiUrl = new URL("./" + basename(url.pathname) + url.search, apiEndPoint);
    consola.debug(`[Icon] fetching ${(icons || []).map((i) => "`" + collectionName + ":" + i + "`").join(",")} from iconify api`);
    if (apiUrl.host !== new URL(apiEndPoint).host) {
      return createError$2({ status: 400, message: "Invalid icon request" });
    }
    try {
      const data = await $fetch(apiUrl.href);
      return data;
    } catch (e) {
      consola.error(e);
      if (e.status === 404)
        return createError$2({ status: 404 });
      else
        return createError$2({ status: 500, message: "Failed to fetch fallback icon" });
    }
  }
  return createError$2({ status: 404 });
}, {
  group: "nuxt",
  name: "icon",
  getKey(event) {
    const collection = event.context.params?.collection?.replace(/\.json$/, "") || "unknown";
    const icons = String(getQuery(event).icons || "");
    return `${collection}_${icons.split(",")[0]}_${icons.length}_${hash$1(icons)}`;
  },
  swr: true,
  maxAge: 60 * 60 * 24 * 7
  // 1 week
});

const storage = prefixStorage(useStorage(), "i18n");
function cachedFunctionI18n(fn, opts) {
  opts = { maxAge: 1, ...opts };
  const pending = {};
  async function get(key, resolver) {
    const isPending = pending[key];
    if (!isPending) {
      pending[key] = Promise.resolve(resolver());
    }
    try {
      return await pending[key];
    } finally {
      delete pending[key];
    }
  }
  return async (...args) => {
    const key = [opts.name, opts.getKey(...args)].join(":").replace(/:\/$/, ":index");
    const maxAge = opts.maxAge ?? 1;
    const isCacheable = !opts.shouldBypassCache(...args) && maxAge >= 0;
    const cache = isCacheable && await storage.getItemRaw(key);
    if (!cache || cache.ttl < Date.now()) {
      pending[key] = Promise.resolve(fn(...args));
      const value = await get(key, () => fn(...args));
      if (isCacheable) {
        await storage.setItemRaw(key, { ttl: Date.now() + maxAge * 1e3, value, mtime: Date.now() });
      }
      return value;
    }
    return cache.value;
  };
}

const _getMessages = async (locale) => {
  return { [locale]: await getLocaleMessagesMerged(locale, localeLoaders[locale]) };
};
const _getMessagesCached = cachedFunctionI18n(_getMessages, {
  name: "messages",
  maxAge: 60 * 60 * 24,
  getKey: (locale) => locale,
  shouldBypassCache: (locale) => !isLocaleCacheable(locale)
});
const getMessages = _getMessagesCached;
const _getMergedMessages = async (locale, fallbackLocales) => {
  const merged = {};
  try {
    if (fallbackLocales.length > 0) {
      const messages = await Promise.all(fallbackLocales.map(getMessages));
      for (const message2 of messages) {
        deepCopy(message2, merged);
      }
    }
    const message = await getMessages(locale);
    deepCopy(message, merged);
    return merged;
  } catch (e) {
    throw new Error("Failed to merge messages: " + e.message);
  }
};
const getMergedMessages = cachedFunctionI18n(_getMergedMessages, {
  name: "merged-single",
  maxAge: 60 * 60 * 24,
  getKey: (locale, fallbackLocales) => `${locale}-[${[...new Set(fallbackLocales)].sort().join("-")}]`,
  shouldBypassCache: (locale, fallbackLocales) => !isLocaleWithFallbacksCacheable(locale, fallbackLocales)
});
const _getAllMergedMessages = async (locales) => {
  const merged = {};
  try {
    const messages = await Promise.all(locales.map(getMessages));
    for (const message of messages) {
      deepCopy(message, merged);
    }
    return merged;
  } catch (e) {
    throw new Error("Failed to merge messages: " + e.message);
  }
};
cachedFunctionI18n(_getAllMergedMessages, {
  name: "merged-all",
  maxAge: 60 * 60 * 24,
  getKey: (locales) => locales.join("-"),
  shouldBypassCache: (locales) => !locales.every((locale) => isLocaleCacheable(locale))
});

const _messagesHandler = defineEventHandler(async (event) => {
  const locale = getRouterParam(event, "locale");
  if (!locale) {
    throw createError({ status: 400, message: "Locale not specified." });
  }
  const ctx = useI18nContext(event);
  if (ctx.localeConfigs && locale in ctx.localeConfigs === false) {
    throw createError({ status: 404, message: `Locale '${locale}' not found.` });
  }
  const messages = await getMergedMessages(locale, ctx.localeConfigs?.[locale]?.fallbacks ?? []);
  deepCopy(messages, ctx.messages);
  return ctx.messages;
});
const _cachedMessageLoader = defineCachedFunction(_messagesHandler, {
  name: "i18n:messages-internal",
  maxAge: 60 * 60 * 24,
  getKey: (event) => [getRouterParam(event, "locale") ?? "null", getRouterParam(event, "hash") ?? "null"].join("-"),
  shouldBypassCache(event) {
    const locale = getRouterParam(event, "locale");
    if (locale == null) return false;
    return !useI18nContext(event).localeConfigs?.[locale]?.cacheable;
  }
});
const _messagesHandlerCached = defineCachedEventHandler(_cachedMessageLoader, {
  name: "i18n:messages",
  maxAge: 10,
  swr: false,
  getKey: (event) => [getRouterParam(event, "locale") ?? "null", getRouterParam(event, "hash") ?? "null"].join("-")
});
const _wvYjFl = _messagesHandlerCached;

const VueResolver = (_, value) => {
  return isRef(value) ? toValue(value) : value;
};

const headSymbol = "usehead";
function vueInstall(head) {
  const plugin = {
    install(app) {
      app.config.globalProperties.$unhead = head;
      app.config.globalProperties.$head = head;
      app.provide(headSymbol, head);
    }
  };
  return plugin.install;
}

function injectHead() {
  if (hasInjectionContext()) {
    const instance = inject(headSymbol);
    if (!instance) {
      throw new Error("useHead() was called without provide context, ensure you call it through the setup() function.");
    }
    return instance;
  }
  throw new Error("useHead() was called without provide context, ensure you call it through the setup() function.");
}
function useHead(input, options = {}) {
  const head = options.head || injectHead();
  return head.ssr ? head.push(input || {}, options) : clientUseHead(head, input, options);
}
function clientUseHead(head, input, options = {}) {
  const deactivated = ref(false);
  let entry;
  watchEffect(() => {
    const i = deactivated.value ? {} : walkResolver(input, VueResolver);
    if (entry) {
      entry.patch(i);
    } else {
      entry = head.push(i, options);
    }
  });
  const vm = getCurrentInstance();
  if (vm) {
    onBeforeUnmount(() => {
      entry.dispose();
    });
    onDeactivated(() => {
      deactivated.value = true;
    });
    onActivated(() => {
      deactivated.value = false;
    });
  }
  return entry;
}
function useSeoMeta(input = {}, options = {}) {
  const head = options.head || injectHead();
  head.use(FlatMetaPlugin);
  const { title, titleTemplate, ...meta } = input;
  return useHead({
    title,
    titleTemplate,
    _flatMeta: meta
  }, options);
}

function resolveUnrefHeadInput(input) {
  return walkResolver(input, VueResolver);
}

function createHead(options = {}) {
  const head = createHead$1({
    ...options,
    propResolvers: [VueResolver]
  });
  head.install = vueInstall(head);
  return head;
}

const unheadOptions = {
  disableDefaults: true,
  disableCapoSorting: false,
  plugins: [DeprecationsPlugin, PromisesPlugin, TemplateParamsPlugin, AliasSortingPlugin],
};

function createSSRContext(event) {
  const ssrContext = {
    url: event.path,
    event,
    runtimeConfig: useRuntimeConfig(event),
    noSSR: event.context.nuxt?.noSSR || (false),
    head: createHead(unheadOptions),
    error: false,
    nuxt: void 0,
    /* NuxtApp */
    payload: {},
    _payloadReducers: /* @__PURE__ */ Object.create(null),
    modules: /* @__PURE__ */ new Set()
  };
  return ssrContext;
}
function setSSRError(ssrContext, error) {
  ssrContext.error = true;
  ssrContext.payload = { error };
  ssrContext.url = error.url;
}

const APP_ROOT_OPEN_TAG = `<${appRootTag}${propsToString(appRootAttrs)}>`;
const APP_ROOT_CLOSE_TAG = `</${appRootTag}>`;
const getServerEntry = () => import('../build/server.mjs').then((r) => r.default || r);
const getClientManifest = () => import('../build/client.manifest.mjs').then((r) => r.default || r).then((r) => typeof r === "function" ? r() : r);
const getSSRRenderer = lazyCachedFunction(async () => {
  const manifest = await getClientManifest();
  if (!manifest) {
    throw new Error("client.manifest is not available");
  }
  const createSSRApp = await getServerEntry();
  if (!createSSRApp) {
    throw new Error("Server bundle is not available");
  }
  const options = {
    manifest,
    renderToString: renderToString$1,
    buildAssetsURL
  };
  const renderer = createRenderer(createSSRApp, options);
  async function renderToString$1(input, context) {
    const html = await renderToString(input, context);
    return APP_ROOT_OPEN_TAG + html + APP_ROOT_CLOSE_TAG;
  }
  return renderer;
});
const getSPARenderer = lazyCachedFunction(async () => {
  const manifest = await getClientManifest();
  const spaTemplate = await import('../virtual/_virtual_spa-template.mjs').then((r) => r.template).catch(() => "").then((r) => {
    {
      return APP_ROOT_OPEN_TAG + r + APP_ROOT_CLOSE_TAG;
    }
  });
  const options = {
    manifest,
    renderToString: () => spaTemplate,
    buildAssetsURL
  };
  const renderer = createRenderer(() => () => {
  }, options);
  const result = await renderer.renderToString({});
  const renderToString = (ssrContext) => {
    const config = useRuntimeConfig(ssrContext.event);
    ssrContext.modules ||= /* @__PURE__ */ new Set();
    ssrContext.payload.serverRendered = false;
    ssrContext.config = {
      public: config.public,
      app: config.app
    };
    return Promise.resolve(result);
  };
  return {
    rendererContext: renderer.rendererContext,
    renderToString
  };
});
function lazyCachedFunction(fn) {
  let res = null;
  return () => {
    if (res === null) {
      res = fn().catch((err) => {
        res = null;
        throw err;
      });
    }
    return res;
  };
}
function getRenderer(ssrContext) {
  return ssrContext.noSSR ? getSPARenderer() : getSSRRenderer();
}
const getSSRStyles = lazyCachedFunction(() => import('../build/styles.mjs').then((r) => r.default || r));

async function renderInlineStyles(usedModules) {
  const styleMap = await getSSRStyles();
  const inlinedStyles = /* @__PURE__ */ new Set();
  for (const mod of usedModules) {
    if (mod in styleMap && styleMap[mod]) {
      for (const style of await styleMap[mod]()) {
        inlinedStyles.add(style);
      }
    }
  }
  return Array.from(inlinedStyles).map((style) => ({ innerHTML: style }));
}

const ROOT_NODE_REGEX = new RegExp(`^<${appRootTag}[^>]*>([\\s\\S]*)<\\/${appRootTag}>$`);
function getServerComponentHTML(body) {
  const match = body.match(ROOT_NODE_REGEX);
  return match?.[1] || body;
}
const SSR_SLOT_TELEPORT_MARKER = /^uid=([^;]*);slot=(.*)$/;
const SSR_CLIENT_TELEPORT_MARKER = /^uid=([^;]*);client=(.*)$/;
const SSR_CLIENT_SLOT_MARKER = /^island-slot=([^;]*);(.*)$/;
function getSlotIslandResponse(ssrContext) {
  if (!ssrContext.islandContext || !Object.keys(ssrContext.islandContext.slots).length) {
    return void 0;
  }
  const response = {};
  for (const [name, slot] of Object.entries(ssrContext.islandContext.slots)) {
    response[name] = {
      ...slot,
      fallback: ssrContext.teleports?.[`island-fallback=${name}`]
    };
  }
  return response;
}
function getClientIslandResponse(ssrContext) {
  if (!ssrContext.islandContext || !Object.keys(ssrContext.islandContext.components).length) {
    return void 0;
  }
  const response = {};
  for (const [clientUid, component] of Object.entries(ssrContext.islandContext.components)) {
    const html = ssrContext.teleports?.[clientUid]?.replaceAll("<!--teleport start anchor-->", "") || "";
    response[clientUid] = {
      ...component,
      html,
      slots: getComponentSlotTeleport(clientUid, ssrContext.teleports ?? {})
    };
  }
  return response;
}
function getComponentSlotTeleport(clientUid, teleports) {
  const entries = Object.entries(teleports);
  const slots = {};
  for (const [key, value] of entries) {
    const match = key.match(SSR_CLIENT_SLOT_MARKER);
    if (match) {
      const [, id, slot] = match;
      if (!slot || clientUid !== id) {
        continue;
      }
      slots[slot] = value;
    }
  }
  return slots;
}
function replaceIslandTeleports(ssrContext, html) {
  const { teleports, islandContext } = ssrContext;
  if (islandContext || !teleports) {
    return html;
  }
  for (const key in teleports) {
    const matchClientComp = key.match(SSR_CLIENT_TELEPORT_MARKER);
    if (matchClientComp) {
      const [, uid, clientId] = matchClientComp;
      if (!uid || !clientId) {
        continue;
      }
      html = html.replace(new RegExp(` data-island-uid="${uid}" data-island-component="${clientId}"[^>]*>`), (full) => {
        return full + teleports[key];
      });
      continue;
    }
    const matchSlot = key.match(SSR_SLOT_TELEPORT_MARKER);
    if (matchSlot) {
      const [, uid, slot] = matchSlot;
      if (!uid || !slot) {
        continue;
      }
      html = html.replace(new RegExp(` data-island-uid="${uid}" data-island-slot="${slot}"[^>]*>`), (full) => {
        return full + teleports[key];
      });
    }
  }
  return html;
}

const ISLAND_SUFFIX_RE = /\.json(\?.*)?$/;
const _SxA8c9 = defineEventHandler$1(async (event) => {
  const nitroApp = useNitroApp();
  setResponseHeaders(event, {
    "content-type": "application/json;charset=utf-8",
    "x-powered-by": "Nuxt"
  });
  const islandContext = await getIslandContext(event);
  const ssrContext = {
    ...createSSRContext(event),
    islandContext,
    noSSR: false,
    url: islandContext.url
  };
  const renderer = await getSSRRenderer();
  const renderResult = await renderer.renderToString(ssrContext).catch(async (error) => {
    await ssrContext.nuxt?.hooks.callHook("app:error", error);
    throw error;
  });
  const inlinedStyles = await renderInlineStyles(ssrContext.modules ?? []);
  await ssrContext.nuxt?.hooks.callHook("app:rendered", { ssrContext, renderResult });
  if (inlinedStyles.length) {
    ssrContext.head.push({ style: inlinedStyles });
  }
  const islandHead = {};
  for (const entry of ssrContext.head.entries.values()) {
    for (const [key, value] of Object.entries(resolveUnrefHeadInput(entry.input))) {
      const currentValue = islandHead[key];
      if (Array.isArray(currentValue)) {
        currentValue.push(...value);
      }
      islandHead[key] = value;
    }
  }
  islandHead.link ||= [];
  islandHead.style ||= [];
  const islandResponse = {
    id: islandContext.id,
    head: islandHead,
    html: getServerComponentHTML(renderResult.html),
    components: getClientIslandResponse(ssrContext),
    slots: getSlotIslandResponse(ssrContext)
  };
  await nitroApp.hooks.callHook("render:island", islandResponse, { event, islandContext });
  return islandResponse;
});
async function getIslandContext(event) {
  let url = event.path || "";
  const componentParts = url.substring("/__nuxt_island".length + 1).replace(ISLAND_SUFFIX_RE, "").split("_");
  const hashId = componentParts.length > 1 ? componentParts.pop() : void 0;
  const componentName = componentParts.join("_");
  const context = event.method === "GET" ? getQuery(event) : await readBody(event);
  const ctx = {
    url: "/",
    ...context,
    id: hashId,
    name: componentName,
    props: destr(context.props) || {},
    slots: {},
    components: {}
  };
  return ctx;
}

const _eD5A5M = defineEventHandler$1(async (event) => {
  const { getContentQuery } = await import('../_/query.mjs');
  const { serverQueryContent } = await import('../_/storage.mjs').then(function (n) { return n.a; });
  const query = getContentQuery(event);
  const { advanceQuery } = useRuntimeConfig().public.content.experimental;
  if (query.first) {
    let contentQuery = serverQueryContent(event, query);
    if (!advanceQuery) {
      contentQuery = contentQuery.withDirConfig();
    }
    const content = await contentQuery.findOne();
    const _result = advanceQuery ? content?.result : content;
    const missing = !_result && !content?.dirConfig?.navigation?.redirect && !content?._dir?.navigation?.redirect;
    if (missing) {
      throw createError$2({
        statusMessage: "Document not found!",
        statusCode: 404,
        data: {
          description: "Could not find document for the given query.",
          query
        }
      });
    }
    return content;
  }
  if (query.count) {
    return serverQueryContent(event, query).count();
  }
  return serverQueryContent(event, query).find();
});

const _EHNXAI = defineEventHandler$1(async (event) => {
  const { getContentIndex } = await import('../_/storage.mjs').then(function (n) { return n.c; });
  const { cacheStorage, serverQueryContent } = await import('../_/storage.mjs').then(function (n) { return n.a; });
  const { content } = useRuntimeConfig();
  const now = Date.now();
  const contents = await serverQueryContent(event).find();
  await getContentIndex(event);
  const navigation = await $fetch(`${content.api.baseURL}/navigation`);
  await cacheStorage().setItem("content-navigation.json", navigation);
  return {
    generatedAt: now,
    generateTime: Date.now() - now,
    contents: content.experimental.cacheContents ? contents : [],
    navigation
  };
});

const _jTnZEt = defineEventHandler$1(async (event) => {
  const { serverSearchContent, splitPageIntoSections } = await import('../_/search.mjs');
  const MiniSearch = await import('minisearch').then((m) => m.default);
  const runtimeConfig = useRuntimeConfig();
  const { ignoredTags = [], filterQuery, indexed, options } = runtimeConfig.public.content.search;
  const files = await serverSearchContent(event, filterQuery);
  const sections = files.map((page) => splitPageIntoSections(page, { ignoredTags })).flat();
  if (indexed) {
    const miniSearch = new MiniSearch(options);
    miniSearch.addAll(sections);
    return JSON.stringify(miniSearch);
  }
  return sections;
});

const isPreview = (event) => {
  const previewToken = getQuery(event).previewToken || getCookie(event, "previewToken");
  return !!previewToken;
};
const getPreview = (event) => {
  const key = getQuery(event).previewToken || getCookie(event, "previewToken");
  return { key };
};

const _diihhV = defineEventHandler$1(async (event) => {
  const { getContentQuery } = await import('../_/query.mjs');
  const { cacheStorage, serverQueryContent } = await import('../_/storage.mjs').then(function (n) { return n.a; });
  const { createNav } = await import('../_/navigation.mjs');
  const query = getContentQuery(event);
  if (!isPreview(event) && Object.keys(query).length === 0) {
    const cache = await cacheStorage().getItem("content-navigation.json");
    if (cache) {
      return cache;
    }
  }
  const contents = await serverQueryContent(event, query).where({
    /**
     * Partial contents are not included in the navigation
     * A partial content is a content that has `_` prefix in its path
     */
    _partial: false,
    /**
     * Exclude any pages which have opted out of navigation via frontmatter.
     */
    navigation: {
      $ne: false
    }
  }).find();
  const _locale = (query?.where || []).find((w) => w._locale)?._locale;
  const dirConfigs = await serverQueryContent(event, _locale ? { where: [{ _locale }] } : void 0).where({ _path: /\/_dir$/i, _partial: true }).find();
  const configs = (dirConfigs?.result || dirConfigs).reduce((configs2, conf) => {
    if (conf.title?.toLowerCase() === "dir") {
      conf.title = void 0;
    }
    const key = conf._path.split("/").slice(0, -1).join("/") || "/";
    configs2[key] = {
      ...conf,
      // Extract meta from body. (non MD files)
      ...conf.body
    };
    return configs2;
  }, {});
  return createNav(contents?.result || contents, configs);
});

const _mITn_C = lazyEventHandler(() => {
  const opts = useRuntimeConfig().ipx || {};
  const fsDir = opts?.fs?.dir ? (Array.isArray(opts.fs.dir) ? opts.fs.dir : [opts.fs.dir]).map((dir) => isAbsolute(dir) ? dir : fileURLToPath(new URL(dir, globalThis._importMeta_.url))) : void 0;
  const fsStorage = opts.fs?.dir ? ipxFSStorage({ ...opts.fs, dir: fsDir }) : void 0;
  const httpStorage = opts.http?.domains ? ipxHttpStorage({ ...opts.http }) : void 0;
  if (!fsStorage && !httpStorage) {
    throw new Error("IPX storage is not configured!");
  }
  const ipxOptions = {
    ...opts,
    storage: fsStorage || httpStorage,
    httpStorage
  };
  const ipx = createIPX(ipxOptions);
  const ipxHandler = createIPXH3Handler(ipx);
  return useBase(opts.baseURL, ipxHandler);
});

const _lazy_tyDr8I = () => import('../routes/api/_content/packages.json.mjs');
const _lazy_fLwWdT = () => import('../routes/api/_content/releases.json.mjs');
const _lazy_9zFJPU = () => import('../routes/renderer.mjs');
const _lazy_bCfcsc = () => import('../routes/sitemap_index.xml.mjs');
const _lazy_Eym0Un = () => import('../routes/__sitemap__/_sitemap_.xml.mjs');
const _lazy_lRht0M = () => import('../routes/__og-image__/font/font.mjs');
const _lazy_0qE0Uc = () => import('../routes/__og-image__/image/image.mjs');

const handlers = [
  { route: '', handler: _3vdAZv, lazy: false, middleware: true, method: undefined },
  { route: '/api/_content/packages.json', handler: _lazy_tyDr8I, lazy: true, middleware: false, method: undefined },
  { route: '/api/_content/releases.json', handler: _lazy_fLwWdT, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_9zFJPU, lazy: true, middleware: false, method: undefined },
  { route: '', handler: _f7hhGP, lazy: false, middleware: true, method: undefined },
  { route: '/sitemap_index.xml', handler: _lazy_bCfcsc, lazy: true, middleware: false, method: undefined },
  { route: '/__sitemap__/**:sitemap', handler: _lazy_Eym0Un, lazy: true, middleware: false, method: undefined },
  { route: '/__sitemap__/style.xsl', handler: _AlJ4WX, lazy: false, middleware: false, method: undefined },
  { route: '/sitemap.xml', handler: _D5sQ8g, lazy: false, middleware: false, method: undefined },
  { route: '/api/_mdc/highlight', handler: _thVScw, lazy: false, middleware: false, method: undefined },
  { route: '/api/_nuxt_icon/:collection', handler: _bpR_ew, lazy: false, middleware: false, method: undefined },
  { route: '/__og-image__/font/**', handler: _lazy_lRht0M, lazy: true, middleware: false, method: undefined },
  { route: '/__og-image__/image/**', handler: _lazy_0qE0Uc, lazy: true, middleware: false, method: undefined },
  { route: '/__og-image__/static/**', handler: _lazy_0qE0Uc, lazy: true, middleware: false, method: undefined },
  { route: '/_i18n/:hash/:locale/messages.json', handler: _wvYjFl, lazy: false, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/api/_content/query/:qid/**:params', handler: _eD5A5M, lazy: false, middleware: false, method: "get" },
  { route: '/api/_content/query/:qid', handler: _eD5A5M, lazy: false, middleware: false, method: "get" },
  { route: '/api/_content/query', handler: _eD5A5M, lazy: false, middleware: false, method: "get" },
  { route: '/api/_content/cache.1767020924919.json', handler: _EHNXAI, lazy: false, middleware: false, method: "get" },
  { route: '/api/_content/search-1767020924919', handler: _jTnZEt, lazy: false, middleware: false, method: "get" },
  { route: '/api/_content/navigation/:qid/**:params', handler: _diihhV, lazy: false, middleware: false, method: "get" },
  { route: '/api/_content/navigation/:qid', handler: _diihhV, lazy: false, middleware: false, method: "get" },
  { route: '/api/_content/navigation', handler: _diihhV, lazy: false, middleware: false, method: "get" },
  { route: '/_ipx/**', handler: _mITn_C, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_9zFJPU, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(nodeHandler, aRequest);
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler$1(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { setHeaders as $, globalSitemapSources as A, resolveSitemapSources as B, resolveSitemapEntries as C, defu as D, joinURL as E, normaliseDate as F, childSitemapSources as G, sortInPlace as H, useSitemapRuntimeConfig as I, useNitroUrlResolvers as J, setHeader as K, getRouterParam$1 as L, withoutLeadingSlash as M, withoutTrailingSlash as N, parseChunkInfo as O, getSitemapConfig as P, createSitemap as Q, prefixStorage as R, useStorage as S, useNitroOrigin as T, emojiCache as U, useOgImageRuntimeConfig as V, fetchIsland as W, normaliseFontInput as X, theme as Y, withTrailingSlash as Z, handleCacheHeaders as _, fetchPackageJsonFromGitHub as a, hash$1 as a0, parseURL as a1, setResponseHeader as a2, proxyRequest as a3, sendRedirect$1 as a4, resolveContext as a5, H3Error$1 as a6, isRelative as a7, destr as a8, extname as a9, createRouter$1 as aA, getRequestURL$1 as aB, getRequestURL as aC, getRequestHeader as aD, decodeHtml as aE, logger$1 as aF, toBase64Image as aG, withBase as aH, htmlDecodeQuotes as aI, sendError as aJ, fontCache as aK, createStorage as aL, memoryDriver as aM, nodeServer as aN, camelCase as aa, useRuntimeConfig as ab, isPreview as ac, withLeadingSlash as ad, getPreview as ae, pascalCase as af, klona as ag, createDefu as ah, defuFn as ai, useSeoMeta as aj, headSymbol as ak, useHead as al, sanitizeStatusCode$1 as am, parse as an, getRequestHeader$1 as ao, isEqual as ap, kebabCase as aq, getContext as ar, setCookie$1 as as, getCookie as at, deleteCookie as au, $fetch$1 as av, baseURL as aw, createHooks as ax, executeAsync as ay, toRouteMatcher as az, fetchReleasesFromGitHub as b, getResponseStatus as c, defineEventHandler$1 as d, appId as e, fetchPackageJson as f, getResponseStatusText as g, defineRenderHandler as h, buildAssetsURL as i, publicAssetsURL as j, appTeleportTag as k, appTeleportAttrs as l, getQuery as m, createError$2 as n, createSSRContext as o, parseMarkdown as p, appHead as q, getRouteRules as r, setSSRError as s, getRenderer as t, replaceIslandTeleports as u, useNitroApp as v, defineCachedFunction as w, escapeValueForXml as x, withQuery as y, getHeader as z };
