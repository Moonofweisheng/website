import { Resvg } from '@resvg/resvg-js';

const node = {
  initWasmPromise: Promise.resolve(),
  Resvg: Resvg
};

export { node as default };
