import { s as serverQueryContent$1 } from './storage.mjs';

const serverQueryContent = serverQueryContent$1;

export { serverQueryContent as s };
