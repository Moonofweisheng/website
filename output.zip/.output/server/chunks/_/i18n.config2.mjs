const i18n_config = () => ({
  legacy: false,
  locale: "zh",
  messages: { zh: {
    "Read more at": "\u66F4\u591A\u4FE1\u606F\u8BF7\u53C2\u8003",
    "Back to Top": "\u8FD4\u56DE\u9876\u90E8"
  } }
});

export { i18n_config as default };
