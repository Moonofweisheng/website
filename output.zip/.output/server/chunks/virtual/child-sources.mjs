const sources = {
    "zh-CN": []
};

export { sources };
